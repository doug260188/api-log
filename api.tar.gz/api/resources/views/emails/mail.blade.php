<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="utf-8" />
</head>

<body>
    <h2>Sistema</h2>
    <p>{{ $test_message }}</p>
</body>

</html>
