<p align="center"><a href="https://laravel.com" target="_blank"><img src="https://raw.githubusercontent.com/laravel/art/master/logo-lockup/5%20SVG/2%20CMYK/1%20Full%20Color/laravel-logolockup-cmyk-red.svg" width="400"></a></p>

## PROJETO PADRÃO LARAVEL
- [ ] Instalar todos os componentes/pacotes

**Principais Comandos a serem utilizados**
```
composer install
```

- [ ] Levantar o banco de dados
- [ ] Criar o esquema para o projeto no banco de dados
- [ ] Configurar .ENV (APP_KEY, CONFIG DE BANCO DE DADOS, ETC)
- [ ] Executar a instalação do Migrate
- [ ] Executar o Migrate Status (verificar se é necessário rodar atualização do banco)
- [ ] Executar o Migrate (atualizar o banco de dados)

**Principais Comandos a serem utilizados**
```
php artisan migrate:install
php artisan migrate:status
php artisan migrate
```

## Este Sistema utiliza o VIACEP para consumir endereço dos CEP, com isso é necessário acesso a internet.

## Ver documentação e configuração do Laravel para maiores configurações

- [Documentação do Laravel](https://laravel.com/docs/).
- [Documentação do Lara vel para arquivos](https://laravel.com/docs/10.x/filesystem#main-content).

## Licens

The Laravel framework is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).
