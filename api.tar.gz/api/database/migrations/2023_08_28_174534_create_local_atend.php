<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() {
        Schema::create('local_atend', function (Blueprint $table) {
            $table->id();
            $table->string('nome_local', 250)->nullable();
            $table->string('cep', 10)->nullable();
            $table->string('endereco', 500)->nullable();
            $table->string('numero', 200)->nullable();
            $table->string('complemento', 200)->nullable();
            $table->string('bairro', 200)->nullable();
            $table->foreignId('estado')->nullable()->constrained('estado');
            $table->foreignId('municipio')->nullable()->constrained('municipio');
            $table->string('telefone', 15)->nullable();
            $table->string('fax', 15)->nullable();
            $table->string('email', 255)->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {
        Schema::dropIfExists('local_atend');
    }
};

