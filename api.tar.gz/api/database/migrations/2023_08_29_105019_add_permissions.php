<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() {
        DB::table('permissions')->insert([
                ['permission' => 'acao_rel_med','created_at' => now(),'updated_at' => now()],
                ['permission' => 'atendimento','created_at' => now(),'updated_at' => now()],
                ['permission' => 'aval_risc_int','created_at' => now(),'updated_at' => now()],
                ['permission' => 'caract_violencia','created_at' => now(),'updated_at' => now()],
                ['permission' => 'escolaridade','created_at' => now(),'updated_at' => now()],
                ['permission' => 'estado','created_at' => now(),'updated_at' => now()],
                ['permission' => 'estado_civil','created_at' => now(),'updated_at' => now()],
                ['permission' => 'etnia','created_at' => now(),'updated_at' => now()],
                ['permission' => 'failed_jobs','created_at' => now(),'updated_at' => now()],
                ['permission' => 'for_busc_serv','created_at' => now(),'updated_at' => now()],
                ['permission' => 'grau_violencia','created_at' => now(),'updated_at' => now()],
                ['permission' => 'inst_encaminha','created_at' => now(),'updated_at' => now()],
                ['permission' => 'local_atend','created_at' => now(),'updated_at' => now()],
                ['permission' => 'mulher','created_at' => now(),'updated_at' => now()],
                ['permission' => 'municipio','created_at' => now(),'updated_at' => now()],
                ['permission' => 'org_acionado','created_at' => now(),'updated_at' => now()],
                ['permission' => 'ori_sexual','created_at' => now(),'updated_at' => now()],
                ['permission' => 'password_resets','created_at' => now(),'updated_at' => now()],
                ['permission' => 'permissions','created_at' => now(),'updated_at' => now()],
                ['permission' => 'personal_access_tokens','created_at' => now(),'updated_at' => now()],
                ['permission' => 'prof_resp_encam','created_at' => now(),'updated_at' => now()],
                ['permission' => 'profiles','created_at' => now(),'updated_at' => now()],
                ['permission' => 'relacao_agressor','created_at' => now(),'updated_at' => now()],
                ['permission' => 'reside_com','created_at' => now(),'updated_at' => now()],
                ['permission' => 'servico','created_at' => now(),'updated_at' => now()],
                ['permission' => 'sit_moradia','created_at' => now(),'updated_at' => now()],
                ['permission' => 'tipo_agressor','created_at' => now(),'updated_at' => now()],
                ['permission' => 'tipo_violencia','created_at' => now(),'updated_at' => now()],
                ['permission' => 'tp_atendimento','created_at' => now(),'updated_at' => now()],
                ['permission' => 'tp_viol_fisica','created_at' => now(),'updated_at' => now()],
                ['permission' => 'tp_viol_psico','created_at' => now(),'updated_at' => now()],
                ['permission' => 'tp_viol_sexual','created_at' => now(),'updated_at' => now()],
                ['permission' => 'users','created_at' => now(),'updated_at' => now()],
            ]);
    }

    public function down()
    {
        DB::table('permissions')->where('permission','acao_rel_med')->delete();
        DB::table('permissions')->where('permission','atendimento')->delete();
        DB::table('permissions')->where('permission','aval_risc_int')->delete();
        DB::table('permissions')->where('permission','caract_violencia')->delete();
        DB::table('permissions')->where('permission','escolaridade')->delete();
        DB::table('permissions')->where('permission','estado')->delete();
        DB::table('permissions')->where('permission','estado_civil')->delete();
        DB::table('permissions')->where('permission','etnia')->delete();
        DB::table('permissions')->where('permission','failed_jobs')->delete();
        DB::table('permissions')->where('permission','for_busc_serv')->delete();
        DB::table('permissions')->where('permission','grau_violencia')->delete();
        DB::table('permissions')->where('permission','inst_encaminha')->delete();
        DB::table('permissions')->where('permission','local_atend')->delete();
        DB::table('permissions')->where('permission','mulher')->delete();
        DB::table('permissions')->where('permission','municipio')->delete();
        DB::table('permissions')->where('permission','org_acionado')->delete();
        DB::table('permissions')->where('permission','ori_sexual')->delete();
        DB::table('permissions')->where('permission','password_resets')->delete();
        DB::table('permissions')->where('permission','permissions')->delete();
        DB::table('permissions')->where('permission','personal_access_tokens')->delete();
        DB::table('permissions')->where('permission','prof_resp_encam')->delete();
        DB::table('permissions')->where('permission','profiles')->delete();
        DB::table('permissions')->where('permission','relacao_agressor')->delete();
        DB::table('permissions')->where('permission','reside_com')->delete();
        DB::table('permissions')->where('permission','servico')->delete();
        DB::table('permissions')->where('permission','sit_moradia')->delete();
        DB::table('permissions')->where('permission','tipo_agressor')->delete();
        DB::table('permissions')->where('permission','tipo_violencia')->delete();
        DB::table('permissions')->where('permission','tp_atendimento')->delete();
        DB::table('permissions')->where('permission','tp_viol_fisica')->delete();
        DB::table('permissions')->where('permission','tp_viol_psico')->delete();
        DB::table('permissions')->where('permission','tp_viol_sexual')->delete();
        DB::table('permissions')->where('permission','users')->delete();
    }

};

