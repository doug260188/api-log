<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() {
        $id_profile_admin = DB::table('profiles')->where('nome','Admin')->select('id')->first()->id;
        DB::table('profiles_permissions')->insert([
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','acao_rel_med')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','atendimento')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','aval_risc_int')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','caract_violencia')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','escolaridade')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','estado')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','estado_civil')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','etnia')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','failed_jobs')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','for_busc_serv')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','grau_violencia')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','inst_encaminha')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','local_atend')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','mulher')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','municipio')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','org_acionado')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','ori_sexual')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','password_resets')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','permissions')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','personal_access_tokens')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','prof_resp_encam')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','profiles')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','relacao_agressor')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','reside_com')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','servico')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','sit_moradia')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','tipo_agressor')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','tipo_violencia')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','tp_atendimento')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','tp_viol_fisica')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','tp_viol_psico')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','tp_viol_sexual')->select('id')->first()->id,
            ],
            [
                'profiles_id' => $id_profile_admin,
                'permissions_id' => DB::table('permissions')->where('permission','users')->select('id')->first()->id,
            ],
            ]);
    }

    public function down()
    {
        $id_profile_admin = DB::table('profiles')->where('nome','Admin')->select('id')->first()->id;
        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','acao_rel_med')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','atendimento')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','aval_risc_int')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','caract_violencia')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','escolaridade')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','estado')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','estado_civil')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','etnia')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','failed_jobs')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','for_busc_serv')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','grau_violencia')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','inst_encaminha')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','local_atend')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','mulher')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','municipio')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','org_acionado')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','ori_sexual')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','password_resets')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','permissions')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','personal_access_tokens')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','prof_resp_encam')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','profiles')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','relacao_agressor')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','reside_com')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','servico')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','sit_moradia')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','tipo_agressor')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','tipo_violencia')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','tp_atendimento')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','tp_viol_fisica')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','tp_viol_psico')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','tp_viol_sexual')->select('id')->first()->id)
        ->delete();

        DB::table('profiles_permissions')
        ->where('profiles_id',$id_profile_admin)
        ->where('permissions_id',DB::table('permissions')->where('permission','users')->select('id')->first()->id)
        ->delete();

    }

};

