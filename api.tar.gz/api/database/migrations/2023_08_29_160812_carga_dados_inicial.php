<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() {

        // DADOS PARA CADASTRO DA MULHER
        DB::table('ori_sexual')->insert([
            ['orientacao' => 'Heterossexual','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['orientacao' => 'Homossexual','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['orientacao' => 'Bissexual','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['orientacao' => 'Pansexual','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['orientacao' => 'Assexual','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['orientacao' => 'Outro','ativo' => true,'created_at' => now(),'updated_at' => now()],
        ]);


        DB::table('etnia')->insert([
            ['etnia' => 'Branca','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['etnia' => 'Preta','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['etnia' => 'Parda','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['etnia' => 'Amarela','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['etnia' => 'Indígena','ativo' => true,'created_at' => now(),'updated_at' => now()],
        ]);


        DB::table('estado_civil')->insert([
            ['estado_civil' => 'Solteira','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['estado_civil' => 'Casada','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['estado_civil' => 'Viúva','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['estado_civil' => 'Separada Judicialmente','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['estado_civil' => 'União consensual','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['estado_civil' => 'Ignorado','ativo' => true,'created_at' => now(),'updated_at' => now()],
        ]);

        
        DB::table('escolaridade')->insert([
            ['escolaridade' => 'Ensino fundamental incompleto','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['escolaridade' => 'Ensino fundamental completo','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['escolaridade' => 'Ensino médio incompleto','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['escolaridade' => 'Ensino médio completo','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['escolaridade' => 'Ensino técnico/profissionalizante','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['escolaridade' => 'Ensino superior incompleto','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['escolaridade' => 'Ensino superior completo','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['escolaridade' => 'Pós-graduação (especialização, mestrado, doutorado)','ativo' => true,'created_at' => now(),'updated_at' => now()],
        ]);


        DB::table('reside_com')->insert([
            ['reside_com' => 'Sozinha(o)','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['reside_com' => 'Com parceiro(a) ou cônjuge','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['reside_com' => 'Com filhos(as)','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['reside_com' => 'Com familiares (pais, irmãos, avós etc.)','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['reside_com' => 'Com colegas de moradia','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['reside_com' => 'Com amigos(as)','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['reside_com' => 'Outros','ativo' => true,'created_at' => now(),'updated_at' => now()],
        ]);


        DB::table('servico')->insert([
            ['servico' => 'Centro de Saúde','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['servico' => 'Creche','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['servico' => 'Escola','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['servico' => 'Núcleo de Classificação Profissional','ativo' => true,'created_at' => now(),'updated_at' => now()],
        ]);


        DB::table('sit_moradia')->insert([
            ['situacao' => 'Própria','chave' => null,'ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['situacao' => 'Alugada','chave' => null,'ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['situacao' => 'Cedida ou "de favor"','chave' => 3,'ativo' => true,'created_at' => now(),'updated_at' => now()],
        ]);



        // DADOS PARA CADASTRO DE ATENDIMENTO
        DB::table('for_busc_serv')->insert([
            ['forma_busca' => 'Espontânea','chave' => 1,'ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['forma_busca' => 'Encaminhada','chave' => 2,'ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['forma_busca' => 'Outros','chave' => 3,'ativo' => true,'created_at' => now(),'updated_at' => now()],
        ]);


        DB::table('inst_encaminha')->insert([
            ['tipo_instituição' => 'Saúde','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_instituição' => 'Segurança','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_instituição' => 'Assistência Social','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_instituição' => 'Justiça','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_instituição' => 'Educação','ativo' => true,'created_at' => now(),'updated_at' => now()],
        ]);


        DB::table('prof_resp_encam')->insert([
            ['tipo_prof' => 'Advogado','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_prof' => 'Agente Comunitário de Saúde','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_prof' => 'Agente Cultural','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_prof' => 'Assistência Social','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_prof' => 'Auxiliar de Enfermagem','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_prof' => 'Conselheiro Tutelar','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_prof' => 'Delegada da Mulher','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_prof' => 'Dentista','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_prof' => 'Diretor de Escola','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_prof' => 'Educador Social','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_prof' => 'Educador Social de Rua','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_prof' => 'Enfermeiro','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_prof' => 'Guarda Municipal','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_prof' => 'Médico','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_prof' => 'Monitor','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_prof' => 'Orientador Pedagógico','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_prof' => 'Psicólogo','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_prof' => 'Policial Militar','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_prof' => 'Policial Civil','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_prof' => 'Professor','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_prof' => 'Outros','ativo' => true,'created_at' => now(),'updated_at' => now()],
        ]);


        DB::table('caract_violencia')->insert([
            ['caracteristica' => 'Doméstica','chave' => 1,'ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['caracteristica' => 'No Trabalho','chave' => null,'ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['caracteristica' => 'Na Rua','chave' => null,'ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['caracteristica' => 'Circunstancial','chave' => null,'ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['caracteristica' => 'Continuada','chave' => null,'ativo' => true,'created_at' => now(),'updated_at' => now()],

        ]);

        
        DB::table('tipo_agressor')->insert([
            ['tipo' => 'Conhecido','chave' => 1,'ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo' => 'Desconhecido','chave' => null,'ativo' => true,'created_at' => now(),'updated_at' => now()],

        ]);


        DB::table('relacao_agressor')->insert([
            ['rela_par_agressor' => 'Cônjuge ou companheiro(a)','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['rela_par_agressor' => 'Ex-cônjuge ou ex-companheiro(a)','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['rela_par_agressor' => 'Namorado(a) ou parceiro(a) romântico(a)','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['rela_par_agressor' => 'Ex-namorado(a) ou ex-parceiro(a) romântico(a)','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['rela_par_agressor' => 'Pai ou Mãe','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['rela_par_agressor' => 'Filho(a)','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['rela_par_agressor' => 'Irmão(a)','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['rela_par_agressor' => 'Outro Parente','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['rela_par_agressor' => 'Amigo(a)','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['rela_par_agressor' => 'Colega de trabalho','ativo' => true,'created_at' => now(),'updated_at' => now()],
        ]);


        DB::table('tipo_violencia')->insert([
            ['tipo' => 'Violência Física','chave' => 1,'ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo' => 'Violência Sexual','chave' => 2,'ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo' => 'Violência Psicológica','chave' => 3,'ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo' => 'Violência Patrimonial','chave' => 4,'ativo' => true,'created_at' => now(),'updated_at' => now()],
        ]);


        DB::table('grau_violencia')->insert([
            ['grau' => 'Leve','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['grau' => 'Grave','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['grau' => 'Gravíssima','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['grau' => 'Incapacitante','ativo' => true,'created_at' => now(),'updated_at' => now()],
        ]);


        DB::table('tp_viol_fisica')->insert([
            ['tipo_viol_fisica' => 'Queimadura','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_viol_fisica' => 'Enforcamento','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_viol_fisica' => 'Sufocamento','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_viol_fisica' => 'Estrangulamento','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_viol_fisica' => 'Tiro','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_viol_fisica' => 'Afogamento','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_viol_fisica' => 'Facada','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_viol_fisica' => 'Paulada','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_viol_fisica' => 'Soco','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_viol_fisica' => 'Chute','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_viol_fisica' => 'Tapa','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_viol_fisica' => 'Empurrão','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_viol_fisica' => 'Puxão de Cabelo','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_viol_fisica' => 'Outra','ativo' => true,'created_at' => now(),'updated_at' => now()],
        ]);


        DB::table('tp_atendimento')->insert([
            ['tipo_atendimento' => 'Atendimento Médico','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_atendimento' => 'Internação','ativo' => true,'created_at' => now(),'updated_at' => now()],
        ]);


        DB::table('acao_rel_med')->insert([
            ['acao' => 'Já Descumpriu Medida Protetiva Anteriormente','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['acao' => 'Cumpre Medida Proteriva','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['acao' => 'Não Possui Medida Proteriva','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['acao' => 'Não Sei','ativo' => true,'created_at' => now(),'updated_at' => now()],
        ]);

        
        DB::table('tp_viol_sexual')->insert([
            ['tipo_viol_sexual' => 'Estupro','chave' => 1,'ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_viol_sexual' => 'Atentado Violento ao Pudor','chave' => 2,'ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_viol_sexual' => 'Tráfico','chave' => null,'ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_viol_sexual' => 'Exploração Sexual Comercial','chave' => null,'ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_viol_sexual' => 'Assédio Sexual','chave' => null,'ativo' => true,'created_at' => now(),'updated_at' => now()],
        ]);


        DB::table('tp_viol_psico')->insert([
            ['tipo_viol_psico' => 'Intimidação por (ex)Parceiro(a) Íntimo(a)','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_viol_psico' => 'Assédio Moral','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_viol_psico' => 'Difamação','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['tipo_viol_psico' => 'Injúria','ativo' => true,'created_at' => now(),'updated_at' => now()],
        ]);


        DB::table('aval_risc_int')->insert([
            ['aval_risc_int' => 'Leve','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['aval_risc_int' => 'Moderado','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['aval_risc_int' => 'Grave','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['aval_risc_int' => 'Gravíssima','ativo' => true,'created_at' => now(),'updated_at' => now()],
        ]);


        DB::table('org_acionado')->insert([
            ['org_acionado' => 'Delegacia Especializada de Atendimento à Mulher (DEAM)','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['org_acionado' => 'Casa de Amparo às Mulheres Vítimas de Violência Doméstica','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['org_acionado' => 'Defensoria Pública','ativo' => true,'created_at' => now(),'updated_at' => now()],
            ['org_acionado' => 'Ministério Público','ativo' => true,'created_at' => now(),'updated_at' => now()],
        ]);

    }

    public function down()
    {
        DB::table('ori_sexual')->delete();
        DB::table('etnia')->delete();
        DB::table('estado_civil')->delete();
        DB::table('escolaridade')->delete();
        DB::table('reside_com')->delete();
        DB::table('servico')->delete();
        DB::table('sit_moradia')->delete();
        DB::table('for_busc_serv')->delete();
        DB::table('inst_encaminha')->delete();
        DB::table('prof_resp_encam')->delete();
        DB::table('caract_violencia')->delete();
        DB::table('tipo_agressor')->delete();
        DB::table('relacao_agressor')->delete();
        DB::table('tipo_violencia')->delete();
        DB::table('grau_violencia')->delete();
        DB::table('tp_viol_fisica')->delete();
        DB::table('tp_atendimento')->delete();
        DB::table('acao_rel_med')->delete();
        DB::table('tp_viol_sexual')->delete();
        DB::table('tp_viol_psico')->delete();
        DB::table('aval_risc_int')->delete();
        DB::table('org_acionado')->delete();

    }

};

