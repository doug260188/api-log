<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() {
        Schema::create('atendimento_tipo_violencia', function (Blueprint $table) {
            $table->id();
            $table->foreignId('atendimento_id')->constrained('atendimento');
            $table->foreignId('tipo_violencia_id')->constrained('tipo_violencia');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {
        Schema::dropIfExists('atendimento_tipo_violencia');
    }
};

