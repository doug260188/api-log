<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() {
        Schema::create('mulher', function (Blueprint $table) {
            $table->id();
            $table->string('nome', 500);
            $table->date('data_nascimento')->nullable();
            $table->string('rg', 100)->nullable();
            $table->string('cpf', 14)->nullable();
            $table->string('nis', 11)->nullable();
            $table->boolean('trabalha')->nullable();
            $table->boolean('remunerado')->nullable();
            $table->string('ocupacao', 500)->nullable();
            $table->foreignId('escolaridade')->nullable()->constrained('escolaridade');
            $table->foreignId('orientacao')->nullable()->constrained('ori_sexual');
            $table->foreignId('etnia')->nullable()->constrained('etnia');
            $table->foreignId('estado_civil')->nullable()->constrained('estado_civil');
            $table->boolean('possui_filhos')->nullable();
            $table->boolean('dorme_rua')->nullable();
            $table->foreignId('resido_com')->nullable()->constrained('reside_com');
            $table->foreignId('sit_moradia')->nullable()->constrained('sit_moradia');
            $table->string('quem_cedeu_moradia', 200)->nullable();
            $table->string('cep', 10)->nullable();
            $table->string('endereco', 500)->nullable();
            $table->string('numero', 200)->nullable();
            $table->string('complemento', 200)->nullable();
            $table->string('bairro', 200)->nullable();
            $table->foreignId('estado')->nullable()->constrained('estado');
            $table->foreignId('municipio')->nullable()->constrained('municipio');
            $table->longText('outro_end_loca')->nullable();
            $table->boolean('nacionalidade_br')->nullable();
            $table->foreignId('estado_nascimento')->nullable()->constrained('estado');
            $table->foreignId('municipio_nascimento')->nullable()->constrained('municipio');
            $table->string('pais_cidade_estrangeiro', 200)->nullable();
            $table->decimal('tempo_reside_mun', 4,2)->nullable();
            $table->boolean('port_deficiencia')->nullable();
            $table->string('tipo_deficiencia', 500)->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {
        Schema::dropIfExists('mulher');
    }
};

