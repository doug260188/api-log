<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() {
        Schema::create('atendimento', function (Blueprint $table) {
            $table->id();
            $table->foreignId('mulher')->nullable()->constrained('mulher');
            $table->foreignId('local_atend')->nullable()->constrained('local_atend');
            $table->date('data_ocorrido')->nullable();
            $table->longText('desc_sumaria')->nullable();
            $table->foreignId('for_busc_serv')->nullable()->constrained('for_busc_serv');
            $table->string('como_soube', 500)->nullable();
            $table->foreignId('inst_encaminha')->nullable()->constrained('inst_encaminha');
            $table->string('nome_instituicao', 500)->nullable();
            $table->string('contato_instituicao', 500)->nullable();
            $table->foreignId('prof_resp_encam')->nullable()->constrained('prof_resp_encam');
            $table->string('qual_out_form', 500)->nullable();
            $table->foreignId('tipo_agressor')->nullable()->constrained('tipo_agressor');
            $table->foreignId('relacao_agressor')->nullable()->constrained('relacao_agressor');
            $table->foreignId('grau_violencia_fis')->nullable()->constrained('grau_violencia');
            $table->boolean('necessitou_atendimento')->nullable();
            $table->foreignId('tp_atendimento')->nullable()->constrained('tp_atendimento');
            $table->boolean('regis_policial')->nullable();
            $table->boolean('form_medida_prot')->nullable();
            $table->foreignId('acao_rel_med')->nullable()->constrained('acao_rel_med');
            $table->boolean('atend_viol_sex')->nullable();
            $table->boolean('viol_sex_men_horas')->nullable();
            $table->boolean('negligencia')->nullable();
            $table->boolean('dep_finan')->nullable();
            $table->boolean('aceita_abrig_temp')->nullable();
            $table->boolean('concord_encami')->nullable();
            $table->longText('motivo_n_con_enc')->nullable();
            $table->date('data_atendimento')->nullable();
            $table->foreignId('aval_risc_int')->nullable()->constrained('aval_risc_int');
            $table->longText('providencia')->nullable();
            $table->boolean('elab_psp')->nullable();
            $table->longText('encaminha')->nullable();
            $table->foreignId('usuario_cadastro')->nullable()->constrained('users');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {
        Schema::dropIfExists('atendimento');
    }
};

