<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() {
        Schema::create('mulher_muni_anterior', function (Blueprint $table) {
            $table->id();
            $table->foreignId('mulher_id')->constrained('mulher');
            $table->foreignId('muni_anterior_id')->constrained('muni_anterior');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {
        Schema::dropIfExists('mulher_muni_anterior');
    }
};

