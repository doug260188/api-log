<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Hash;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() {
        DB::table('permissions')->insert(
            [
                ['permission' => 'profiles', 'created_at' => now(), 'updated_at' => now() ],
                ['permission' => 'users', 'created_at' => now(), 'updated_at' => now()],
                ['permission' => 'auditoria', 'created_at' => now(), 'updated_at' => now()],
            ]);

        DB::table('profiles')->insert(
            [
                ['nome' => 'Admin', 'created_at' => now(), 'updated_at' => now()],
            ]);

        $id_profile_admin = DB::table('profiles')->where('nome','Admin')->select('id')->first()->id;
        DB::table('profiles_permissions')->insert(
            [
                [
                    'profiles_id' => $id_profile_admin,
                    'permissions_id' => DB::table('permissions')->where('permission','profiles')->select('id')->first()->id,
                ],
                [
                    'profiles_id' => $id_profile_admin,
                    'permissions_id' => DB::table('permissions')->where('permission','users')->select('id')->first()->id,
                ],
                [
                    'profiles_id' => $id_profile_admin,
                    'permissions_id' => DB::table('permissions')->where('permission','auditoria')->select('id')->first()->id,
                ]
            ]);

        DB::table('users')->insert(
            [
                'nome' => 'admin',
                'email' => 'admin@admin.com',
                'cargo_funcao' => 'Admin do Sistema',
                'password' => bcrypt('123456789'),
                'ativo' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ]
        );

        DB::table('users_profiles')->insert(
            [
                'users_id' => DB::table('users')->where('nome','admin')->select('id')->first()->id,
                'profiles_id' => $id_profile_admin,
            ]
        );
    }

    public function down()
    {
        DB::table('users_profiles')->delete();
        DB::table('users')->delete();
        DB::table('profiles_permissions')->delete();
        DB::table('profiles')->delete();
        DB::table('permissions')->delete();
    }

};

