<?php

namespace Database\Seeders;

use App\Models\AcaoRelMed;
use App\Models\Atendimento;
use App\Models\AvalRiscInt;
use App\Models\Escolaridade;
use App\Models\Estado;
use App\Models\EstadoCivil;
use App\Models\Etinia;
use App\Models\Filho;
use App\Models\ForBuscServ;
use App\Models\GrauViolencia;
use App\Models\InstEncaminha;
use App\Models\LocalAtend;
use App\Models\Mulher;
use App\Models\MuniAnterior;
use App\Models\Municipio;
use App\Models\Ori_sexual;
use App\Models\ProfRespEncam;
use App\Models\RelacaoAgressor;
use App\Models\ResideCom;
use App\Models\ServicoUtilizado;
use App\Models\SitMoradia;
use App\Models\Telefone;
use App\Models\TipoAgressor;
use App\Models\TpAtendimento;
use App\Models\User;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Collection;

class DevSeeder extends Seeder
{
    /**
     * Executa os Seeds para o Desenvolvimento .
     *
     * @return void
     */
    public function run()
    {
        $this->command->info('Executando DevSeeder');
        $this->createUser();
        $this->createMulher();
        $this->createLocalAtend();
        $this->createAtendimento();
    }

    private function createUser()
    {
        $obj = User::create([
            'nome' => 'Tatiane Cristiane Isabella Galvão',
            'email' => 'tatiane_cristiane_galvao@teste.com',
            'cargo_funcao' => 'Atendente',
            'password' => bcrypt('123456789'),
            'ativo' => true,
        ]);

        $obj->Profile()->sync([1]);

        $obj = User::create([
            'nome' => 'Rafael Manuel Ryan Ribeiro',
            'email' => 'rafael_manuel@teste.com',
            'cargo_funcao' => 'Advogada da Defensoria Pública',
            'password' => bcrypt('123456789'),
            'ativo' => true,
        ]);

        $obj->Profile()->sync([1]);


        $this->command->info('User Criados');
    }

    

    

    private function createMulher()
    {
        $obj = Mulher::create([
            'nome' => 'Sophia Agatha Laís Pereira',
            'data_nascimento' => '1988-02-01',
            'rg' => '19.211.535-2',
            'cpf' => '926.622.331-09',
            'nis' => '37414972104',
            'trabalha' => true,
            'remunerado' => true,
            'ocupacao' => 'Vendedora',
            'escolaridade' => Escolaridade::where('id','=', 2)->first()->id,
            'orientacao' => Ori_sexual::where('id','=', 1)->first()->id,
            'etnia' => Etinia::where('id','=', 2)->first()->id,
            'estado_civil' => EstadoCivil::where('id','=', 1)->first()->id,
            'possui_filhos' => true,
            'dorme_rua' => false,
            'resido_com' => ResideCom::where('id','=', 1)->first()->id,
            'sit_moradia' => SitMoradia::where('id','=', 1)->first()->id,
            'quem_cedeu_moradia' => NULL,
            'cep' => '78043-128',
            'endereco' => 'Rua das Rosas',
            'numero' => '479',
            'complemento' => NULL,
            'bairro' => 'Jardim Cuiabá',
            'estado' => Estado::where('id','=', 11)->first()->id,
            'municipio' => Municipio::where('id','=', 5220)->first()->id,
            'outro_end_loca' => NULL,
            'nacionalidade_br' => true,
            'estado_nascimento' => Estado::where('id','=', 11)->first()->id,
            'municipio_nascimento' => Municipio::where('id','=', 5220)->first()->id,
            'pais_cidade_estrangeiro' => NULL,
            'tempo_reside_mun' => 3.5,
            'port_deficiencia' => false,
            'tipo_deficiencia' => NULL,
        ]);


        $colecao_filhos = collect([
                            ['idade' =>12,
                             'fillho_reside_com' =>1,
                             'port_deficiencia' =>false]
        ]);

        foreach($colecao_filhos as $item){
            $obj_preencher = $item;
            $objitem = Filho::create($obj_preencher);
            $obj->Filho()->attach($objitem);
        }

        $colecao_telefone = collect([
                            ['telefone' =>'(65) 3698-5249'],
                             ['telefone' =>'(65) 99121-7026']
        ]);

        foreach($colecao_telefone as $item){
            $obj_preencher = $item;
            $objitem = Telefone::create($obj_preencher);
            $obj->Telefone()->attach($objitem);
        }

        $colecao_muni_anterior = collect([
                            ['estado' =>22,
                             'municipio' =>17],
                             ['estado' =>14,
                             'municipio' =>276]
        ]);

        foreach($colecao_muni_anterior as $item){
            $obj_preencher = $item;
            $objitem = MuniAnterior::create($obj_preencher);
            $obj->MuniAnterior()->attach($objitem);
        }

        $colecao_servico_utilizado = collect([
                            ['servico' =>1,
                             'nome' =>'Centro de Saúde Dr Oscarino de Campos Borges']
        ]);

        foreach($colecao_servico_utilizado as $item){
            $obj_preencher = $item;
            $objitem = ServicoUtilizado::create($obj_preencher);
            $obj->ServicoUtilizado()->attach($objitem);
        }

        $obj = Mulher::create([
            'nome' => 'Clarice Lorena Assunção',
            'data_nascimento' => '1996-03-04',
            'rg' => '47.502.312-2',
            'cpf' => '933.407.401-94',
            'nis' => '',
            'trabalha' => false,
            'remunerado' => false,
            'ocupacao' => 'Nenhuma',
            'escolaridade' => Escolaridade::where('id','=', 1)->first()->id,
            'orientacao' => Ori_sexual::where('id','=', 1)->first()->id,
            'etnia' => Etinia::where('id','=', 3)->first()->id,
            'estado_civil' => EstadoCivil::where('id','=', 1)->first()->id,
            'possui_filhos' => true,
            'dorme_rua' => true,
            'resido_com' => NULL,
            'sit_moradia' => NULL,
            'quem_cedeu_moradia' => NULL,
            'cep' => '',
            'endereco' => '',
            'numero' => '',
            'complemento' => NULL,
            'bairro' => '',
            'estado' => NULL,
            'municipio' => NULL,
            'outro_end_loca' => NULL,
            'nacionalidade_br' => false,
            'estado_nascimento' => NULL,
            'municipio_nascimento' => NULL,
            'pais_cidade_estrangeiro' => NULL,
            'tempo_reside_mun' => 5.5,
            'port_deficiencia' => true,
            'tipo_deficiencia' => NULL,
        ]);


        $colecao_filhos = collect([
                            ['idade' =>4,
                             'fillho_reside_com' =>2,
                             'port_deficiencia' =>false],
                             ['idade' =>13,
                             'fillho_reside_com' =>3,
                             'port_deficiencia' =>true]
        ]);

        foreach($colecao_filhos as $item){
            $obj_preencher = $item;
            $objitem = Filho::create($obj_preencher);
            $obj->Filho()->attach($objitem);
        }

        $colecao_telefone = collect([
                            ['telefone' =>'(65) 99866-6767']
        ]);

        foreach($colecao_telefone as $item){
            $obj_preencher = $item;
            $objitem = Telefone::create($obj_preencher);
            $obj->Telefone()->attach($objitem);
        }

        $colecao_muni_anterior = collect([
                            ['estado' =>27,
                             'municipio' =>424],
                             ['estado' =>16,
                             'municipio' =>4137],
                             ['estado' =>8,
                             'municipio' =>3147]
        ]);

        foreach($colecao_muni_anterior as $item){
            $obj_preencher = $item;
            $objitem = MuniAnterior::create($obj_preencher);
            $obj->MuniAnterior()->attach($objitem);
        }

        $colecao_servico_utilizado = collect([
                            ['servico' =>1,
                             'nome' =>'Centro de Saúde Dr Oscarino de Campos Borges'],
                             ['servico' =>2,
                             'nome' =>'Creche Municipal Josefa Da Silva Parente']
        ]);

        foreach($colecao_servico_utilizado as $item){
            $obj_preencher = $item;
            $objitem = ServicoUtilizado::create($obj_preencher);
            $obj->ServicoUtilizado()->attach($objitem);
        }


        $this->command->info('Mulher Criados');
    }


    private function createLocalAtend()
    {
        $obj = LocalAtend::create([
            'nome_local' => 'Casa de Amparo às Mulheres Vítimas de Violência Doméstica',
            'cep' => '78005-580',
            'endereco' => 'Palácio Alencastro',
            'numero' => '158',
            'complemento' => '7 andar',
            'bairro' => 'Centro',
            'estado' => Estado::where('id','=', 11)->first()->id,
            'municipio' => Municipio::where('id','=', 5220)->first()->id,
            'telefone' => '(65) 3555-1224',
            'fax' => NULL,
            'email' => NULL,
        ]);


        $obj = LocalAtend::create([
            'nome_local' => 'Casa de Apoio Master',
            'cep' => '78048-615',
            'endereco' => 'R. Alta Floresta',
            'numero' => '20',
            'complemento' => '',
            'bairro' => 'Consil',
            'estado' => Estado::where('id','=', 11)->first()->id,
            'municipio' => Municipio::where('id','=', 5220)->first()->id,
            'telefone' => '(65) 99669-7566',
            'fax' => NULL,
            'email' => NULL,
        ]);



        $this->command->info('LocalAtend Criados');
    }

    private function createAtendimento()
    {
        $obj = Atendimento::create([
            'mulher' => Mulher::where('id','=', 1)->first()->id,
            'local_atend' => LocalAtend::where('id','=', 1)->first()->id,
            'data_ocorrido' => '2023-08-29',
            'desc_sumaria' => 'Sophia, 35 anos, relatou que foi agredida fisicamente pelo marido, João, 40 anos. O casal está casado há 13 anos e tem um filhos, de 12 . A agressão ocorreu na residência do casal, após uma discussão sobre o comportamento de João.',
            'for_busc_serv' => ForBuscServ::where('id','=', 1)->first()->id,
            'como_soube' => 'Viu um cartaz em um posto de saúde',
            'inst_encaminha' => NULL,
            'nome_instituicao' => NULL,
            'contato_instituicao' => NULL,
            'prof_resp_encam' => NULL,
            'qual_out_form' => NULL,
            'tipo_agressor' => TipoAgressor::where('id','=', 1)->first()->id,
            'relacao_agressor' => RelacaoAgressor::where('id','=', 1)->first()->id,
            'grau_violencia_fis' => GrauViolencia::where('id','=', 1)->first()->id,
            'necessitou_atendimento' => true,
            'tp_atendimento' => TpAtendimento::where('id','=', 1)->first()->id,
            'regis_policial' => true,
            'form_medida_prot' => true,
            'acao_rel_med' => AcaoRelMed::where('id','=', 1)->first()->id,
            'atend_viol_sex' => false,
            'viol_sex_men_horas' => false,
            'negligencia' => false,
            'dep_finan' => true,
            'aceita_abrig_temp' => true,
            'concord_encami' => false,
            'motivo_n_con_enc' => 'A vítima não concordou com o encaminhamento para o abrigo temporário, pois não quer se separar dos filhos.',
            'aval_risc_int' => AvalRiscInt::where('id','=', 1)->first()->id,
            'providencia' => 'Foi elaborado um plano de segurança pessoal para Sophia, com medidas como a mudança temporária de residência e o acompanhamento psicológico. Foi solicitado à Polícia Militar a prisão preventiva de João.',
            'elab_psp' => true,
            'data_atendimento' => '2023-08-30',
            'encaminha' => 'Atendimento médico, encaminhamento para abrigo temporário, acompanhamento psicológico, elaboração de plano de segurança pessoal, solicitação de prisão preventiva do agressor',
            'usuario_cadastro' => User::where('id','=', 1)->first()->id,
        ]);

        $obj->CaractViolencia()->sync([1]);
        $obj->TipoViolencia()->sync([1,2,3]);
        $obj->TpViolFisica()->sync([1]);
        $obj->TpViolSexual()->sync([1]);
        $obj->TpViolPsico()->sync([1]);
        $obj->OrgAcionado()->sync([1,2]);

        $obj = Atendimento::create([
            'mulher' => Mulher::where('id','=', 2)->first()->id,
            'local_atend' => LocalAtend::where('id','=', 1)->first()->id,
            'data_ocorrido' => '2023-08-30',
            'desc_sumaria' => 'Clarice, 25 anos, relatou que foi vítima de violência sexual por um desconhecido. O fato ocorreu na rua, enquanto ela voltava do trabalho.',
            'for_busc_serv' => ForBuscServ::where('id','=', 2)->first()->id,
            'como_soube' => '',
            'inst_encaminha' => InstEncaminha::where('id','=', 1)->first()->id,
            'nome_instituicao' => NULL,
            'contato_instituicao' => NULL,
            'prof_resp_encam' => ProfRespEncam::where('id','=', 2)->first()->id,
            'qual_out_form' => NULL,
            'tipo_agressor' => TipoAgressor::where('id','=', 2)->first()->id,
            'relacao_agressor' => NULL,
            'grau_violencia_fis' => NULL,
            'necessitou_atendimento' => NULL,
            'tp_atendimento' => NULL,
            'regis_policial' => false,
            'form_medida_prot' => false,
            'acao_rel_med' => NULL,
            'atend_viol_sex' => true,
            'viol_sex_men_horas' => true,
            'negligencia' => true,
            'dep_finan' => false,
            'aceita_abrig_temp' => false,
            'concord_encami' => true,
            'motivo_n_con_enc' => '',
            'aval_risc_int' => AvalRiscInt::where('id','=', 2)->first()->id,
            'providencia' => 'Foi realizado o encaminhamento de Clarice para um hospital para receber atendimento médico e psicológico. Foi solicitado à Polícia Civil a investigação do caso.',
            'elab_psp' => false,
            'data_atendimento' => '2023-08-30',
            'encaminha' => 'Atendimento médico, encaminhamento para hospital, acompanhamento psicológico, solicitação de investigação do caso',
            'usuario_cadastro' => User::where('id','=', 1)->first()->id,
        ]);

        $obj->CaractViolencia()->sync([2]);
        $obj->TipoViolencia()->sync([2]);
        $obj->TpViolFisica()->sync(NULL);
        $obj->TpViolSexual()->sync([1,2]);
        $obj->TpViolPsico()->sync([1,2]);
        $obj->OrgAcionado()->sync([2]);


        $this->command->info('Atendimento Criados');
    }

}

