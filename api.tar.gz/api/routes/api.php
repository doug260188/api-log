<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\PermissionController;
use App\Http\Controllers\UserController;

use App\Http\Controllers\AtendimentoController;
use App\Http\Controllers\AcaoRelMedController;
use App\Http\Controllers\AvalRiscIntController;
use App\Http\Controllers\CaractViolenciaController;
use App\Http\Controllers\CEPController;
use App\Http\Controllers\DashBoardController;
use App\Http\Controllers\EscolaridadeController;
use App\Http\Controllers\EstadoController;
use App\Http\Controllers\EstadoCivilController;
use App\Http\Controllers\EtiniaController;
use App\Http\Controllers\ForBuscServController;
use App\Http\Controllers\GrauViolenciaController;
use App\Http\Controllers\InstEncaminhaController;
use App\Http\Controllers\LocalAtendController;
use App\Http\Controllers\MulherController;
use App\Http\Controllers\MunicipioController;
use App\Http\Controllers\OrgAcionadoController;
use App\Http\Controllers\Ori_sexualController;
use App\Http\Controllers\ProfRespEncamController;
use App\Http\Controllers\RelacaoAgressorController;
use App\Http\Controllers\ResideComController;
use App\Http\Controllers\ServicoController;
use App\Http\Controllers\SitMoradiaController;
use App\Http\Controllers\TipoAgressorController;
use App\Http\Controllers\TipoViolenciaController;
use App\Http\Controllers\TpAtendimentoController;
use App\Http\Controllers\TpViolFisicaController;
use App\Http\Controllers\TpViolPsicoController;
use App\Http\Controllers\TpViolSexualController;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\MailController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });


// Route::post('/register', [UserController::class, 'register']);
Route::post('/login', [AuthController::class, 'login']);
Route::post('/sendgrid', [MailController::class, 'sendGridMail']);

Route::post('/forgetPassword', [AuthController::class, 'forgetPassword']);
Route::post('/recoverPassword', [AuthController::class, 'recoverPassword']);

Route::group(['middleware' => ['auth:sanctum']], function () {

    Route::post('/logout',[AuthController::class, 'logout']);
    Route::get('/rota', [AuthController::class, 'rota']);

    Route::put('/update_password', [UserController::class, 'update_password']);

    Route::get('/listar_permissoes', [PermissionController::class, 'index']);
    Route::get('/minhas_permissoes', [PermissionController::class, 'my_permission']);

    Route::get('/dashboard', [DashBoardController::class, 'dashboard']);

    Route::group(['prefix' => 'profiles', 'controller' => ProfileController::class, 'middleware' => ['permission:profiles']], function () {
        Route::get('lov_permission', [PermissionController::class, 'index']);
        Route::get('/lov', 'lov');
        Route::get('/', 'index');
        Route::post('/', 'store');
        Route::get('/{id}', 'show');
        Route::put('/{id}', 'update');
        Route::delete('/{id}', 'destroy');
    });

     
    Route::group(['prefix' => 'users', 'middleware' => ['permission:users']], function () {
        Route::get('lov_profile', [ProfileController::class, 'lov']);
        Route::group(['controller' => UserController::class], function () {
            Route::get('/lov', 'lov');
            Route::get('/', 'index');
            Route::post('/', 'store');
            Route::get('/{id}', 'show');
            Route::put('/{id}', 'update');
            Route::delete('/{id}', 'destroy');
            Route::group(['middleware' => ['permission:auditoria']], function () {
                Route::get('/lista_audit_completa/{id}', 'lista_audit_completa');
                Route::get('/audit/{id_audit}', 'audit');
            });
        });
    });

    Route::group(['prefix'=>'ori_sexual','middleware' => ['permission:ori_sexual']], function () {
        Route::group(['controller'=>Ori_sexualController::class], function () {
            Route::get('/lov', 'lov');
            Route::get('/', 'index');
            Route::post('/', 'store');
            Route::get('/{id}', 'show');
            Route::put('/{id}', 'update');
            Route::delete('/{id}', 'destroy');
        });
    });


    Route::group(['prefix'=>'etnia','middleware' => ['permission:etnia']], function () {
        Route::group(['controller'=>EtiniaController::class], function () {
            Route::get('/lov', 'lov');
            Route::get('/', 'index');
            Route::post('/', 'store');
            Route::get('/{id}', 'show');
            Route::put('/{id}', 'update');
            Route::delete('/{id}', 'destroy');
        });
    });


    Route::group(['prefix'=>'estado_civil','middleware' => ['permission:estado_civil']], function () {
        Route::group(['controller'=>EstadoCivilController::class], function () {
            Route::get('/lov', 'lov');
            Route::get('/', 'index');
            Route::post('/', 'store');
            Route::get('/{id}', 'show');
            Route::put('/{id}', 'update');
            Route::delete('/{id}', 'destroy');
        });
    });


    Route::group(['prefix'=>'escolaridade','middleware' => ['permission:escolaridade']], function () {
        Route::group(['controller'=>EscolaridadeController::class], function () {
            Route::get('/lov', 'lov');
            Route::get('/', 'index');
            Route::post('/', 'store');
            Route::get('/{id}', 'show');
            Route::put('/{id}', 'update');
            Route::delete('/{id}', 'destroy');
        });
    });


    Route::group(['prefix'=>'reside_com','middleware' => ['permission:reside_com']], function () {
        Route::group(['controller'=>ResideComController::class], function () {
            Route::get('/lov', 'lov');
            Route::get('/', 'index');
            Route::post('/', 'store');
            Route::get('/{id}', 'show');
            Route::put('/{id}', 'update');
            Route::delete('/{id}', 'destroy');
        });
    });


    Route::group(['prefix'=>'estado','middleware' => ['permission:estado']], function () {
        Route::group(['controller'=>EstadoController::class], function () {
            Route::get('/lov', 'lov');
            Route::get('/', 'index');
            Route::post('/', 'store');
            Route::get('/{id}', 'show');
            Route::put('/{id}', 'update');
            Route::delete('/{id}', 'destroy');
        });
    });


    Route::group(['prefix'=>'municipio','middleware' => ['permission:municipio']], function () {
        Route::get('lov_estado', [EstadoController::class, 'lov']);
        Route::group(['controller'=>MunicipioController::class], function () {
            Route::get('/lov', 'lov');
            Route::get('/', 'index');
            Route::post('/', 'store');
            Route::get('/{id}', 'show');
            Route::put('/{id}', 'update');
            Route::delete('/{id}', 'destroy');
        });
    });


    Route::group(['prefix'=>'servico','middleware' => ['permission:servico']], function () {
        Route::group(['controller'=>ServicoController::class], function () {
            Route::get('/lov', 'lov');
            Route::get('/', 'index');
            Route::post('/', 'store');
            Route::get('/{id}', 'show');
            Route::put('/{id}', 'update');
            Route::delete('/{id}', 'destroy');
        });
    });


    Route::group(['prefix'=>'sit_moradia','middleware' => ['permission:sit_moradia']], function () {
        Route::group(['controller'=>SitMoradiaController::class], function () {
            Route::get('/lov', 'lov');
            Route::get('/', 'index');
            Route::post('/', 'store');
            Route::get('/{id}', 'show');
            Route::put('/{id}', 'update');
            Route::delete('/{id}', 'destroy');
        });
    });


    Route::group(['prefix'=>'mulher','middleware' => ['permission:mulher']], function () {
        Route::get('lov_escolaridade', [EscolaridadeController::class, 'lov']);
        Route::get('lov_ori_sexual', [Ori_sexualController::class, 'lov']);
        Route::get('lov_etnia', [EtiniaController::class, 'lov']);
        Route::get('lov_estado_civil', [EstadoCivilController::class, 'lov']);
        Route::get('lov_reside_com', [ResideComController::class, 'lov']);
        Route::get('lov_sit_moradia', [SitMoradiaController::class, 'lov']);
        Route::get('lov_estado', [EstadoController::class, 'lov']);
        Route::get('lov_municipio', [MunicipioController::class, 'lov']);
        Route::get('lov_servico', [ServicoController::class, 'lov']);
        Route::get('todos_atendimentos/{id_mulher}', [AtendimentoController::class, 'todos_atendimentos']);
        Route::get('/cep/{cep}', [CEPController::class, 'show']);
        Route::group(['controller'=>MulherController::class], function () {
            Route::get('/lov', 'lov');
            Route::get('/', 'index');
            Route::post('/', 'store');
            Route::get('/{id}', 'show');
            Route::put('/{id}', 'update');
            Route::delete('/{id}', 'destroy');
        });
    });


    Route::group(['prefix'=>'for_busc_serv','middleware' => ['permission:for_busc_serv']], function () {
        Route::group(['controller'=>ForBuscServController::class], function () {
            Route::get('/lov', 'lov');
            Route::get('/', 'index');
            Route::post('/', 'store');
            Route::get('/{id}', 'show');
            Route::put('/{id}', 'update');
            Route::delete('/{id}', 'destroy');
        });
    });


    Route::group(['prefix'=>'inst_encaminha','middleware' => ['permission:inst_encaminha']], function () {
        Route::group(['controller'=>InstEncaminhaController::class], function () {
            Route::get('/lov', 'lov');
            Route::get('/', 'index');
            Route::post('/', 'store');
            Route::get('/{id}', 'show');
            Route::put('/{id}', 'update');
            Route::delete('/{id}', 'destroy');
        });
    });


    Route::group(['prefix'=>'prof_resp_encam','middleware' => ['permission:prof_resp_encam']], function () {
        Route::group(['controller'=>ProfRespEncamController::class], function () {
            Route::get('/lov', 'lov');
            Route::get('/', 'index');
            Route::post('/', 'store');
            Route::get('/{id}', 'show');
            Route::put('/{id}', 'update');
            Route::delete('/{id}', 'destroy');
        });
    });


    Route::group(['prefix'=>'caract_violencia','middleware' => ['permission:caract_violencia']], function () {
        Route::group(['controller'=>CaractViolenciaController::class], function () {
            Route::get('/lov', 'lov');
            Route::get('/', 'index');
            Route::post('/', 'store');
            Route::get('/{id}', 'show');
            Route::put('/{id}', 'update');
            Route::delete('/{id}', 'destroy');
        });
    });


    Route::group(['prefix'=>'tipo_agressor','middleware' => ['permission:tipo_agressor']], function () {
        Route::group(['controller'=>TipoAgressorController::class], function () {
            Route::get('/lov', 'lov');
            Route::get('/', 'index');
            Route::post('/', 'store');
            Route::get('/{id}', 'show');
            Route::put('/{id}', 'update');
            Route::delete('/{id}', 'destroy');
        });
    });


    Route::group(['prefix'=>'relacao_agressor','middleware' => ['permission:relacao_agressor']], function () {
        Route::group(['controller'=>RelacaoAgressorController::class], function () {
            Route::get('/lov', 'lov');
            Route::get('/', 'index');
            Route::post('/', 'store');
            Route::get('/{id}', 'show');
            Route::put('/{id}', 'update');
            Route::delete('/{id}', 'destroy');
        });
    });


    Route::group(['prefix'=>'tipo_violencia','middleware' => ['permission:tipo_violencia']], function () {
        Route::group(['controller'=>TipoViolenciaController::class], function () {
            Route::get('/lov', 'lov');
            Route::get('/', 'index');
            Route::post('/', 'store');
            Route::get('/{id}', 'show');
            Route::put('/{id}', 'update');
            Route::delete('/{id}', 'destroy');
        });
    });


    Route::group(['prefix'=>'grau_violencia','middleware' => ['permission:grau_violencia']], function () {
        Route::group(['controller'=>GrauViolenciaController::class], function () {
            Route::get('/lov', 'lov');
            Route::get('/', 'index');
            Route::post('/', 'store');
            Route::get('/{id}', 'show');
            Route::put('/{id}', 'update');
            Route::delete('/{id}', 'destroy');
        });
    });


    Route::group(['prefix'=>'tp_viol_fisica','middleware' => ['permission:tp_viol_fisica']], function () {
        Route::group(['controller'=>TpViolFisicaController::class], function () {
            Route::get('/lov', 'lov');
            Route::get('/', 'index');
            Route::post('/', 'store');
            Route::get('/{id}', 'show');
            Route::put('/{id}', 'update');
            Route::delete('/{id}', 'destroy');
        });
    });


    Route::group(['prefix'=>'tp_atendimento','middleware' => ['permission:tp_atendimento']], function () {
        Route::group(['controller'=>TpAtendimentoController::class], function () {
            Route::get('/lov', 'lov');
            Route::get('/', 'index');
            Route::post('/', 'store');
            Route::get('/{id}', 'show');
            Route::put('/{id}', 'update');
            Route::delete('/{id}', 'destroy');
        });
    });


    Route::group(['prefix'=>'acao_rel_med','middleware' => ['permission:acao_rel_med']], function () {
        Route::group(['controller'=>AcaoRelMedController::class], function () {
            Route::get('/lov', 'lov');
            Route::get('/', 'index');
            Route::post('/', 'store');
            Route::get('/{id}', 'show');
            Route::put('/{id}', 'update');
            Route::delete('/{id}', 'destroy');
        });
    });


    Route::group(['prefix'=>'tp_viol_sexual','middleware' => ['permission:tp_viol_sexual']], function () {
        Route::group(['controller'=>TpViolSexualController::class], function () {
            Route::get('/lov', 'lov');
            Route::get('/', 'index');
            Route::post('/', 'store');
            Route::get('/{id}', 'show');
            Route::put('/{id}', 'update');
            Route::delete('/{id}', 'destroy');
        });
    });


    Route::group(['prefix'=>'tp_viol_psico','middleware' => ['permission:tp_viol_psico']], function () {
        Route::group(['controller'=>TpViolPsicoController::class], function () {
            Route::get('/lov', 'lov');
            Route::get('/', 'index');
            Route::post('/', 'store');
            Route::get('/{id}', 'show');
            Route::put('/{id}', 'update');
            Route::delete('/{id}', 'destroy');
        });
    });


    Route::group(['prefix'=>'aval_risc_int','middleware' => ['permission:aval_risc_int']], function () {
        Route::group(['controller'=>AvalRiscIntController::class], function () {
            Route::get('/lov', 'lov');
            Route::get('/', 'index');
            Route::post('/', 'store');
            Route::get('/{id}', 'show');
            Route::put('/{id}', 'update');
            Route::delete('/{id}', 'destroy');
        });
    });


    Route::group(['prefix'=>'org_acionado','middleware' => ['permission:org_acionado']], function () {
        Route::group(['controller'=>OrgAcionadoController::class], function () {
            Route::get('/lov', 'lov');
            Route::get('/', 'index');
            Route::post('/', 'store');
            Route::get('/{id}', 'show');
            Route::put('/{id}', 'update');
            Route::delete('/{id}', 'destroy');
        });
    });


    Route::group(['prefix'=>'local_atend','middleware' => ['permission:local_atend']], function () {
        Route::get('lov_estado', [EstadoController::class, 'lov']);
        Route::get('lov_municipio', [MunicipioController::class, 'lov']);
        Route::get('/cep/{cep}', [CEPController::class, 'show']);
        Route::group(['controller'=>LocalAtendController::class], function () {
            Route::get('/lov', 'lov');
            Route::get('/', 'index');
            Route::post('/', 'store');
            Route::get('/{id}', 'show');
            Route::put('/{id}', 'update');
            Route::delete('/{id}', 'destroy');
        });
    });


    Route::group(['prefix'=>'atendimento','middleware' => ['permission:atendimento']], function () {
        Route::get('lov_mulher', [MulherController::class, 'lov']);
        Route::get('buscar_mulher', [MulherController::class, 'index']);
        Route::get('lov_local_atend', [LocalAtendController::class, 'lov']);
        Route::get('lov_for_busc_serv', [ForBuscServController::class, 'lov']);
        Route::get('lov_inst_encaminha', [InstEncaminhaController::class, 'lov']);
        Route::get('lov_prof_resp_encam', [ProfRespEncamController::class, 'lov']);
        Route::get('lov_caract_violencia', [CaractViolenciaController::class, 'lov']);
        Route::get('lov_tipo_agressor', [TipoAgressorController::class, 'lov']);
        Route::get('lov_relacao_agressor', [RelacaoAgressorController::class, 'lov']);
        Route::get('lov_tipo_violencia', [TipoViolenciaController::class, 'lov']);
        Route::get('lov_grau_violencia', [GrauViolenciaController::class, 'lov']);
        Route::get('lov_tp_viol_fisica', [TpViolFisicaController::class, 'lov']);
        Route::get('lov_tp_atendimento', [TpAtendimentoController::class, 'lov']);
        Route::get('lov_acao_rel_med', [AcaoRelMedController::class, 'lov']);
        Route::get('lov_tp_viol_sexual', [TpViolSexualController::class, 'lov']);
        Route::get('lov_tp_viol_psico', [TpViolPsicoController::class, 'lov']);
        Route::get('lov_aval_risc_int', [AvalRiscIntController::class, 'lov']);
        Route::get('lov_org_acionado', [OrgAcionadoController::class, 'lov']);
        Route::get('lov_users', [UserController::class, 'lov']);
        Route::group(['controller'=>AtendimentoController::class], function () {
            Route::get('/lov', 'lov');
            Route::get('/', 'index');
            Route::post('/', 'store');
            Route::get('/{id}', 'show');
            Route::get('/todos_atendimentos/{id_mulher}', 'todos_atendimentos');
            Route::put('/{id}', 'update');
            Route::delete('/{id}', 'destroy');
        });
    });

});