<?php

namespace Tests\Feature;

use App\Models\Profile;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class ServicoTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp():void 
    {
        parent::setUp();

        $this->cadastro_correto = [
            'ativo' => true,
            'servico' => 'Saúde Pública',
        ];


        $this->cadastro_compara = [
            'ativo' => true,
            'servico' => 'Saúde Pública',
        ];


        $this->edicao_correto = [
            'ativo' => false,
            'servico' => 'Educação',
        ];


        $this->edicao_compara = [
            'ativo' => false,
            'servico' => 'Educação',
        ];

    }


    /** @test */
    public function listar_get_sem_login()
    {
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->get('/api/servico');

        $response
        -> assertStatus(401)
        -> assertJson(['message' => 'Unauthenticated.']);

    }


    /** @test */
    public function listar_get_com_login()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->get('/api/servico');

        $response
        -> assertStatus(200);

    }


    /** @test */
    public function salvar_post_sem_login()
    {
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->post('/api/servico');

        $response
        -> assertStatus(401)
        -> assertJson(['message' => 'Unauthenticated.']);

    }


    /** @test */
    public function editar_put_sem_login()
    {
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/servico/1',[]);

        $response
        -> assertStatus(401)
        -> assertJson(['message' => 'Unauthenticated.']);

    }


    /** @test */
    public function campos_listar()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/servico',$this->cadastro_correto);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->get('/api/servico');

        $response
        -> assertStatus(200)
        -> assertJsonStructure(['*' => ['id', 'ativo', 'servico']]);

    }


    /** @test */
    public function salvar_correto()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/servico',$this->cadastro_correto);

        $response
        ->assertStatus(201)
        ->assertJsonFragment($this->cadastro_compara);

    }


    /** @test */
    public function salvar_servico_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/servico',[
                                    'servico' => '']);

        $response->assertJsonValidationErrors([
                   'servico' => __('validation.required',['attribute' => 'Serviço'])
        ]);

    }


    /** @test */
    public function salvar_servico_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/servico',[
                'servico' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'servico' => __('validation.string',['attribute' => 'Serviço'])
        ]);

    }


    /** @test */
    public function salvar_servico_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit';

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/servico',[
                'servico' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'servico' => __('validation.max.string',['attribute' => 'Serviço', 'max' => '250'])
        ]);

    }


    /** @test */
    public function salvar_servico_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing';

        $obj = $this->cadastro_correto;
        $obj['servico'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->cadastro_compara;
        $objcompara['servico'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/servico',$obj);

        $response
        ->assertJsonMissingValidationErrors('servico');

    }


    /** @test */
    public function salvar_servico_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/servico',[
                'servico' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'servico' => __('validation.min.string',['attribute' => 'Serviço', 'min' => '2'])
        ]);

    }


    /** @test */
    public function salvar_servico_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $obj['servico'] = 'Lo';
        $objcompara = $this->cadastro_compara;
        $objcompara['servico'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/servico',$obj);

        $response
        ->assertJsonMissingValidationErrors('servico');

    }


    /** @test */
    public function salvar_servico_unique()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/servico',$this->cadastro_correto);
        $response->assertStatus(201);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/servico',$this->cadastro_correto);

        $response->assertJsonValidationErrors([
                   'servico' => __('validation.unique',['attribute' => 'Serviço'])
        ]);

    }


    /** @test */
    public function editar_correto()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/servico',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];


        $obj = $this->edicao_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/servico/'.$id_objeto,$obj);

        $response
        ->assertStatus(200)
        ->assertJsonFragment($this->edicao_compara);

    }
    /** @test */
    public function editar_servico_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/servico',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/servico/'.$id_objeto,[
                                    'servico' => '']);

        $response->assertJsonValidationErrors([
                   'servico' => __('validation.required',['attribute' => 'Serviço'])
        ]);

    }


    /** @test */
    public function editar_servico_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/servico',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/servico/'.$id_objeto,[
                'servico' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'servico' => __('validation.string',['attribute' => 'Serviço'])
        ]);

    }


    /** @test */
    public function editar_servico_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/servico',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/servico/'.$id_objeto,[
                'servico' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'servico' => __('validation.max.string',['attribute' => 'Serviço', 'max' => '250'])
        ]);

    }


    /** @test */
    public function editar_servico_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/servico',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['servico'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->edicao_compara;
        $objcompara['servico'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/servico/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('servico');

    }


    /** @test */
    public function editar_servico_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/servico',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/servico/'.$id_objeto,[
                'servico' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'servico' => __('validation.min.string',['attribute' => 'Serviço', 'min' => '2'])
        ]);

    }


    /** @test */
    public function editar_servico_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/servico',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['servico'] = 'Lo';
        $objcompara = $this->edicao_compara;
        $objcompara['servico'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/servico/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('servico');

    }

    /** @test */
    public function editar_servico_unique()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/servico',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto1 = json_decode($resposta,true)['id'];

        $obj2 = $this->cadastro_correto;
        $obj2['servico'] = $obj2['servico'] . 'abc';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/servico',$obj2);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto2 = json_decode($resposta,true)['id'];

        $obj = $this->edicao_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/servico/'.$id_objeto1,$obj);
        $response->assertStatus(200);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/servico/'.$id_objeto2,$obj);

        $response->assertJsonValidationErrors([
                   'servico' => __('validation.unique',['attribute' => 'Serviço'])
        ]);

    }


    /** @test */
    public function buscar_registro_especifico()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/servico',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->get('/api/servico/'.$id_objeto);

        $response
        ->assertStatus(200)
        ->assertJson($this->cadastro_compara);

    }


    /** @test */
    public function buscar_varios_registros()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/servico',$obj);

        $resposta = $response->assertStatus(201)->getContent();

        $obj2 = array_merge($this->cadastro_correto, $this->edicao_correto);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/servico',$obj2);

        $resposta = $response->assertStatus(201)->getContent();


        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->get('/api/servico/');

        $response
        ->assertStatus(200)
        ->assertJsonCount(6);

    }


    /** @test */
    public function deletar_um_registro()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/servico',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = array_merge($this->cadastro_correto, $this->edicao_correto);
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/servico',$obj2);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->delete('/api/servico/'.$id_objeto);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->get('/api/servico/');

        $response
        ->assertStatus(200)
        ->assertJsonMissingExact($obj);

    }

}

