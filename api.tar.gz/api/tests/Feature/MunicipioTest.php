<?php

namespace Tests\Feature;

use App\Models\Profile;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class MunicipioTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp():void 
    {
        parent::setUp();

        $this->cadastro_correto = [
            'ativo' => true,
            'cod_muni_ibge' => '993403',
            'estado' => 1,
            'municipio' => 'Cuiabá',
        ];


        $this->cadastro_compara = [
            'ativo' => true,
            'cod_muni_ibge' => '993403',
            'estado' => 1,
            'municipio' => 'Cuiabá',
        ];


        $this->edicao_correto = [
            'ativo' => false,
            'cod_muni_ibge' => '9901402',
            'estado' => 2,
            'municipio' => 'Belém',
        ];


        $this->edicao_compara = [
            'ativo' => false,
            'cod_muni_ibge' => '9901402',
            'estado' => 2,
            'municipio' => 'Belém',
        ];

    }


    /** @test */
    public function listar_get_sem_login()
    {
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->get('/api/municipio');

        $response
        -> assertStatus(401)
        -> assertJson(['message' => 'Unauthenticated.']);

    }


    /** @test */
    public function listar_get_com_login()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->get('/api/municipio');

        $response
        -> assertStatus(200);

    }


    /** @test */
    public function salvar_post_sem_login()
    {
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->post('/api/municipio');

        $response
        -> assertStatus(401)
        -> assertJson(['message' => 'Unauthenticated.']);

    }


    /** @test */
    public function editar_put_sem_login()
    {
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/municipio/1',[]);

        $response
        -> assertStatus(401)
        -> assertJson(['message' => 'Unauthenticated.']);

    }


    /** @test */
    public function campos_listar()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$this->cadastro_correto);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->get('/api/municipio');

        $response
        -> assertStatus(200)
        -> assertJsonStructure(['*' => ['id', 'ativo', 'cod_muni_ibge', 'municipio']]);

    }


    /** @test */
    public function salvar_correto()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$this->cadastro_correto);

        $response
        ->assertStatus(201)
        ->assertJsonFragment($this->cadastro_compara);

    }


    /** @test */
    public function salvar_cod_muni_ibge_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',[
                                    'cod_muni_ibge' => '']);

        $response->assertJsonValidationErrors([
                   'cod_muni_ibge' => __('validation.required',['attribute' => 'Código Município Completo do IBGE'])
        ]);

    }


    /** @test */
    public function salvar_estado_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',[
                                    'estado' => '']);

        $response->assertJsonValidationErrors([
                   'estado' => __('validation.required',['attribute' => 'Estado'])
        ]);

    }


    /** @test */
    public function salvar_municipio_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',[
                                    'municipio' => '']);

        $response->assertJsonValidationErrors([
                   'municipio' => __('validation.required',['attribute' => 'Município'])
        ]);

    }


    /** @test */
    public function salvar_cod_muni_ibge_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/municipio',[
                'cod_muni_ibge' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'cod_muni_ibge' => __('validation.string',['attribute' => 'Código Município Completo do IBGE'])
        ]);

    }


    /** @test */
    public function salvar_municipio_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/municipio',[
                'municipio' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'municipio' => __('validation.string',['attribute' => 'Município'])
        ]);

    }


    /** @test */
    public function salvar_cod_muni_ibge_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_d';

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',[
                'cod_muni_ibge' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'cod_muni_ibge' => __('validation.max.string',['attribute' => 'Código Município Completo do IBGE', 'max' => '8'])
        ]);

    }


    /** @test */
    public function salvar_cod_muni_ibge_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ip';

        $obj = $this->cadastro_correto;
        $obj['cod_muni_ibge'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->cadastro_compara;
        $objcompara['cod_muni_ibge'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$obj);

        $response
        ->assertJsonMissingValidationErrors('cod_muni_ibge');

    }


    /** @test */
    public function salvar_municipio_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit';

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',[
                'municipio' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'municipio' => __('validation.max.string',['attribute' => 'Município', 'max' => '250'])
        ]);

    }


    /** @test */
    public function salvar_municipio_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing';

        $obj = $this->cadastro_correto;
        $obj['municipio'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->cadastro_compara;
        $objcompara['municipio'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$obj);

        $response
        ->assertJsonMissingValidationErrors('municipio');

    }


    /** @test */
    public function salvar_cod_muni_ibge_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',[
                'cod_muni_ibge' => 'Lorem'
        ]);

        $response-> assertJsonValidationErrors([
            'cod_muni_ibge' => __('validation.min.string',['attribute' => 'Código Município Completo do IBGE', 'min' => '6'])
        ]);

    }


    /** @test */
    public function salvar_cod_muni_ibge_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $obj['cod_muni_ibge'] = 'Lorem_';
        $objcompara = $this->cadastro_compara;
        $objcompara['cod_muni_ibge'] = 'Lorem_';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$obj);

        $response
        ->assertJsonMissingValidationErrors('cod_muni_ibge');

    }


    /** @test */
    public function salvar_municipio_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',[
                'municipio' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'municipio' => __('validation.min.string',['attribute' => 'Município', 'min' => '2'])
        ]);

    }


    /** @test */
    public function salvar_municipio_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $obj['municipio'] = 'Lo';
        $objcompara = $this->cadastro_compara;
        $objcompara['municipio'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$obj);

        $response
        ->assertJsonMissingValidationErrors('municipio');

    }


    /** @test */
    public function salvar_estado_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/municipio',[
                'estado' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'estado' => __('validation.exists',['attribute' => 'Estado'])
        ]);

    }


    /** @test */
    public function salvar_cod_muni_ibge_unique()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$this->cadastro_correto);
        $response->assertStatus(201);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$this->cadastro_correto);

        $response->assertJsonValidationErrors([
                   'cod_muni_ibge' => __('validation.unique',['attribute' => 'Código Município Completo do IBGE'])
        ]);

    }


    /** @test */
    public function editar_correto()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];


        $obj = $this->edicao_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/municipio/'.$id_objeto,$obj);

        $response
        ->assertStatus(200)
        ->assertJsonFragment($this->edicao_compara);

    }
    /** @test */
    public function editar_cod_muni_ibge_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/municipio/'.$id_objeto,[
                                    'cod_muni_ibge' => '']);

        $response->assertJsonValidationErrors([
                   'cod_muni_ibge' => __('validation.required',['attribute' => 'Código Município Completo do IBGE'])
        ]);

    }


    /** @test */
    public function editar_estado_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/municipio/'.$id_objeto,[
                                    'estado' => '']);

        $response->assertJsonValidationErrors([
                   'estado' => __('validation.required',['attribute' => 'Estado'])
        ]);

    }


    /** @test */
    public function editar_municipio_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/municipio/'.$id_objeto,[
                                    'municipio' => '']);

        $response->assertJsonValidationErrors([
                   'municipio' => __('validation.required',['attribute' => 'Município'])
        ]);

    }


    /** @test */
    public function editar_cod_muni_ibge_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/municipio/'.$id_objeto,[
                'cod_muni_ibge' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'cod_muni_ibge' => __('validation.string',['attribute' => 'Código Município Completo do IBGE'])
        ]);

    }


    /** @test */
    public function editar_municipio_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/municipio/'.$id_objeto,[
                'municipio' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'municipio' => __('validation.string',['attribute' => 'Município'])
        ]);

    }


    /** @test */
    public function editar_cod_muni_ibge_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_d';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/municipio/'.$id_objeto,[
                'cod_muni_ibge' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'cod_muni_ibge' => __('validation.max.string',['attribute' => 'Código Município Completo do IBGE', 'max' => '8'])
        ]);

    }


    /** @test */
    public function editar_cod_muni_ibge_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ip';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['cod_muni_ibge'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->edicao_compara;
        $objcompara['cod_muni_ibge'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/municipio/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('cod_muni_ibge');

    }


    /** @test */
    public function editar_municipio_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/municipio/'.$id_objeto,[
                'municipio' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'municipio' => __('validation.max.string',['attribute' => 'Município', 'max' => '250'])
        ]);

    }


    /** @test */
    public function editar_municipio_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['municipio'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->edicao_compara;
        $objcompara['municipio'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/municipio/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('municipio');

    }


    /** @test */
    public function editar_cod_muni_ibge_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/municipio/'.$id_objeto,[
                'cod_muni_ibge' => 'Lorem'
        ]);

        $response-> assertJsonValidationErrors([
            'cod_muni_ibge' => __('validation.min.string',['attribute' => 'Código Município Completo do IBGE', 'min' => '6'])
        ]);

    }


    /** @test */
    public function editar_cod_muni_ibge_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['cod_muni_ibge'] = 'Lorem_';
        $objcompara = $this->edicao_compara;
        $objcompara['cod_muni_ibge'] = 'Lorem_';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/municipio/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('cod_muni_ibge');

    }

    /** @test */
    public function editar_municipio_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/municipio/'.$id_objeto,[
                'municipio' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'municipio' => __('validation.min.string',['attribute' => 'Município', 'min' => '2'])
        ]);

    }


    /** @test */
    public function editar_municipio_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['municipio'] = 'Lo';
        $objcompara = $this->edicao_compara;
        $objcompara['municipio'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/municipio/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('municipio');

    }

    /** @test */
    public function editar_estado_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/municipio/'.$id_objeto,[
                'estado' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'estado' => __('validation.exists',['attribute' => 'Estado'])
        ]);

    }


    /** @test */
    public function editar_cod_muni_ibge_unique()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto1 = json_decode($resposta,true)['id'];

        $obj2 = $this->cadastro_correto;
        $obj2['cod_muni_ibge'] = '99999900';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$obj2);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto2 = json_decode($resposta,true)['id'];

        $obj = $this->edicao_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/municipio/'.$id_objeto1,$obj);
        $response->assertStatus(200);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/municipio/'.$id_objeto2,$obj);

        $response->assertJsonValidationErrors([
                   'cod_muni_ibge' => __('validation.unique',['attribute' => 'Código Município Completo do IBGE'])
        ]);

    }


    /** @test */
    public function buscar_registro_especifico()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->get('/api/municipio/'.$id_objeto);

        $response
        ->assertStatus(200)
        ->assertJson($this->cadastro_compara);

    }


    /** @test */
    public function buscar_varios_registros()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$obj);

        $resposta = $response->assertStatus(201)->getContent();

        $obj2 = array_merge($this->cadastro_correto, $this->edicao_correto);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$obj2);

        $resposta = $response->assertStatus(201)->getContent();


        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->get('/api/municipio/');

        $response
        ->assertStatus(200)
        ->assertJsonCount(5572);

    }


    /** @test */
    public function deletar_um_registro()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = array_merge($this->cadastro_correto, $this->edicao_correto);
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$obj2);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->delete('/api/municipio/'.$id_objeto);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->get('/api/municipio/');

        $response
        ->assertStatus(200)
        ->assertJsonMissingExact($obj);

    }


    /** @test */
    public function deletar_um_registro_possuind_mulher()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $this->mulher1 = [

            'nome' => 'Sophia Agatha Laís Pereira',
            'data_nascimento' => '1988-02-01',
            'rg' => '19.211.535-2',
            'cpf' => '926.622.331-09',
            'nis' => '37414972104',
            'trabalha' => true,
            'remunerado' => true,
            'ocupacao' => 'Vendedora',
            'escolaridade' => 2,
            'orientacao' => 1,
            'etnia' => 2,
            'estado_civil' => 1,
            'possui_filhos' => true,
            'filhos' => array(["idade"=>12,"fillho_reside_com"=>1,"port_deficiencia"=>false]),
            'dorme_rua' => false,
            'resido_com' => 1,
            'sit_moradia' => 1,
            'cep' => '78043-128',
            'endereco' => 'Rua das Rosas',
            'numero' => '479',
            'complemento' => 'não informado',
            'bairro' => 'Jardim Cuiabá',
            'estado' => 1,
            'municipio' => $id_objeto,
            'outro_end_loca' => 'não informado',
            'telefone' => array(["telefone"=>"(65) 3698-5249"],["telefone"=>"(65) 99121-7026"]),
            'nacionalidade_br' => true,
            'estado_nascimento' => 1,
            'municipio_nascimento' => $id_objeto,
            'pais_cidade_estrangeiro' => 'Não se Aplica',
            'tempo_reside_mun' => 3.5,
            'muni_anterior' => array(["estado"=>1,"municipio"=>2],["estado"=>4,"municipio"=>3]),
            'port_deficiencia' => false,
            'tipo_deficiencia' => 'Não se Aplica',
            'servico_utilizado' => array(["servico"=>1,"nome"=>"Centro de Saúde Dr Oscarino de Campos Borges"]),
        ];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$this->mulher1);

        $response->assertStatus(201)->getContent();

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->delete('/api/municipio/'.$id_objeto);

        $response
        ->assertStatus(422)
        ->assertJsonValidationErrors(['mulher']);

    }


    /** @test */
    public function deletar_um_registro_possuind_local_atend()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $this->local_atend1 = [

            'nome_local' => 'Casa de Amparo às Mulheres Vítimas de Violência Doméstica',
            'cep' => '78005-580',
            'endereco' => 'Palácio Alencastro',
            'numero' => '158',
            'complemento' => '7 andar',
            'bairro' => 'Centro',
            'estado' => 1,
            'municipio' => $id_objeto,
            'telefone' => '(65) 3555-1224',
        ];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/local_atend',$this->local_atend1);

        $response->assertStatus(201)->getContent();

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->delete('/api/municipio/'.$id_objeto);

        $response
        ->assertStatus(422)
        ->assertJsonValidationErrors(['local_atend']);

    }

}

