<?php

namespace Tests\Feature;

use App\Models\Profile;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class SitMoradiaTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp():void 
    {
        parent::setUp();

        $this->cadastro_correto = [
            'ativo' => true,
            'situacao' => 'Cedido',
        ];


        $this->cadastro_compara = [
            'ativo' => true,
            'situacao' => 'Cedido',
        ];


        $this->edicao_correto = [
            'ativo' => false,
            'situacao' => 'Próprio',
        ];


        $this->edicao_compara = [
            'ativo' => false,
            'situacao' => 'Próprio',
        ];

    }


    /** @test */
    public function listar_get_sem_login()
    {
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->get('/api/sit_moradia');

        $response
        -> assertStatus(401)
        -> assertJson(['message' => 'Unauthenticated.']);

    }


    /** @test */
    public function listar_get_com_login()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->get('/api/sit_moradia');

        $response
        -> assertStatus(200);

    }


    /** @test */
    public function salvar_post_sem_login()
    {
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->post('/api/sit_moradia');

        $response
        -> assertStatus(401)
        -> assertJson(['message' => 'Unauthenticated.']);

    }


    /** @test */
    public function editar_put_sem_login()
    {
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/sit_moradia/1',[]);

        $response
        -> assertStatus(401)
        -> assertJson(['message' => 'Unauthenticated.']);

    }


    /** @test */
    public function campos_listar()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/sit_moradia',$this->cadastro_correto);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->get('/api/sit_moradia');

        $response
        -> assertStatus(200)
        -> assertJsonStructure(['*' => ['id', 'ativo', 'situacao', 'chave']]);

    }


    /** @test */
    public function salvar_correto()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/sit_moradia',$this->cadastro_correto);

        $response
        ->assertStatus(201)
        ->assertJsonFragment($this->cadastro_compara);

    }


    /** @test */
    public function salvar_situacao_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/sit_moradia',[
                                    'situacao' => '']);

        $response->assertJsonValidationErrors([
                   'situacao' => __('validation.required',['attribute' => 'Situação da Moradia'])
        ]);

    }


    /** @test */
    public function salvar_situacao_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/sit_moradia',[
                'situacao' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'situacao' => __('validation.string',['attribute' => 'Situação da Moradia'])
        ]);

    }


    /** @test */
    public function salvar_situacao_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit';

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/sit_moradia',[
                'situacao' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'situacao' => __('validation.max.string',['attribute' => 'Situação da Moradia', 'max' => '250'])
        ]);

    }


    /** @test */
    public function salvar_situacao_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing';

        $obj = $this->cadastro_correto;
        $obj['situacao'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->cadastro_compara;
        $objcompara['situacao'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/sit_moradia',$obj);

        $response
        ->assertJsonMissingValidationErrors('situacao');

    }


    /** @test */
    public function salvar_situacao_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/sit_moradia',[
                'situacao' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'situacao' => __('validation.min.string',['attribute' => 'Situação da Moradia', 'min' => '2'])
        ]);

    }


    /** @test */
    public function salvar_situacao_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $obj['situacao'] = 'Lo';
        $objcompara = $this->cadastro_compara;
        $objcompara['situacao'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/sit_moradia',$obj);

        $response
        ->assertJsonMissingValidationErrors('situacao');

    }


    /** @test */
    public function salvar_situacao_unique()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/sit_moradia',$this->cadastro_correto);
        $response->assertStatus(201);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/sit_moradia',$this->cadastro_correto);

        $response->assertJsonValidationErrors([
                   'situacao' => __('validation.unique',['attribute' => 'Situação da Moradia'])
        ]);

    }


    /** @test */
    public function editar_correto()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/sit_moradia',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];


        $obj = $this->edicao_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/sit_moradia/'.$id_objeto,$obj);

        $response
        ->assertStatus(200)
        ->assertJsonFragment($this->edicao_compara);

    }
    /** @test */
    public function editar_situacao_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/sit_moradia',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/sit_moradia/'.$id_objeto,[
                                    'situacao' => '']);

        $response->assertJsonValidationErrors([
                   'situacao' => __('validation.required',['attribute' => 'Situação da Moradia'])
        ]);

    }


    /** @test */
    public function editar_situacao_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/sit_moradia',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/sit_moradia/'.$id_objeto,[
                'situacao' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'situacao' => __('validation.string',['attribute' => 'Situação da Moradia'])
        ]);

    }


    /** @test */
    public function editar_situacao_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/sit_moradia',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/sit_moradia/'.$id_objeto,[
                'situacao' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'situacao' => __('validation.max.string',['attribute' => 'Situação da Moradia', 'max' => '250'])
        ]);

    }


    /** @test */
    public function editar_situacao_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/sit_moradia',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['situacao'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->edicao_compara;
        $objcompara['situacao'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/sit_moradia/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('situacao');

    }


    /** @test */
    public function editar_situacao_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/sit_moradia',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/sit_moradia/'.$id_objeto,[
                'situacao' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'situacao' => __('validation.min.string',['attribute' => 'Situação da Moradia', 'min' => '2'])
        ]);

    }


    /** @test */
    public function editar_situacao_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/sit_moradia',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['situacao'] = 'Lo';
        $objcompara = $this->edicao_compara;
        $objcompara['situacao'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/sit_moradia/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('situacao');

    }

    /** @test */
    public function editar_situacao_unique()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/sit_moradia',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto1 = json_decode($resposta,true)['id'];

        $obj2 = $this->cadastro_correto;
        $obj2['situacao'] = $obj2['situacao'] . 'abc';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/sit_moradia',$obj2);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto2 = json_decode($resposta,true)['id'];

        $obj = $this->edicao_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/sit_moradia/'.$id_objeto1,$obj);
        $response->assertStatus(200);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/sit_moradia/'.$id_objeto2,$obj);

        $response->assertJsonValidationErrors([
                   'situacao' => __('validation.unique',['attribute' => 'Situação da Moradia'])
        ]);

    }


    /** @test */
    public function buscar_registro_especifico()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/sit_moradia',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->get('/api/sit_moradia/'.$id_objeto);

        $response
        ->assertStatus(200)
        ->assertJson($this->cadastro_compara);

    }


    /** @test */
    public function buscar_varios_registros()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/sit_moradia',$obj);

        $resposta = $response->assertStatus(201)->getContent();

        $obj2 = array_merge($this->cadastro_correto, $this->edicao_correto);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/sit_moradia',$obj2);

        $resposta = $response->assertStatus(201)->getContent();


        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->get('/api/sit_moradia/');

        $response
        ->assertStatus(200)
        ->assertJsonCount(5);

    }


    /** @test */
    public function deletar_um_registro()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/sit_moradia',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = array_merge($this->cadastro_correto, $this->edicao_correto);
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/sit_moradia',$obj2);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->delete('/api/sit_moradia/'.$id_objeto);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->get('/api/sit_moradia/');

        $response
        ->assertStatus(200)
        ->assertJsonMissingExact($obj);

    }


    /** @test */
    public function deletar_um_registro_possuind_mulher()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/sit_moradia',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $this->mulher1 = [

            'nome' => 'Sophia Agatha Laís Pereira',
            'data_nascimento' => '1988-02-01',
            'rg' => '19.211.535-2',
            'cpf' => '926.622.331-09',
            'nis' => '37414972104',
            'trabalha' => true,
            'remunerado' => true,
            'ocupacao' => 'Vendedora',
            'escolaridade' => 2,
            'orientacao' => 1,
            'etnia' => 2,
            'estado_civil' => 1,
            'possui_filhos' => true,
            'filhos' => array(["idade"=>12,"fillho_reside_com"=>1,"port_deficiencia"=>false]),
            'dorme_rua' => false,
            'resido_com' => 1,
            'sit_moradia' => $id_objeto,
            'cep' => '78043-128',
            'endereco' => 'Rua das Rosas',
            'numero' => '479',
            'complemento' => 'não informado',
            'bairro' => 'Jardim Cuiabá',
            'estado' => 1,
            'municipio' => 1,
            'outro_end_loca' => 'não informado',
            'telefone' => array(["telefone"=>"(65) 3698-5249"],["telefone"=>"(65) 99121-7026"]),
            'nacionalidade_br' => true,
            'estado_nascimento' => 1,
            'municipio_nascimento' => 3,
            'pais_cidade_estrangeiro' => 'Não se Aplica',
            'tempo_reside_mun' => 3.5,
            'muni_anterior' => array(["estado"=>1,"municipio"=>2],["estado"=>4,"municipio"=>3]),
            'port_deficiencia' => false,
            'tipo_deficiencia' => 'Não se Aplica',
            'servico_utilizado' => array(["servico"=>1,"nome"=>"Centro de Saúde Dr Oscarino de Campos Borges"]),
        ];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$this->mulher1);

        $response->assertStatus(201)->getContent();

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->delete('/api/sit_moradia/'.$id_objeto);

        $response
        ->assertStatus(422)
        ->assertJsonValidationErrors(['mulher']);

    }

}

