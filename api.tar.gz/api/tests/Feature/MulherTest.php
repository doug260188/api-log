<?php

namespace Tests\Feature;

use App\Models\Profile;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class MulherTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp():void 
    {
        parent::setUp();

        $this->cadastro_correto = [
            'nome' => 'Sophia Agatha Laís Pereira',
            'data_nascimento' => '1988-02-01',
            'rg' => '19.211.535-2',
            'cpf' => '926.622.331-09',
            'nis' => '37414972104',
            'trabalha' => true,
            'remunerado' => true,
            'ocupacao' => 'Vendedora',
            'escolaridade' => 2,
            'orientacao' => 1,
            'etnia' => 2,
            'estado_civil' => 1,
            'possui_filhos' => true,
            'filhos' => array(["idade"=>12,"fillho_reside_com"=>1,"port_deficiencia"=>false]),
            'dorme_rua' => false,
            'resido_com' => 1,
            'sit_moradia' => 1,
            'cep' => '78043-128',
            'endereco' => 'Rua das Rosas',
            'numero' => '479',
            'complemento' => 'não informado',
            'bairro' => 'Jardim Cuiabá',
            'estado' => 1,
            'municipio' => 1,
            'outro_end_loca' => 'não informado',
            'telefone' => array(["telefone"=>"(65) 3698-5249"],["telefone"=>"(65) 99121-7026"]),
            'nacionalidade_br' => true,
            'estado_nascimento' => 1,
            'municipio_nascimento' => 3,
            'pais_cidade_estrangeiro' => 'Não se Aplica',
            'tempo_reside_mun' => 3.5,
            'muni_anterior' => array(["estado"=>1,"municipio"=>2],["estado"=>4,"municipio"=>3]),
            'port_deficiencia' => false,
            'tipo_deficiencia' => 'Não se Aplica',
            'servico_utilizado' => array(["servico"=>1,"nome"=>"Centro de Saúde Dr Oscarino de Campos Borges"]),
        ];


        $this->cadastro_compara = [
            'nome' => 'Sophia Agatha Laís Pereira',
            'data_nascimento' => '1988-02-01',
            'rg' => '19.211.535-2',
            'cpf' => '926.622.331-09',
            'nis' => '37414972104',
            'trabalha' => true,
            'remunerado' => true,
            'ocupacao' => 'Vendedora',
            'escolaridade' => 2,
            'orientacao' => 1,
            'etnia' => 2,
            'estado_civil' => 1,
            'possui_filhos' => true,
            'dorme_rua' => false,
            'resido_com' => 1,
            'sit_moradia' => 1,
            'cep' => '78043-128',
            'endereco' => 'Rua das Rosas',
            'numero' => '479',
            'complemento' => 'não informado',
            'bairro' => 'Jardim Cuiabá',
            'estado' => 1,
            'municipio' => 1,
            'outro_end_loca' => 'não informado',
            'nacionalidade_br' => true,
            'estado_nascimento' => 1,
            'municipio_nascimento' => 3,
            'pais_cidade_estrangeiro' => 'Não se Aplica',
            'tempo_reside_mun' => 3.5,
            'port_deficiencia' => false,
            'tipo_deficiencia' => 'Não se Aplica',
        ];


        $this->edicao_correto = [
            'nome' => 'Clarice Lorena Assunção',
            'data_nascimento' => '1996-03-04',
            'rg' => '47.502.312-2',
            'cpf' => '933.407.401-94',
            'trabalha' => false,
            'remunerado' => false,
            'ocupacao' => 'Nenhuma',
            'escolaridade' => 1,
            'orientacao' => 1,
            'etnia' => 3,
            'estado_civil' => 1,
            'possui_filhos' => true,
            'filhos' => array(["idade"=>4,"fillho_reside_com"=>2,"port_deficiencia"=>false],["idade"=>13,"fillho_reside_com"=>3,"port_deficiencia"=>true]),
            'dorme_rua' => true,
            'outro_end_loca' => 'Sempre fico ao lado do Prédio XXXX',
            'telefone' => array(["telefone"=>"(65) 99866-6767"]),
            'nacionalidade_br' => false,
            'pais_cidade_estrangeiro' => 'Boliviana, Sucre',
            'tempo_reside_mun' => 5.5,
            'muni_anterior' => array(["estado"=>1,"municipio"=>7],["estado"=>3,"municipio"=>2],["estado"=>7,"municipio"=>2]),
            'port_deficiencia' => true,
            'tipo_deficiencia' => 'Deficiência Auditiva grave',
            'servico_utilizado' => array(["servico"=>1,"nome"=>"Centro de Saúde Dr Oscarino de Campos Borges"],["servico"=>2,"nome"=>"Creche Municipal Josefa Da Silva Parente"]),
        ];


        $this->edicao_compara = [
            'nome' => 'Clarice Lorena Assunção',
            'data_nascimento' => '1996-03-04',
            'rg' => '47.502.312-2',
            'cpf' => '933.407.401-94',
            'trabalha' => false,
            'remunerado' => false,
            'ocupacao' => 'Nenhuma',
            'escolaridade' => 1,
            'orientacao' => 1,
            'etnia' => 3,
            'estado_civil' => 1,
            'possui_filhos' => true,
            'dorme_rua' => true,
            'outro_end_loca' => 'Sempre fico ao lado do Prédio XXXX',
            'nacionalidade_br' => false,
            'pais_cidade_estrangeiro' => 'Boliviana, Sucre',
            'tempo_reside_mun' => 5.5,
            'port_deficiencia' => true,
            'tipo_deficiencia' => 'Deficiência Auditiva grave',
        ];


        $this->todos_atendimentos_correto = [
            'nome' => 'Sophia Agatha Laís Pereira',
            'data_nascimento' => '1988-02-01',
            'rg' => '19.211.535-2',
            'cpf' => '926.622.331-09',
            'nis' => '37414972104',
            'trabalha' => true,
            'remunerado' => true,
            'ocupacao' => 'Vendedora',
            'escolaridade' => 2,
            'orientacao' => 1,
            'etnia' => 2,
            'estado_civil' => 1,
            'possui_filhos' => true,
            'filhos' => array(["idade"=>12,"fillho_reside_com"=>1,"port_deficiencia"=>false]),
            'dorme_rua' => false,
            'resido_com' => 1,
            'sit_moradia' => 1,
            'cep' => '78043-128',
            'endereco' => 'Rua das Rosas',
            'numero' => '479',
            'complemento' => 'não informado',
            'bairro' => 'Jardim Cuiabá',
            'estado' => 1,
            'municipio' => 1,
            'outro_end_loca' => 'não informado',
            'telefone' => array(["telefone"=>"(65) 3698-5249"],["telefone"=>"(65) 99121-7026"]),
            'nacionalidade_br' => true,
            'estado_nascimento' => 1,
            'municipio_nascimento' => 3,
            'pais_cidade_estrangeiro' => 'Não se Aplica',
            'tempo_reside_mun' => 3.5,
            'muni_anterior' => array(["estado"=>1,"municipio"=>2],["estado"=>4,"municipio"=>3]),
            'port_deficiencia' => false,
            'tipo_deficiencia' => 'Não se Aplica',
            'servico_utilizado' => array(["servico"=>1,"nome"=>"Centro de Saúde Dr Oscarino de Campos Borges"]),
        ];


        $this->todos_atendimentos_compara = [
            'nome' => 'Sophia Agatha Laís Pereira',
            'data_nascimento' => '1988-02-01',
            'rg' => '19.211.535-2',
            'cpf' => '926.622.331-09',
            'nis' => '37414972104',
            'trabalha' => true,
            'remunerado' => true,
            'ocupacao' => 'Vendedora',
            'escolaridade' => 2,
            'orientacao' => 1,
            'etnia' => 2,
            'estado_civil' => 1,
            'possui_filhos' => true,
            'dorme_rua' => false,
            'resido_com' => 1,
            'sit_moradia' => 1,
            'cep' => '78043-128',
            'endereco' => 'Rua das Rosas',
            'numero' => '479',
            'complemento' => 'não informado',
            'bairro' => 'Jardim Cuiabá',
            'estado' => 1,
            'municipio' => 1,
            'outro_end_loca' => 'não informado',
            'nacionalidade_br' => true,
            'estado_nascimento' => 1,
            'municipio_nascimento' => 3,
            'pais_cidade_estrangeiro' => 'Não se Aplica',
            'tempo_reside_mun' => 3.5,
            'port_deficiencia' => false,
            'tipo_deficiencia' => 'Não se Aplica',
        ];

    }


    /** @test */
    public function listar_get_sem_login()
    {
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->get('/api/mulher');

        $response
        -> assertStatus(401)
        -> assertJson(['message' => 'Unauthenticated.']);

    }


    /** @test */
    public function listar_get_com_login()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->get('/api/mulher');

        $response
        -> assertStatus(200);

    }


    /** @test */
    public function salvar_post_sem_login()
    {
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->post('/api/mulher');

        $response
        -> assertStatus(401)
        -> assertJson(['message' => 'Unauthenticated.']);

    }


    /** @test */
    public function editar_put_sem_login()
    {
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/1',[]);

        $response
        -> assertStatus(401)
        -> assertJson(['message' => 'Unauthenticated.']);

    }


    /** @test */
    public function campos_listar()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$this->cadastro_correto);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->get('/api/mulher');

        $response
        -> assertStatus(200)
        -> assertJsonStructure(['*' => ['id', 'nome', 'rg', 'cpf', 'nis']]);

    }


    /** @test */
    public function salvar_correto()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$this->cadastro_correto);

        $response
        ->assertStatus(201)
        ->assertJsonFragment($this->cadastro_compara);

    }


    /** @test */
    public function salvar_nome_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                                    'nome' => '']);

        $response->assertJsonValidationErrors([
                   'nome' => __('validation.required',['attribute' => 'Nome'])
        ]);

    }


    /** @test */
    public function salvar_data_nascimento_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                                    'data_nascimento' => '']);

        $response->assertJsonValidationErrors([
                   'data_nascimento' => __('validation.required',['attribute' => 'Data de Nascimento'])
        ]);

    }


    /** @test */
    public function salvar_escolaridade_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                                    'escolaridade' => '']);

        $response->assertJsonValidationErrors([
                   'escolaridade' => __('validation.required',['attribute' => 'Escolaridade'])
        ]);

    }


    /** @test */
    public function salvar_orientacao_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                                    'orientacao' => '']);

        $response->assertJsonValidationErrors([
                   'orientacao' => __('validation.required',['attribute' => 'Orientação Sexual'])
        ]);

    }


    /** @test */
    public function salvar_etnia_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                                    'etnia' => '']);

        $response->assertJsonValidationErrors([
                   'etnia' => __('validation.required',['attribute' => 'Etnia/Raça'])
        ]);

    }


    /** @test */
    public function salvar_estado_civil_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                                    'estado_civil' => '']);

        $response->assertJsonValidationErrors([
                   'estado_civil' => __('validation.required',['attribute' => 'Estado Civil'])
        ]);

    }


    /** @test */
    public function salvar_tempo_reside_mun_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                                    'tempo_reside_mun' => '']);

        $response->assertJsonValidationErrors([
                   'tempo_reside_mun' => __('validation.required',['attribute' => 'Quanto tempo reside no Município (Anos)'])
        ]);

    }


    /** @test */
    public function salvar_ocupacao_obrigatorio_se_trabalha_true()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->postJson('/api/mulher',[
                'trabalha' => true,
                'ocupacao' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'ocupacao' => __('validation.required_if',['attribute' => 'Ocupação',
                                                                         'other' => 'Trabalha',
                                                                         'value' => 'true'
                                                                         ])
        ]);

    }


    /** @test */
    public function salvar_resido_com_obrigatorio_se_dorme_rua_false()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->postJson('/api/mulher',[
                'dorme_rua' => false,
                'resido_com' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'resido_com' => __('validation.required_if',['attribute' => 'Reside Com',
                                                                         'other' => 'Dorme na Rua',
                                                                         'value' => 'false'
                                                                         ])
        ]);

    }


    /** @test */
    public function salvar_sit_moradia_obrigatorio_se_dorme_rua_false()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->postJson('/api/mulher',[
                'dorme_rua' => false,
                'sit_moradia' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'sit_moradia' => __('validation.required_if',['attribute' => 'Situação da Moradia',
                                                                         'other' => 'Dorme na Rua',
                                                                         'value' => 'false'
                                                                         ])
        ]);

    }


    /** @test */
    public function salvar_quem_cedeu_moradia_obrigatorio_se_sit_moradia_3()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->postJson('/api/mulher',[
                'sit_moradia' => 3,
                'quem_cedeu_moradia' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'quem_cedeu_moradia' => __('validation.required',['attribute' => 'Quem Cedeu a Moradia'])
        ]);

    }


    /** @test */
    public function salvar_cep_obrigatorio_se_dorme_rua_false()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->postJson('/api/mulher',[
                'dorme_rua' => false,
                'cep' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'cep' => __('validation.required_if',['attribute' => 'CEP',
                                                                         'other' => 'Dorme na Rua',
                                                                         'value' => 'false'
                                                                         ])
        ]);

    }


    /** @test */
    public function salvar_endereco_obrigatorio_se_dorme_rua_false()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->postJson('/api/mulher',[
                'dorme_rua' => false,
                'endereco' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'endereco' => __('validation.required_if',['attribute' => 'Endereço',
                                                                         'other' => 'Dorme na Rua',
                                                                         'value' => 'false'
                                                                         ])
        ]);

    }


    /** @test */
    public function salvar_numero_obrigatorio_se_dorme_rua_false()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->postJson('/api/mulher',[
                'dorme_rua' => false,
                'numero' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'numero' => __('validation.required_if',['attribute' => 'Número',
                                                                         'other' => 'Dorme na Rua',
                                                                         'value' => 'false'
                                                                         ])
        ]);

    }


    /** @test */
    public function salvar_bairro_obrigatorio_se_dorme_rua_false()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->postJson('/api/mulher',[
                'dorme_rua' => false,
                'bairro' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'bairro' => __('validation.required_if',['attribute' => 'Bairro',
                                                                         'other' => 'Dorme na Rua',
                                                                         'value' => 'false'
                                                                         ])
        ]);

    }


    /** @test */
    public function salvar_estado_obrigatorio_se_dorme_rua_false()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->postJson('/api/mulher',[
                'dorme_rua' => false,
                'estado' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'estado' => __('validation.required_if',['attribute' => 'Estado',
                                                                         'other' => 'Dorme na Rua',
                                                                         'value' => 'false'
                                                                         ])
        ]);

    }


    /** @test */
    public function salvar_municipio_obrigatorio_se_dorme_rua_false()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->postJson('/api/mulher',[
                'dorme_rua' => false,
                'municipio' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'municipio' => __('validation.required_if',['attribute' => 'Município',
                                                                         'other' => 'Dorme na Rua',
                                                                         'value' => 'false'
                                                                         ])
        ]);

    }


    /** @test */
    public function salvar_estado_nascimento_obrigatorio_se_nacionalidade_br_true()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->postJson('/api/mulher',[
                'nacionalidade_br' => true,
                'estado_nascimento' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'estado_nascimento' => __('validation.required_if',['attribute' => 'Estado de Nascimento',
                                                                         'other' => 'Nacionalidade Brasileira',
                                                                         'value' => 'true'
                                                                         ])
        ]);

    }


    /** @test */
    public function salvar_municipio_nascimento_obrigatorio_se_nacionalidade_br_true()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->postJson('/api/mulher',[
                'nacionalidade_br' => true,
                'municipio_nascimento' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'municipio_nascimento' => __('validation.required_if',['attribute' => 'Município de Nascimento',
                                                                         'other' => 'Nacionalidade Brasileira',
                                                                         'value' => 'true'
                                                                         ])
        ]);

    }


    /** @test */
    public function salvar_pais_cidade_estrangeiro_obrigatorio_se_nacionalidade_br_false()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->postJson('/api/mulher',[
                'nacionalidade_br' => false,
                'pais_cidade_estrangeiro' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'pais_cidade_estrangeiro' => __('validation.required_if',['attribute' => 'País e Cidade para Estrangeiro',
                                                                         'other' => 'Nacionalidade Brasileira',
                                                                         'value' => 'false'
                                                                         ])
        ]);

    }


    /** @test */
    public function salvar_tipo_deficiencia_obrigatorio_se_port_deficiencia_true()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->postJson('/api/mulher',[
                'port_deficiencia' => true,
                'tipo_deficiencia' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'tipo_deficiencia' => __('validation.required_if',['attribute' => 'Tipo de Deficiência',
                                                                         'other' => 'Portadora de Deficiência',
                                                                         'value' => 'true'
                                                                         ])
        ]);

    }


    /** @test */
    public function salvar_nome_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'nome' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'nome' => __('validation.string',['attribute' => 'Nome'])
        ]);

    }


    /** @test */
    public function salvar_data_nascimento_data()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'data_nascimento' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'data_nascimento' => __('validation.date',['attribute' => 'Data de Nascimento'])
        ]);

    }


    /** @test */
    public function salvar_rg_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'rg' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'rg' => __('validation.string',['attribute' => 'RG'])
        ]);

    }


    /** @test */
    public function salvar_cpf_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'cpf' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'cpf' => __('validation.string',['attribute' => 'CPF'])
        ]);

    }


    /** @test */
    public function salvar_nis_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'nis' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'nis' => __('validation.string',['attribute' => 'NIS'])
        ]);

    }


    /** @test */
    public function salvar_ocupacao_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'ocupacao' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'ocupacao' => __('validation.string',['attribute' => 'Ocupação'])
        ]);

    }


    /** @test */
    public function salvar_filhos_n_idade_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'filhos' => array(['idade' => 'ABCDEF'])
                ]);

        $response-> assertJsonValidationErrors([
            'filhos.0.idade' => __('validation.integer',['attribute' => 'Idade do Filho'])
        ]);

    }


    /** @test */
    public function salvar_quem_cedeu_moradia_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'quem_cedeu_moradia' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'quem_cedeu_moradia' => __('validation.string',['attribute' => 'Quem Cedeu a Moradia'])
        ]);

    }


    /** @test */
    public function salvar_cep_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'cep' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'cep' => __('validation.string',['attribute' => 'CEP'])
        ]);

    }


    /** @test */
    public function salvar_endereco_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'endereco' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'endereco' => __('validation.string',['attribute' => 'Endereço'])
        ]);

    }


    /** @test */
    public function salvar_numero_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'numero' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'numero' => __('validation.string',['attribute' => 'Número'])
        ]);

    }


    /** @test */
    public function salvar_complemento_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'complemento' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'complemento' => __('validation.string',['attribute' => 'Complemento'])
        ]);

    }


    /** @test */
    public function salvar_bairro_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'bairro' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'bairro' => __('validation.string',['attribute' => 'Bairro'])
        ]);

    }


    /** @test */
    public function salvar_outro_end_loca_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'outro_end_loca' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'outro_end_loca' => __('validation.string',['attribute' => 'Outro Endereço para Localização'])
        ]);

    }


    /** @test */
    public function salvar_telefone_n_telefone_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'telefone' => array(['telefone' => 999])
                ]);

        $response-> assertJsonValidationErrors([
            'telefone.0.telefone' => __('validation.string',['attribute' => 'Telefone'])
        ]);

    }


    /** @test */
    public function salvar_pais_cidade_estrangeiro_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'pais_cidade_estrangeiro' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'pais_cidade_estrangeiro' => __('validation.string',['attribute' => 'País e Cidade para Estrangeiro'])
        ]);

    }


    /** @test */
    public function salvar_tempo_reside_mun_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'tempo_reside_mun' => 'ABCDEF'
                ]);

        $response-> assertJsonValidationErrors([
            'tempo_reside_mun' => __('validation.numeric',['attribute' => 'Quanto tempo reside no Município (Anos)'])
        ]);

    }


    /** @test */
    public function salvar_tipo_deficiencia_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'tipo_deficiencia' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'tipo_deficiencia' => __('validation.string',['attribute' => 'Tipo de Deficiência'])
        ]);

    }


    /** @test */
    public function salvar_servico_utilizado_n_nome_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'servico_utilizado' => array(['nome' => 999])
                ]);

        $response-> assertJsonValidationErrors([
            'servico_utilizado.0.nome' => __('validation.string',['attribute' => 'Nome do Local do Serviço'])
        ]);

    }


    /** @test */
    public function salvar_nome_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                'nome' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'nome' => __('validation.max.string',['attribute' => 'Nome', 'max' => '500'])
        ]);

    }


    /** @test */
    public function salvar_nome_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $obj['nome'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->cadastro_compara;
        $objcompara['nome'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $response
        ->assertJsonMissingValidationErrors('nome');

    }


    /** @test */
    public function salvar_rg_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                'rg' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'rg' => __('validation.max.string',['attribute' => 'RG', 'max' => '100'])
        ]);

    }


    /** @test */
    public function salvar_rg_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $obj['rg'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->cadastro_compara;
        $objcompara['rg'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $response
        ->assertJsonMissingValidationErrors('rg');

    }


    /** @test */
    public function salvar_nis_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolo';

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                'nis' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'nis' => __('validation.max.string',['attribute' => 'NIS', 'max' => '11'])
        ]);

    }


    /** @test */
    public function salvar_nis_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum';

        $obj = $this->cadastro_correto;
        $obj['nis'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->cadastro_compara;
        $objcompara['nis'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $response
        ->assertJsonMissingValidationErrors('nis');

    }


    /** @test */
    public function salvar_ocupacao_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                'ocupacao' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'ocupacao' => __('validation.max.string',['attribute' => 'Ocupação', 'max' => '500'])
        ]);

    }


    /** @test */
    public function salvar_ocupacao_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $obj['ocupacao'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->cadastro_compara;
        $objcompara['ocupacao'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $response
        ->assertJsonMissingValidationErrors('ocupacao');

    }


    /** @test */
    public function salvar_filhos_n_idade_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                'filhos' =>  array(['idade' => 105])
        ]);

        $response-> assertJsonValidationErrors([
            'filhos.0.idade' => __('validation.max.numeric',['attribute' => 'Idade do Filho', 'max' => '100'])
        ]);

    }


    /** @test */
    public function salvar_filhos_n_idade_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $obj['filhos'] =  array(['idade' => 100]);
        $objcompara = $this->cadastro_compara;
        $objcompara['filhos'] =  array(['idade' => 100]);
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $response
        ->assertJsonMissingValidationErrors('filhos.0.idade');

    }


    /** @test */
    public function salvar_quem_cedeu_moradia_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                'quem_cedeu_moradia' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'quem_cedeu_moradia' => __('validation.max.string',['attribute' => 'Quem Cedeu a Moradia', 'max' => '200'])
        ]);

    }


    /** @test */
    public function salvar_quem_cedeu_moradia_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $obj['quem_cedeu_moradia'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->cadastro_compara;
        $objcompara['quem_cedeu_moradia'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $response
        ->assertJsonMissingValidationErrors('quem_cedeu_moradia');

    }


    /** @test */
    public function salvar_endereco_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                'endereco' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'endereco' => __('validation.max.string',['attribute' => 'Endereço', 'max' => '500'])
        ]);

    }


    /** @test */
    public function salvar_endereco_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $obj['endereco'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->cadastro_compara;
        $objcompara['endereco'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $response
        ->assertJsonMissingValidationErrors('endereco');

    }


    /** @test */
    public function salvar_numero_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                'numero' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'numero' => __('validation.max.string',['attribute' => 'Número', 'max' => '200'])
        ]);

    }


    /** @test */
    public function salvar_numero_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $obj['numero'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->cadastro_compara;
        $objcompara['numero'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $response
        ->assertJsonMissingValidationErrors('numero');

    }


    /** @test */
    public function salvar_complemento_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                'complemento' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'complemento' => __('validation.max.string',['attribute' => 'Complemento', 'max' => '200'])
        ]);

    }


    /** @test */
    public function salvar_complemento_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $obj['complemento'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->cadastro_compara;
        $objcompara['complemento'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $response
        ->assertJsonMissingValidationErrors('complemento');

    }


    /** @test */
    public function salvar_bairro_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                'bairro' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'bairro' => __('validation.max.string',['attribute' => 'Bairro', 'max' => '200'])
        ]);

    }


    /** @test */
    public function salvar_bairro_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $obj['bairro'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->cadastro_compara;
        $objcompara['bairro'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $response
        ->assertJsonMissingValidationErrors('bairro');

    }


    /** @test */
    public function salvar_outro_end_loca_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                'outro_end_loca' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'outro_end_loca' => __('validation.max.string',['attribute' => 'Outro Endereço para Localização', 'max' => '5000'])
        ]);

    }


    /** @test */
    public function salvar_outro_end_loca_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $obj['outro_end_loca'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->cadastro_compara;
        $objcompara['outro_end_loca'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $response
        ->assertJsonMissingValidationErrors('outro_end_loca');

    }


    /** @test */
    public function salvar_pais_cidade_estrangeiro_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                'pais_cidade_estrangeiro' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'pais_cidade_estrangeiro' => __('validation.max.string',['attribute' => 'País e Cidade para Estrangeiro', 'max' => '200'])
        ]);

    }


    /** @test */
    public function salvar_pais_cidade_estrangeiro_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $obj['pais_cidade_estrangeiro'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->cadastro_compara;
        $objcompara['pais_cidade_estrangeiro'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $response
        ->assertJsonMissingValidationErrors('pais_cidade_estrangeiro');

    }


    /** @test */
    public function salvar_tempo_reside_mun_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                'tempo_reside_mun' => 125
        ]);

        $response-> assertJsonValidationErrors([
            'tempo_reside_mun' => __('validation.max.numeric',['attribute' => 'Quanto tempo reside no Município (Anos)', 'max' => '120'])
        ]);

    }


    /** @test */
    public function salvar_tempo_reside_mun_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $obj['tempo_reside_mun'] = 120;
        $objcompara = $this->cadastro_compara;
        $objcompara['tempo_reside_mun'] = 120;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $response
        ->assertJsonMissingValidationErrors('tempo_reside_mun');

    }


    /** @test */
    public function salvar_tipo_deficiencia_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                'tipo_deficiencia' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'tipo_deficiencia' => __('validation.max.string',['attribute' => 'Tipo de Deficiência', 'max' => '500'])
        ]);

    }


    /** @test */
    public function salvar_tipo_deficiencia_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $obj['tipo_deficiencia'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->cadastro_compara;
        $objcompara['tipo_deficiencia'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $response
        ->assertJsonMissingValidationErrors('tipo_deficiencia');

    }


    /** @test */
    public function salvar_servico_utilizado_n_nome_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                'servico_utilizado' =>  array(['nome' => $txt_Lorem_ipsum_maior])
        ]);

        $response-> assertJsonValidationErrors([
            'servico_utilizado.0.nome' => __('validation.max.string',['attribute' => 'Nome do Local do Serviço', 'max' => '500'])
        ]);

    }


    /** @test */
    public function salvar_servico_utilizado_n_nome_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $obj['servico_utilizado'] =  array(['nome' => $txt_Lorem_ipsum_max]);
        $objcompara = $this->cadastro_compara;
        $objcompara['servico_utilizado'] =  array(['nome' => $txt_Lorem_ipsum_max]);
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $response
        ->assertJsonMissingValidationErrors('servico_utilizado.0.nome');

    }


    /** @test */
    public function salvar_nome_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                'nome' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'nome' => __('validation.min.string',['attribute' => 'Nome', 'min' => '2'])
        ]);

    }


    /** @test */
    public function salvar_nome_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $obj['nome'] = 'Lo';
        $objcompara = $this->cadastro_compara;
        $objcompara['nome'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $response
        ->assertJsonMissingValidationErrors('nome');

    }


    /** @test */
    public function salvar_rg_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                'rg' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'rg' => __('validation.min.string',['attribute' => 'RG', 'min' => '2'])
        ]);

    }


    /** @test */
    public function salvar_rg_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $obj['rg'] = 'Lo';
        $objcompara = $this->cadastro_compara;
        $objcompara['rg'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $response
        ->assertJsonMissingValidationErrors('rg');

    }


    /** @test */
    public function salvar_nis_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                'nis' => 'Lorem_ipsu'
        ]);

        $response-> assertJsonValidationErrors([
            'nis' => __('validation.min.string',['attribute' => 'NIS', 'min' => '11'])
        ]);

    }


    /** @test */
    public function salvar_nis_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $obj['nis'] = 'Lorem_ipsum';
        $objcompara = $this->cadastro_compara;
        $objcompara['nis'] = 'Lorem_ipsum';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $response
        ->assertJsonMissingValidationErrors('nis');

    }


    /** @test */
    public function salvar_ocupacao_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                'ocupacao' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'ocupacao' => __('validation.min.string',['attribute' => 'Ocupação', 'min' => '2'])
        ]);

    }


    /** @test */
    public function salvar_ocupacao_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $obj['ocupacao'] = 'Lo';
        $objcompara = $this->cadastro_compara;
        $objcompara['ocupacao'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $response
        ->assertJsonMissingValidationErrors('ocupacao');

    }


    /** @test */
    public function salvar_filhos_n_idade_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $obj['filhos'] =  array(['idade' => 0]);
        $objcompara = $this->cadastro_compara;
        $objcompara['filhos'] =  array(['idade' => 0]);
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $response
        ->assertJsonMissingValidationErrors('filhos.0.idade');

    }


    /** @test */
    public function salvar_quem_cedeu_moradia_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                'quem_cedeu_moradia' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'quem_cedeu_moradia' => __('validation.min.string',['attribute' => 'Quem Cedeu a Moradia', 'min' => '2'])
        ]);

    }


    /** @test */
    public function salvar_quem_cedeu_moradia_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $obj['quem_cedeu_moradia'] = 'Lo';
        $objcompara = $this->cadastro_compara;
        $objcompara['quem_cedeu_moradia'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $response
        ->assertJsonMissingValidationErrors('quem_cedeu_moradia');

    }


    /** @test */
    public function salvar_endereco_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                'endereco' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'endereco' => __('validation.min.string',['attribute' => 'Endereço', 'min' => '2'])
        ]);

    }


    /** @test */
    public function salvar_endereco_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $obj['endereco'] = 'Lo';
        $objcompara = $this->cadastro_compara;
        $objcompara['endereco'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $response
        ->assertJsonMissingValidationErrors('endereco');

    }


    /** @test */
    public function salvar_numero_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $obj['numero'] = 'L';
        $objcompara = $this->cadastro_compara;
        $objcompara['numero'] = 'L';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $response
        ->assertJsonMissingValidationErrors('numero');

    }


    /** @test */
    public function salvar_complemento_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $obj['complemento'] = 'L';
        $objcompara = $this->cadastro_compara;
        $objcompara['complemento'] = 'L';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $response
        ->assertJsonMissingValidationErrors('complemento');

    }


    /** @test */
    public function salvar_bairro_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $obj['bairro'] = 'L';
        $objcompara = $this->cadastro_compara;
        $objcompara['bairro'] = 'L';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $response
        ->assertJsonMissingValidationErrors('bairro');

    }


    /** @test */
    public function salvar_outro_end_loca_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                'outro_end_loca' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'outro_end_loca' => __('validation.min.string',['attribute' => 'Outro Endereço para Localização', 'min' => '2'])
        ]);

    }


    /** @test */
    public function salvar_outro_end_loca_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $obj['outro_end_loca'] = 'Lo';
        $objcompara = $this->cadastro_compara;
        $objcompara['outro_end_loca'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $response
        ->assertJsonMissingValidationErrors('outro_end_loca');

    }


    /** @test */
    public function salvar_pais_cidade_estrangeiro_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                'pais_cidade_estrangeiro' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'pais_cidade_estrangeiro' => __('validation.min.string',['attribute' => 'País e Cidade para Estrangeiro', 'min' => '2'])
        ]);

    }


    /** @test */
    public function salvar_pais_cidade_estrangeiro_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $obj['pais_cidade_estrangeiro'] = 'Lo';
        $objcompara = $this->cadastro_compara;
        $objcompara['pais_cidade_estrangeiro'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $response
        ->assertJsonMissingValidationErrors('pais_cidade_estrangeiro');

    }


    /** @test */
    public function salvar_tempo_reside_mun_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $obj['tempo_reside_mun'] = 0;
        $objcompara = $this->cadastro_compara;
        $objcompara['tempo_reside_mun'] = 0;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $response
        ->assertJsonMissingValidationErrors('tempo_reside_mun');

    }


    /** @test */
    public function salvar_tipo_deficiencia_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                'tipo_deficiencia' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'tipo_deficiencia' => __('validation.min.string',['attribute' => 'Tipo de Deficiência', 'min' => '2'])
        ]);

    }


    /** @test */
    public function salvar_tipo_deficiencia_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $obj['tipo_deficiencia'] = 'Lo';
        $objcompara = $this->cadastro_compara;
        $objcompara['tipo_deficiencia'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $response
        ->assertJsonMissingValidationErrors('tipo_deficiencia');

    }


    /** @test */
    public function salvar_servico_utilizado_n_nome_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                'servico_utilizado' =>  array(['nome' => 'L'])
        ]);

        $response-> assertJsonValidationErrors([
            'servico_utilizado.0.nome' => __('validation.min.string',['attribute' => 'Nome do Local do Serviço', 'min' => '2'])
        ]);

    }


    /** @test */
    public function salvar_servico_utilizado_n_nome_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $obj['servico_utilizado'] =  array(['nome' => 'Lo']);
        $objcompara = $this->cadastro_compara;
        $objcompara['servico_utilizado'] =  array(['nome' => 'Lo']);
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $response
        ->assertJsonMissingValidationErrors('servico_utilizado.0.nome');

    }


    /** @test */
    public function salvar_escolaridade_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'escolaridade' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'escolaridade' => __('validation.exists',['attribute' => 'Escolaridade'])
        ]);

    }


    /** @test */
    public function salvar_orientacao_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'orientacao' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'orientacao' => __('validation.exists',['attribute' => 'Orientação Sexual'])
        ]);

    }


    /** @test */
    public function salvar_etnia_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'etnia' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'etnia' => __('validation.exists',['attribute' => 'Etnia/Raça'])
        ]);

    }


    /** @test */
    public function salvar_estado_civil_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'estado_civil' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'estado_civil' => __('validation.exists',['attribute' => 'Estado Civil'])
        ]);

    }


    /** @test */
    public function salvar_filhos_n_fillho_reside_com_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'filhos' => array(['fillho_reside_com' => 9999])
        ]);

        $response-> assertJsonValidationErrors([
            'filhos.0.fillho_reside_com' => __('validation.exists',['attribute' => 'Filho reside com'])
        ]);

    }


    /** @test */
    public function salvar_resido_com_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'resido_com' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'resido_com' => __('validation.exists',['attribute' => 'Reside Com'])
        ]);

    }


    /** @test */
    public function salvar_sit_moradia_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'sit_moradia' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'sit_moradia' => __('validation.exists',['attribute' => 'Situação da Moradia'])
        ]);

    }


    /** @test */
    public function salvar_estado_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'estado' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'estado' => __('validation.exists',['attribute' => 'Estado'])
        ]);

    }


    /** @test */
    public function salvar_municipio_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'municipio' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'municipio' => __('validation.exists',['attribute' => 'Município'])
        ]);

    }


    /** @test */
    public function salvar_estado_nascimento_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'estado_nascimento' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'estado_nascimento' => __('validation.exists',['attribute' => 'Estado de Nascimento'])
        ]);

    }


    /** @test */
    public function salvar_municipio_nascimento_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'municipio_nascimento' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'municipio_nascimento' => __('validation.exists',['attribute' => 'Município de Nascimento'])
        ]);

    }


    /** @test */
    public function salvar_muni_anterior_n_estado_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'muni_anterior' => array(['estado' => 9999])
        ]);

        $response-> assertJsonValidationErrors([
            'muni_anterior.0.estado' => __('validation.exists',['attribute' => 'Estado'])
        ]);

    }


    /** @test */
    public function salvar_muni_anterior_n_municipio_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'muni_anterior' => array(['municipio' => 9999])
        ]);

        $response-> assertJsonValidationErrors([
            'muni_anterior.0.municipio' => __('validation.exists',['attribute' => 'Município'])
        ]);

    }


    /** @test */
    public function salvar_servico_utilizado_n_servico_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/mulher',[
                'servico_utilizado' => array(['servico' => 9999])
        ]);

        $response-> assertJsonValidationErrors([
            'servico_utilizado.0.servico' => __('validation.exists',['attribute' => 'Serviço'])
        ]);

    }


    /** @test */
    public function salvar_cpf_cpf()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                'cpf' => '99999999999'
            ]);

        $response-> assertJsonValidationErrors([
            'cpf' => 'O campo CPF não é um CPF válido.'
        ]);

    }


    /** @test */
    public function salvar_cep_cep()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                'cep' => '99999999'
            ]);

        $response-> assertJsonValidationErrors([
            'cep' => 'O campo CEP não possui um formato válido de CEP.'
        ]);

    }


    /** @test */
    public function salvar_telefone_n_telefone_celular_com_ddd()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',[
                'telefone' => array(['telefone' => '999'])
            ]);

        $response-> assertJsonValidationErrors([
            'telefone.0.telefone' => 'O campo Telefone não é um celular com DDD válido.'
        ]);

    }


    /** @test */
    public function salvar_cpf_unique()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$this->cadastro_correto);
        $response->assertStatus(201);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$this->cadastro_correto);

        $response->assertJsonValidationErrors([
                   'cpf' => __('validation.unique',['attribute' => 'CPF'])
        ]);

    }


    /** @test */
    public function editar_correto()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];


        $obj = $this->edicao_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,$obj);

        $response
        ->assertStatus(200)
        ->assertJsonFragment($this->edicao_compara);

    }
    /** @test */
    public function editar_correto_mantendo_objetos()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj = $this->edicao_correto;
        $obj['filhos'][0]['id'] = 1;
        $obj['telefone'][0]['id'] = 1;
        $obj['muni_anterior'][0]['id'] = 1;
        $obj['servico_utilizado'][0]['id'] = 1;

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,$obj);

        $response
        ->assertStatus(200)
        ->assertJsonFragment($this->edicao_compara);

    }
    /** @test */
    public function editar_nome_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                                    'nome' => '']);

        $response->assertJsonValidationErrors([
                   'nome' => __('validation.required',['attribute' => 'Nome'])
        ]);

    }


    /** @test */
    public function editar_data_nascimento_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                                    'data_nascimento' => '']);

        $response->assertJsonValidationErrors([
                   'data_nascimento' => __('validation.required',['attribute' => 'Data de Nascimento'])
        ]);

    }


    /** @test */
    public function editar_escolaridade_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                                    'escolaridade' => '']);

        $response->assertJsonValidationErrors([
                   'escolaridade' => __('validation.required',['attribute' => 'Escolaridade'])
        ]);

    }


    /** @test */
    public function editar_orientacao_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                                    'orientacao' => '']);

        $response->assertJsonValidationErrors([
                   'orientacao' => __('validation.required',['attribute' => 'Orientação Sexual'])
        ]);

    }


    /** @test */
    public function editar_etnia_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                                    'etnia' => '']);

        $response->assertJsonValidationErrors([
                   'etnia' => __('validation.required',['attribute' => 'Etnia/Raça'])
        ]);

    }


    /** @test */
    public function editar_estado_civil_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                                    'estado_civil' => '']);

        $response->assertJsonValidationErrors([
                   'estado_civil' => __('validation.required',['attribute' => 'Estado Civil'])
        ]);

    }


    /** @test */
    public function editar_tempo_reside_mun_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                                    'tempo_reside_mun' => '']);

        $response->assertJsonValidationErrors([
                   'tempo_reside_mun' => __('validation.required',['attribute' => 'Quanto tempo reside no Município (Anos)'])
        ]);

    }


    /** @test */
    public function editar_ocupacao_obrigatorio_se_trabalha_true()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'trabalha' => true,
                'ocupacao' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'ocupacao' => __('validation.required_if',['attribute' => 'Ocupação',
                                                                         'other' => 'Trabalha',
                                                                         'value' => 'true'
                                                                         ])
        ]);

    }


    /** @test */
    public function editar_resido_com_obrigatorio_se_dorme_rua_false()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'dorme_rua' => false,
                'resido_com' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'resido_com' => __('validation.required_if',['attribute' => 'Reside Com',
                                                                         'other' => 'Dorme na Rua',
                                                                         'value' => 'false'
                                                                         ])
        ]);

    }


    /** @test */
    public function editar_sit_moradia_obrigatorio_se_dorme_rua_false()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'dorme_rua' => false,
                'sit_moradia' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'sit_moradia' => __('validation.required_if',['attribute' => 'Situação da Moradia',
                                                                         'other' => 'Dorme na Rua',
                                                                         'value' => 'false'
                                                                         ])
        ]);

    }


    /** @test */
    public function editar_quem_cedeu_moradia_obrigatorio_se_sit_moradia_3()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'sit_moradia' => 3,
                'quem_cedeu_moradia' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'quem_cedeu_moradia' => __('validation.required',['attribute' => 'Quem Cedeu a Moradia'])
        ]);

    }


    /** @test */
    public function editar_cep_obrigatorio_se_dorme_rua_false()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'dorme_rua' => false,
                'cep' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'cep' => __('validation.required_if',['attribute' => 'CEP',
                                                                         'other' => 'Dorme na Rua',
                                                                         'value' => 'false'
                                                                         ])
        ]);

    }


    /** @test */
    public function editar_endereco_obrigatorio_se_dorme_rua_false()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'dorme_rua' => false,
                'endereco' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'endereco' => __('validation.required_if',['attribute' => 'Endereço',
                                                                         'other' => 'Dorme na Rua',
                                                                         'value' => 'false'
                                                                         ])
        ]);

    }


    /** @test */
    public function editar_numero_obrigatorio_se_dorme_rua_false()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'dorme_rua' => false,
                'numero' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'numero' => __('validation.required_if',['attribute' => 'Número',
                                                                         'other' => 'Dorme na Rua',
                                                                         'value' => 'false'
                                                                         ])
        ]);

    }


    /** @test */
    public function editar_bairro_obrigatorio_se_dorme_rua_false()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'dorme_rua' => false,
                'bairro' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'bairro' => __('validation.required_if',['attribute' => 'Bairro',
                                                                         'other' => 'Dorme na Rua',
                                                                         'value' => 'false'
                                                                         ])
        ]);

    }


    /** @test */
    public function editar_estado_obrigatorio_se_dorme_rua_false()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'dorme_rua' => false,
                'estado' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'estado' => __('validation.required_if',['attribute' => 'Estado',
                                                                         'other' => 'Dorme na Rua',
                                                                         'value' => 'false'
                                                                         ])
        ]);

    }


    /** @test */
    public function editar_municipio_obrigatorio_se_dorme_rua_false()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'dorme_rua' => false,
                'municipio' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'municipio' => __('validation.required_if',['attribute' => 'Município',
                                                                         'other' => 'Dorme na Rua',
                                                                         'value' => 'false'
                                                                         ])
        ]);

    }


    /** @test */
    public function editar_estado_nascimento_obrigatorio_se_nacionalidade_br_true()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'nacionalidade_br' => true,
                'estado_nascimento' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'estado_nascimento' => __('validation.required_if',['attribute' => 'Estado de Nascimento',
                                                                         'other' => 'Nacionalidade Brasileira',
                                                                         'value' => 'true'
                                                                         ])
        ]);

    }


    /** @test */
    public function editar_municipio_nascimento_obrigatorio_se_nacionalidade_br_true()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'nacionalidade_br' => true,
                'municipio_nascimento' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'municipio_nascimento' => __('validation.required_if',['attribute' => 'Município de Nascimento',
                                                                         'other' => 'Nacionalidade Brasileira',
                                                                         'value' => 'true'
                                                                         ])
        ]);

    }


    /** @test */
    public function editar_pais_cidade_estrangeiro_obrigatorio_se_nacionalidade_br_false()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'nacionalidade_br' => false,
                'pais_cidade_estrangeiro' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'pais_cidade_estrangeiro' => __('validation.required_if',['attribute' => 'País e Cidade para Estrangeiro',
                                                                         'other' => 'Nacionalidade Brasileira',
                                                                         'value' => 'false'
                                                                         ])
        ]);

    }


    /** @test */
    public function editar_tipo_deficiencia_obrigatorio_se_port_deficiencia_true()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'port_deficiencia' => true,
                'tipo_deficiencia' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'tipo_deficiencia' => __('validation.required_if',['attribute' => 'Tipo de Deficiência',
                                                                         'other' => 'Portadora de Deficiência',
                                                                         'value' => 'true'
                                                                         ])
        ]);

    }


    /** @test */
    public function editar_nome_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'nome' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'nome' => __('validation.string',['attribute' => 'Nome'])
        ]);

    }


    /** @test */
    public function editar_data_nascimento_data()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'data_nascimento' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'data_nascimento' => __('validation.date',['attribute' => 'Data de Nascimento'])
        ]);

    }


    /** @test */
    public function editar_rg_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'rg' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'rg' => __('validation.string',['attribute' => 'RG'])
        ]);

    }


    /** @test */
    public function editar_cpf_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'cpf' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'cpf' => __('validation.string',['attribute' => 'CPF'])
        ]);

    }


    /** @test */
    public function editar_nis_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'nis' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'nis' => __('validation.string',['attribute' => 'NIS'])
        ]);

    }


    /** @test */
    public function editar_ocupacao_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'ocupacao' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'ocupacao' => __('validation.string',['attribute' => 'Ocupação'])
        ]);

    }


    /** @test */
    public function editar_filhos_n_idade_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'filhos' => array(['idade' => 'ABCDEF'])
                ]);

        $response-> assertJsonValidationErrors([
            'filhos.0.idade' => __('validation.integer',['attribute' => 'Idade do Filho'])
        ]);

    }


    /** @test */
    public function editar_quem_cedeu_moradia_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'quem_cedeu_moradia' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'quem_cedeu_moradia' => __('validation.string',['attribute' => 'Quem Cedeu a Moradia'])
        ]);

    }


    /** @test */
    public function editar_cep_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'cep' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'cep' => __('validation.string',['attribute' => 'CEP'])
        ]);

    }


    /** @test */
    public function editar_endereco_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'endereco' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'endereco' => __('validation.string',['attribute' => 'Endereço'])
        ]);

    }


    /** @test */
    public function editar_numero_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'numero' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'numero' => __('validation.string',['attribute' => 'Número'])
        ]);

    }


    /** @test */
    public function editar_complemento_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'complemento' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'complemento' => __('validation.string',['attribute' => 'Complemento'])
        ]);

    }


    /** @test */
    public function editar_bairro_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'bairro' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'bairro' => __('validation.string',['attribute' => 'Bairro'])
        ]);

    }


    /** @test */
    public function editar_outro_end_loca_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'outro_end_loca' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'outro_end_loca' => __('validation.string',['attribute' => 'Outro Endereço para Localização'])
        ]);

    }


    /** @test */
    public function editar_telefone_n_telefone_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'telefone' => array(['telefone' => 999])
                ]);

        $response-> assertJsonValidationErrors([
            'telefone.0.telefone' => __('validation.string',['attribute' => 'Telefone'])
        ]);

    }


    /** @test */
    public function editar_pais_cidade_estrangeiro_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'pais_cidade_estrangeiro' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'pais_cidade_estrangeiro' => __('validation.string',['attribute' => 'País e Cidade para Estrangeiro'])
        ]);

    }


    /** @test */
    public function editar_tempo_reside_mun_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'tempo_reside_mun' => 'ABCDEF'
                ]);

        $response-> assertJsonValidationErrors([
            'tempo_reside_mun' => __('validation.numeric',['attribute' => 'Quanto tempo reside no Município (Anos)'])
        ]);

    }


    /** @test */
    public function editar_tipo_deficiencia_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'tipo_deficiencia' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'tipo_deficiencia' => __('validation.string',['attribute' => 'Tipo de Deficiência'])
        ]);

    }


    /** @test */
    public function editar_servico_utilizado_n_nome_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'servico_utilizado' => array(['nome' => 999])
                ]);

        $response-> assertJsonValidationErrors([
            'servico_utilizado.0.nome' => __('validation.string',['attribute' => 'Nome do Local do Serviço'])
        ]);

    }


    /** @test */
    public function editar_nome_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'nome' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'nome' => __('validation.max.string',['attribute' => 'Nome', 'max' => '500'])
        ]);

    }


    /** @test */
    public function editar_nome_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['nome'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->edicao_compara;
        $objcompara['nome'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('nome');

    }


    /** @test */
    public function editar_rg_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'rg' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'rg' => __('validation.max.string',['attribute' => 'RG', 'max' => '100'])
        ]);

    }


    /** @test */
    public function editar_rg_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['rg'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->edicao_compara;
        $objcompara['rg'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('rg');

    }


    /** @test */
    public function editar_nis_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolo';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'nis' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'nis' => __('validation.max.string',['attribute' => 'NIS', 'max' => '11'])
        ]);

    }


    /** @test */
    public function editar_nis_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['nis'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->edicao_compara;
        $objcompara['nis'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('nis');

    }


    /** @test */
    public function editar_ocupacao_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'ocupacao' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'ocupacao' => __('validation.max.string',['attribute' => 'Ocupação', 'max' => '500'])
        ]);

    }


    /** @test */
    public function editar_ocupacao_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['ocupacao'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->edicao_compara;
        $objcompara['ocupacao'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('ocupacao');

    }


    /** @test */
    public function editar_filhos_n_idade_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'filhos' =>  array(['idade' => 105])
        ]);

        $response-> assertJsonValidationErrors([
            'filhos.0.idade' => __('validation.max.numeric',['attribute' => 'Idade do Filho', 'max' => '100'])
        ]);

    }


    /** @test */
    public function editar_filhos_n_idade_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['filhos'] =  array(['idade' => 100]);
        $objcompara = $this->edicao_compara;
        $objcompara['filhos'] =  array(['idade' => 100]);
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('filhos.0.idade');

    }


    /** @test */
    public function editar_quem_cedeu_moradia_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'quem_cedeu_moradia' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'quem_cedeu_moradia' => __('validation.max.string',['attribute' => 'Quem Cedeu a Moradia', 'max' => '200'])
        ]);

    }


    /** @test */
    public function editar_quem_cedeu_moradia_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['quem_cedeu_moradia'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->edicao_compara;
        $objcompara['quem_cedeu_moradia'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('quem_cedeu_moradia');

    }


    /** @test */
    public function editar_endereco_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'endereco' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'endereco' => __('validation.max.string',['attribute' => 'Endereço', 'max' => '500'])
        ]);

    }


    /** @test */
    public function editar_endereco_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['endereco'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->edicao_compara;
        $objcompara['endereco'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('endereco');

    }


    /** @test */
    public function editar_numero_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'numero' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'numero' => __('validation.max.string',['attribute' => 'Número', 'max' => '200'])
        ]);

    }


    /** @test */
    public function editar_numero_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['numero'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->edicao_compara;
        $objcompara['numero'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('numero');

    }


    /** @test */
    public function editar_complemento_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'complemento' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'complemento' => __('validation.max.string',['attribute' => 'Complemento', 'max' => '200'])
        ]);

    }


    /** @test */
    public function editar_complemento_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['complemento'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->edicao_compara;
        $objcompara['complemento'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('complemento');

    }


    /** @test */
    public function editar_bairro_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'bairro' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'bairro' => __('validation.max.string',['attribute' => 'Bairro', 'max' => '200'])
        ]);

    }


    /** @test */
    public function editar_bairro_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['bairro'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->edicao_compara;
        $objcompara['bairro'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('bairro');

    }


    /** @test */
    public function editar_outro_end_loca_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'outro_end_loca' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'outro_end_loca' => __('validation.max.string',['attribute' => 'Outro Endereço para Localização', 'max' => '5000'])
        ]);

    }


    /** @test */
    public function editar_outro_end_loca_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['outro_end_loca'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->edicao_compara;
        $objcompara['outro_end_loca'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('outro_end_loca');

    }


    /** @test */
    public function editar_pais_cidade_estrangeiro_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'pais_cidade_estrangeiro' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'pais_cidade_estrangeiro' => __('validation.max.string',['attribute' => 'País e Cidade para Estrangeiro', 'max' => '200'])
        ]);

    }


    /** @test */
    public function editar_pais_cidade_estrangeiro_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['pais_cidade_estrangeiro'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->edicao_compara;
        $objcompara['pais_cidade_estrangeiro'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('pais_cidade_estrangeiro');

    }


    /** @test */
    public function editar_tempo_reside_mun_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'tempo_reside_mun' => 125
        ]);

        $response-> assertJsonValidationErrors([
            'tempo_reside_mun' => __('validation.max.numeric',['attribute' => 'Quanto tempo reside no Município (Anos)', 'max' => '120'])
        ]);

    }


    /** @test */
    public function editar_tempo_reside_mun_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['tempo_reside_mun'] = 120;
        $objcompara = $this->edicao_compara;
        $objcompara['tempo_reside_mun'] = 120;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('tempo_reside_mun');

    }


    /** @test */
    public function editar_tipo_deficiencia_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'tipo_deficiencia' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'tipo_deficiencia' => __('validation.max.string',['attribute' => 'Tipo de Deficiência', 'max' => '500'])
        ]);

    }


    /** @test */
    public function editar_tipo_deficiencia_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['tipo_deficiencia'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->edicao_compara;
        $objcompara['tipo_deficiencia'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('tipo_deficiencia');

    }


    /** @test */
    public function editar_servico_utilizado_n_nome_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/mulher/'.$id_objeto,[
                'servico_utilizado' =>  array(['nome' => $txt_Lorem_ipsum_maior])
        ]);

        $response-> assertJsonValidationErrors([
            'servico_utilizado.0.nome' => __('validation.max.string',['attribute' => 'Nome do Local do Serviço', 'max' => '500'])
        ]);

    }


    /** @test */
    public function editar_servico_utilizado_n_nome_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['servico_utilizado'] =  array(['nome' => $txt_Lorem_ipsum_max]);
        $objcompara = $this->edicao_compara;
        $objcompara['servico_utilizado'] =  array(['nome' => $txt_Lorem_ipsum_max]);
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('servico_utilizado.0.nome');

    }


    /** @test */
    public function editar_nome_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'nome' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'nome' => __('validation.min.string',['attribute' => 'Nome', 'min' => '2'])
        ]);

    }


    /** @test */
    public function editar_nome_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['nome'] = 'Lo';
        $objcompara = $this->edicao_compara;
        $objcompara['nome'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('nome');

    }

    /** @test */
    public function editar_rg_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'rg' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'rg' => __('validation.min.string',['attribute' => 'RG', 'min' => '2'])
        ]);

    }


    /** @test */
    public function editar_rg_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['rg'] = 'Lo';
        $objcompara = $this->edicao_compara;
        $objcompara['rg'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('rg');

    }

    /** @test */
    public function editar_nis_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'nis' => 'Lorem_ipsu'
        ]);

        $response-> assertJsonValidationErrors([
            'nis' => __('validation.min.string',['attribute' => 'NIS', 'min' => '11'])
        ]);

    }


    /** @test */
    public function editar_nis_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['nis'] = 'Lorem_ipsum';
        $objcompara = $this->edicao_compara;
        $objcompara['nis'] = 'Lorem_ipsum';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('nis');

    }

    /** @test */
    public function editar_ocupacao_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'ocupacao' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'ocupacao' => __('validation.min.string',['attribute' => 'Ocupação', 'min' => '2'])
        ]);

    }


    /** @test */
    public function editar_ocupacao_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['ocupacao'] = 'Lo';
        $objcompara = $this->edicao_compara;
        $objcompara['ocupacao'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('ocupacao');

    }

    /** @test */
    public function editar_filhos_n_idade_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['filhos'] =  array(['idade' => 0]);
        $objcompara = $this->edicao_compara;
        $objcompara['filhos'] =  array(['idade' => 0]);
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('filhos.0.idade');

    }

    /** @test */
    public function editar_quem_cedeu_moradia_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'quem_cedeu_moradia' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'quem_cedeu_moradia' => __('validation.min.string',['attribute' => 'Quem Cedeu a Moradia', 'min' => '2'])
        ]);

    }


    /** @test */
    public function editar_quem_cedeu_moradia_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['quem_cedeu_moradia'] = 'Lo';
        $objcompara = $this->edicao_compara;
        $objcompara['quem_cedeu_moradia'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('quem_cedeu_moradia');

    }

    /** @test */
    public function editar_endereco_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'endereco' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'endereco' => __('validation.min.string',['attribute' => 'Endereço', 'min' => '2'])
        ]);

    }


    /** @test */
    public function editar_endereco_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['endereco'] = 'Lo';
        $objcompara = $this->edicao_compara;
        $objcompara['endereco'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('endereco');

    }

    /** @test */
    public function editar_numero_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['numero'] = 'L';
        $objcompara = $this->edicao_compara;
        $objcompara['numero'] = 'L';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('numero');

    }

    /** @test */
    public function editar_complemento_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['complemento'] = 'L';
        $objcompara = $this->edicao_compara;
        $objcompara['complemento'] = 'L';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('complemento');

    }

    /** @test */
    public function editar_bairro_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['bairro'] = 'L';
        $objcompara = $this->edicao_compara;
        $objcompara['bairro'] = 'L';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('bairro');

    }

    /** @test */
    public function editar_outro_end_loca_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'outro_end_loca' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'outro_end_loca' => __('validation.min.string',['attribute' => 'Outro Endereço para Localização', 'min' => '2'])
        ]);

    }


    /** @test */
    public function editar_outro_end_loca_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['outro_end_loca'] = 'Lo';
        $objcompara = $this->edicao_compara;
        $objcompara['outro_end_loca'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('outro_end_loca');

    }

    /** @test */
    public function editar_pais_cidade_estrangeiro_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'pais_cidade_estrangeiro' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'pais_cidade_estrangeiro' => __('validation.min.string',['attribute' => 'País e Cidade para Estrangeiro', 'min' => '2'])
        ]);

    }


    /** @test */
    public function editar_pais_cidade_estrangeiro_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['pais_cidade_estrangeiro'] = 'Lo';
        $objcompara = $this->edicao_compara;
        $objcompara['pais_cidade_estrangeiro'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('pais_cidade_estrangeiro');

    }

    /** @test */
    public function editar_tempo_reside_mun_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['tempo_reside_mun'] = 0;
        $objcompara = $this->edicao_compara;
        $objcompara['tempo_reside_mun'] = 0;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('tempo_reside_mun');

    }

    /** @test */
    public function editar_tipo_deficiencia_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'tipo_deficiencia' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'tipo_deficiencia' => __('validation.min.string',['attribute' => 'Tipo de Deficiência', 'min' => '2'])
        ]);

    }


    /** @test */
    public function editar_tipo_deficiencia_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['tipo_deficiencia'] = 'Lo';
        $objcompara = $this->edicao_compara;
        $objcompara['tipo_deficiencia'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('tipo_deficiencia');

    }

    /** @test */
    public function editar_servico_utilizado_n_nome_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'servico_utilizado' =>  array(['nome' => 'L'])
        ]);

        $response-> assertJsonValidationErrors([
            'servico_utilizado.0.nome' => __('validation.min.string',['attribute' => 'Nome do Local do Serviço', 'min' => '2'])
        ]);

    }


    /** @test */
    public function editar_servico_utilizado_n_nome_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['servico_utilizado'] =  array(['nome' => 'Lo']);
        $objcompara = $this->edicao_compara;
        $objcompara['servico_utilizado'] =  array(['nome' => 'Lo']);
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('servico_utilizado.0.nome');

    }

    /** @test */
    public function editar_escolaridade_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'escolaridade' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'escolaridade' => __('validation.exists',['attribute' => 'Escolaridade'])
        ]);

    }


    /** @test */
    public function editar_orientacao_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'orientacao' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'orientacao' => __('validation.exists',['attribute' => 'Orientação Sexual'])
        ]);

    }


    /** @test */
    public function editar_etnia_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'etnia' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'etnia' => __('validation.exists',['attribute' => 'Etnia/Raça'])
        ]);

    }


    /** @test */
    public function editar_estado_civil_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'estado_civil' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'estado_civil' => __('validation.exists',['attribute' => 'Estado Civil'])
        ]);

    }


    /** @test */
    public function editar_filhos_n_fillho_reside_com_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'filhos' => array(['fillho_reside_com' => 9999])
        ]);

        $response-> assertJsonValidationErrors([
            'filhos.0.fillho_reside_com' => __('validation.exists',['attribute' => 'Filho reside com'])
        ]);

    }


    /** @test */
    public function editar_resido_com_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'resido_com' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'resido_com' => __('validation.exists',['attribute' => 'Reside Com'])
        ]);

    }


    /** @test */
    public function editar_sit_moradia_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'sit_moradia' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'sit_moradia' => __('validation.exists',['attribute' => 'Situação da Moradia'])
        ]);

    }


    /** @test */
    public function editar_estado_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'estado' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'estado' => __('validation.exists',['attribute' => 'Estado'])
        ]);

    }


    /** @test */
    public function editar_municipio_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'municipio' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'municipio' => __('validation.exists',['attribute' => 'Município'])
        ]);

    }


    /** @test */
    public function editar_estado_nascimento_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'estado_nascimento' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'estado_nascimento' => __('validation.exists',['attribute' => 'Estado de Nascimento'])
        ]);

    }


    /** @test */
    public function editar_municipio_nascimento_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'municipio_nascimento' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'municipio_nascimento' => __('validation.exists',['attribute' => 'Município de Nascimento'])
        ]);

    }


    /** @test */
    public function editar_muni_anterior_n_estado_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'muni_anterior' => array(['estado' => 9999])
        ]);

        $response-> assertJsonValidationErrors([
            'muni_anterior.0.estado' => __('validation.exists',['attribute' => 'Estado'])
        ]);

    }


    /** @test */
    public function editar_muni_anterior_n_municipio_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'muni_anterior' => array(['municipio' => 9999])
        ]);

        $response-> assertJsonValidationErrors([
            'muni_anterior.0.municipio' => __('validation.exists',['attribute' => 'Município'])
        ]);

    }


    /** @test */
    public function editar_servico_utilizado_n_servico_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'servico_utilizado' => array(['servico' => 9999])
        ]);

        $response-> assertJsonValidationErrors([
            'servico_utilizado.0.servico' => __('validation.exists',['attribute' => 'Serviço'])
        ]);

    }


    /** @test */
    public function editar_cpf_cpf()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'cpf' => '99999999999'
            ]);

        $response-> assertJsonValidationErrors([
            'cpf' => 'O campo CPF não é um CPF válido.'
        ]);

    }


    /** @test */
    public function editar_cep_cep()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'cep' => '99999999'
            ]);

        $response-> assertJsonValidationErrors([
            'cep' => 'O campo CEP não possui um formato válido de CEP.'
        ]);

    }


    /** @test */
    public function editar_telefone_n_telefone_celular_com_ddd()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto,[
                'telefone' => array(['telefone' => '999'])
            ]);

        $response-> assertJsonValidationErrors([
            'telefone.0.telefone' => 'O campo Telefone não é um celular com DDD válido.'
        ]);

    }


    /** @test */
    public function editar_cpf_unique()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto1 = json_decode($resposta,true)['id'];

        $obj2 = $this->cadastro_correto;
        $obj2['cpf'] = $obj2['cpf'] . 'abc';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj2);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto2 = json_decode($resposta,true)['id'];

        $obj = $this->edicao_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto1,$obj);
        $response->assertStatus(200);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/mulher/'.$id_objeto2,$obj);

        $response->assertJsonValidationErrors([
                   'cpf' => __('validation.unique',['attribute' => 'CPF'])
        ]);

    }


    /** @test */
    public function buscar_registro_especifico()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->get('/api/mulher/'.$id_objeto);

        $response
        ->assertStatus(200)
        ->assertJson($this->cadastro_compara);

    }


    /** @test */
    public function buscar_varios_registros()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();

        $obj2 = array_merge($this->cadastro_correto, $this->edicao_correto);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj2);

        $resposta = $response->assertStatus(201)->getContent();


        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->get('/api/mulher/');

        $response
        ->assertStatus(200)
        ->assertJsonCount(2);

    }


    /** @test */
    public function deletar_um_registro()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = array_merge($this->cadastro_correto, $this->edicao_correto);
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj2);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->delete('/api/mulher/'.$id_objeto);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->get('/api/mulher/');

        $response
        ->assertStatus(200)
        ->assertJsonMissingExact($obj);

    }


    /** @test */
    public function deletar_um_registro_possuind_atendimento()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $this->local_atend1 = [

            'nome_local' => 'Casa de Amparo às Mulheres Vítimas de Violência Doméstica',
            'cep' => '78005-580',
            'endereco' => 'Palácio Alencastro',
            'numero' => '158',
            'complemento' => '7 andar',
            'bairro' => 'Centro',
            'estado' => 1,
            'municipio' => 2,
            'telefone' => '(65) 3555-1224',
        ];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/local_atend',$this->local_atend1);

        $response->assertStatus(201)->getContent();

        $this->atendimento1 = [

            'mulher' => $id_objeto,
            'local_atend' => 1,
            'data_ocorrido' => '2023-08-29',
            'desc_sumaria' => 'Sophia, 35 anos, relatou que foi agredida fisicamente pelo marido, João, 40 anos. O casal está casado há 13 anos e tem um filhos, de 12 . A agressão ocorreu na residência do casal, após uma discussão sobre o comportamento de João.',
            'for_busc_serv' => 1,
            'como_soube' => 'Viu um cartaz em um posto de saúde',
            'inst_encaminha' => 1,
            'nome_instituicao' => 'Secretaria Municipal de Assistência Social',
            'contato_instituicao' => '(65) 3333-3334',
            'prof_resp_encam' => 2,
            'qual_out_form' => 'Não se Aplica',
            'caract_violencia' => [1],
            'tipo_agressor' => 1,
            'relacao_agressor' => 1,
            'tipo_violencia' => [1,2,3],
            'grau_violencia_fis' => 1,
            'tp_viol_fisica' => [1],
            'necessitou_atendimento' => true,
            'tp_atendimento' => 1,
            'regis_policial' => true,
            'form_medida_prot' => true,
            'acao_rel_med' => 1,
            'tp_viol_sexual' => [1],
            'atend_viol_sex' => false,
            'viol_sex_men_horas' => false,
            'tp_viol_psico' => [1],
            'negligencia' => false,
            'dep_finan' => true,
            'aceita_abrig_temp' => true,
            'concord_encami' => false,
            'motivo_n_con_enc' => 'A vítima não concordou com o encaminhamento para o abrigo temporário, pois não quer se separar dos filhos.',
            'aval_risc_int' => 1,
            'providencia' => 'Foi elaborado um plano de segurança pessoal para Sophia, com medidas como a mudança temporária de residência e o acompanhamento psicológico. Foi solicitado à Polícia Militar a prisão preventiva de João.',
            'org_acionado' => [1,2],
            'elab_psp' => true,
            'data_atendimento' => '2023-08-30',
            'encaminha' => 'Atendimento médico, encaminhamento para abrigo temporário, acompanhamento psicológico, elaboração de plano de segurança pessoal, solicitação de prisão preventiva do agressor',
        ];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$this->atendimento1);

        $response->assertStatus(201)->getContent();

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->delete('/api/mulher/'.$id_objeto);

        $response
        ->assertStatus(422)
        ->assertJsonValidationErrors(['atendimento']);

    }

}

