<?php

namespace Tests\Feature;

use App\Models\Profile;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class RelacaoAgressorTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp():void 
    {
        parent::setUp();

        $this->cadastro_correto = [
            'ativo' => true,
            'rela_par_agressor' => 'Marido',
        ];


        $this->cadastro_compara = [
            'ativo' => true,
            'rela_par_agressor' => 'Marido',
        ];


        $this->edicao_correto = [
            'ativo' => false,
            'rela_par_agressor' => 'Pai',
        ];


        $this->edicao_compara = [
            'ativo' => false,
            'rela_par_agressor' => 'Pai',
        ];

    }


    /** @test */
    public function listar_get_sem_login()
    {
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->get('/api/relacao_agressor');

        $response
        -> assertStatus(401)
        -> assertJson(['message' => 'Unauthenticated.']);

    }


    /** @test */
    public function listar_get_com_login()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->get('/api/relacao_agressor');

        $response
        -> assertStatus(200);

    }


    /** @test */
    public function salvar_post_sem_login()
    {
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->post('/api/relacao_agressor');

        $response
        -> assertStatus(401)
        -> assertJson(['message' => 'Unauthenticated.']);

    }


    /** @test */
    public function editar_put_sem_login()
    {
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/relacao_agressor/1',[]);

        $response
        -> assertStatus(401)
        -> assertJson(['message' => 'Unauthenticated.']);

    }


    /** @test */
    public function campos_listar()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/relacao_agressor',$this->cadastro_correto);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->get('/api/relacao_agressor');

        $response
        -> assertStatus(200)
        -> assertJsonStructure(['*' => ['id', 'ativo', 'rela_par_agressor']]);

    }


    /** @test */
    public function salvar_correto()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/relacao_agressor',$this->cadastro_correto);

        $response
        ->assertStatus(201)
        ->assertJsonFragment($this->cadastro_compara);

    }


    /** @test */
    public function salvar_rela_par_agressor_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/relacao_agressor',[
                                    'rela_par_agressor' => '']);

        $response->assertJsonValidationErrors([
                   'rela_par_agressor' => __('validation.required',['attribute' => 'Grau de relação e/ou parentesco com o agressor(a)'])
        ]);

    }


    /** @test */
    public function salvar_rela_par_agressor_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/relacao_agressor',[
                'rela_par_agressor' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'rela_par_agressor' => __('validation.string',['attribute' => 'Grau de relação e/ou parentesco com o agressor(a)'])
        ]);

    }


    /** @test */
    public function salvar_rela_par_agressor_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit';

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/relacao_agressor',[
                'rela_par_agressor' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'rela_par_agressor' => __('validation.max.string',['attribute' => 'Grau de relação e/ou parentesco com o agressor(a)', 'max' => '250'])
        ]);

    }


    /** @test */
    public function salvar_rela_par_agressor_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing';

        $obj = $this->cadastro_correto;
        $obj['rela_par_agressor'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->cadastro_compara;
        $objcompara['rela_par_agressor'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/relacao_agressor',$obj);

        $response
        ->assertJsonMissingValidationErrors('rela_par_agressor');

    }


    /** @test */
    public function salvar_rela_par_agressor_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/relacao_agressor',[
                'rela_par_agressor' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'rela_par_agressor' => __('validation.min.string',['attribute' => 'Grau de relação e/ou parentesco com o agressor(a)', 'min' => '2'])
        ]);

    }


    /** @test */
    public function salvar_rela_par_agressor_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $obj['rela_par_agressor'] = 'Lo';
        $objcompara = $this->cadastro_compara;
        $objcompara['rela_par_agressor'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/relacao_agressor',$obj);

        $response
        ->assertJsonMissingValidationErrors('rela_par_agressor');

    }


    /** @test */
    public function salvar_rela_par_agressor_unique()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/relacao_agressor',$this->cadastro_correto);
        $response->assertStatus(201);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/relacao_agressor',$this->cadastro_correto);

        $response->assertJsonValidationErrors([
                   'rela_par_agressor' => __('validation.unique',['attribute' => 'Grau de relação e/ou parentesco com o agressor(a)'])
        ]);

    }


    /** @test */
    public function editar_correto()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/relacao_agressor',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];


        $obj = $this->edicao_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/relacao_agressor/'.$id_objeto,$obj);

        $response
        ->assertStatus(200)
        ->assertJsonFragment($this->edicao_compara);

    }
    /** @test */
    public function editar_rela_par_agressor_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/relacao_agressor',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/relacao_agressor/'.$id_objeto,[
                                    'rela_par_agressor' => '']);

        $response->assertJsonValidationErrors([
                   'rela_par_agressor' => __('validation.required',['attribute' => 'Grau de relação e/ou parentesco com o agressor(a)'])
        ]);

    }


    /** @test */
    public function editar_rela_par_agressor_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/relacao_agressor',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/relacao_agressor/'.$id_objeto,[
                'rela_par_agressor' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'rela_par_agressor' => __('validation.string',['attribute' => 'Grau de relação e/ou parentesco com o agressor(a)'])
        ]);

    }


    /** @test */
    public function editar_rela_par_agressor_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/relacao_agressor',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/relacao_agressor/'.$id_objeto,[
                'rela_par_agressor' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'rela_par_agressor' => __('validation.max.string',['attribute' => 'Grau de relação e/ou parentesco com o agressor(a)', 'max' => '250'])
        ]);

    }


    /** @test */
    public function editar_rela_par_agressor_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/relacao_agressor',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['rela_par_agressor'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->edicao_compara;
        $objcompara['rela_par_agressor'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/relacao_agressor/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('rela_par_agressor');

    }


    /** @test */
    public function editar_rela_par_agressor_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/relacao_agressor',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/relacao_agressor/'.$id_objeto,[
                'rela_par_agressor' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'rela_par_agressor' => __('validation.min.string',['attribute' => 'Grau de relação e/ou parentesco com o agressor(a)', 'min' => '2'])
        ]);

    }


    /** @test */
    public function editar_rela_par_agressor_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/relacao_agressor',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['rela_par_agressor'] = 'Lo';
        $objcompara = $this->edicao_compara;
        $objcompara['rela_par_agressor'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/relacao_agressor/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('rela_par_agressor');

    }

    /** @test */
    public function editar_rela_par_agressor_unique()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/relacao_agressor',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto1 = json_decode($resposta,true)['id'];

        $obj2 = $this->cadastro_correto;
        $obj2['rela_par_agressor'] = $obj2['rela_par_agressor'] . 'abc';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/relacao_agressor',$obj2);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto2 = json_decode($resposta,true)['id'];

        $obj = $this->edicao_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/relacao_agressor/'.$id_objeto1,$obj);
        $response->assertStatus(200);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/relacao_agressor/'.$id_objeto2,$obj);

        $response->assertJsonValidationErrors([
                   'rela_par_agressor' => __('validation.unique',['attribute' => 'Grau de relação e/ou parentesco com o agressor(a)'])
        ]);

    }


    /** @test */
    public function buscar_registro_especifico()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/relacao_agressor',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->get('/api/relacao_agressor/'.$id_objeto);

        $response
        ->assertStatus(200)
        ->assertJson($this->cadastro_compara);

    }


    /** @test */
    public function buscar_varios_registros()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/relacao_agressor',$obj);

        $resposta = $response->assertStatus(201)->getContent();

        $obj2 = array_merge($this->cadastro_correto, $this->edicao_correto);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/relacao_agressor',$obj2);

        $resposta = $response->assertStatus(201)->getContent();


        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->get('/api/relacao_agressor/');

        $response
        ->assertStatus(200)
        ->assertJsonCount(12);

    }


    /** @test */
    public function deletar_um_registro()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/relacao_agressor',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = array_merge($this->cadastro_correto, $this->edicao_correto);
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/relacao_agressor',$obj2);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->delete('/api/relacao_agressor/'.$id_objeto);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->get('/api/relacao_agressor/');

        $response
        ->assertStatus(200)
        ->assertJsonMissingExact($obj);

    }


    /** @test */
    public function deletar_um_registro_possuind_atendimento()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/relacao_agressor',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $this->ori_sexual1 = [

            'ativo' => true,
            'orientacao' => 'Hete',
        ];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/ori_sexual',$this->ori_sexual1);

        $response->assertStatus(201)->getContent();

        $this->etnia1 = [

            'ativo' => true,
            'etnia' => 'Branco',
        ];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/etnia',$this->etnia1);

        $response->assertStatus(201)->getContent();

        $this->estado_civil1 = [

            'ativo' => true,
            'estado_civil' => 'Solteiro',
        ];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/estado_civil',$this->estado_civil1);

        $response->assertStatus(201)->getContent();

        $this->escolaridade1 = [

            'ativo' => true,
            'escolaridade' => 'Ensino Fundamental Incomp.',
        ];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/escolaridade',$this->escolaridade1);

        $response->assertStatus(201)->getContent();

        $this->reside_com1 = [

            'ativo' => true,
            'reside_com' => 'Sozinho',
        ];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/reside_com',$this->reside_com1);

        $response->assertStatus(201)->getContent();

        $this->estado1 = [

            'ativo' => true,
            'sigla' => 'MM',
            'nome' => 'Mato Gr.',
        ];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/estado',$this->estado1);

        $response->assertStatus(201)->getContent();

        $this->municipio1 = [

            'ativo' => true,
            'cod_muni_ibge' => '993403',
            'estado' => 1,
            'municipio' => 'Cuiabá',
        ];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$this->municipio1);

        $response->assertStatus(201)->getContent();

        $this->servico1 = [

            'ativo' => true,
            'servico' => 'Saúde Pública',
        ];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/servico',$this->servico1);

        $response->assertStatus(201)->getContent();

        $this->sit_moradia1 = [

            'ativo' => true,
            'situacao' => 'Cedido',
        ];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/sit_moradia',$this->sit_moradia1);

        $response->assertStatus(201)->getContent();

        $this->mulher1 = [

            'nome' => 'Sophia Agatha Laís Pereira',
            'data_nascimento' => '1988-02-01',
            'rg' => '19.211.535-2',
            'cpf' => '926.622.331-09',
            'nis' => '37414972104',
            'trabalha' => true,
            'remunerado' => true,
            'ocupacao' => 'Vendedora',
            'escolaridade' => 2,
            'orientacao' => 1,
            'etnia' => 2,
            'estado_civil' => 1,
            'possui_filhos' => true,
            'filhos' => array(["idade"=>12,"fillho_reside_com"=>1,"port_deficiencia"=>false]),
            'dorme_rua' => false,
            'resido_com' => 1,
            'sit_moradia' => 1,
            'cep' => '78043-128',
            'endereco' => 'Rua das Rosas',
            'numero' => '479',
            'complemento' => 'não informado',
            'bairro' => 'Jardim Cuiabá',
            'estado' => 1,
            'municipio' => 1,
            'outro_end_loca' => 'não informado',
            'telefone' => array(["telefone"=>"(65) 3698-5249"],["telefone"=>"(65) 99121-7026"]),
            'nacionalidade_br' => true,
            'estado_nascimento' => 1,
            'municipio_nascimento' => 3,
            'pais_cidade_estrangeiro' => 'Não se Aplica',
            'tempo_reside_mun' => 3.5,
            'muni_anterior' => array(["estado"=>1,"municipio"=>2],["estado"=>4,"municipio"=>3]),
            'port_deficiencia' => false,
            'tipo_deficiencia' => 'Não se Aplica',
            'servico_utilizado' => array(["servico"=>1,"nome"=>"Centro de Saúde Dr Oscarino de Campos Borges"]),
        ];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$this->mulher1);

        $response->assertStatus(201)->getContent();

        $this->local_atend1 = [

            'nome_local' => 'Casa de Amparo às Mulheres Vítimas de Violência Doméstica',
            'cep' => '78005-580',
            'endereco' => 'Palácio Alencastro',
            'numero' => '158',
            'complemento' => '7 andar',
            'bairro' => 'Centro',
            'estado' => 1,
            'municipio' => 2,
            'telefone' => '(65) 3555-1224',
        ];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/local_atend',$this->local_atend1);

        $response->assertStatus(201)->getContent();

        $this->atendimento1 = [

            'mulher' => 1,
            'local_atend' => 1,
            'data_ocorrido' => '2023-08-29',
            'desc_sumaria' => 'Sophia, 35 anos, relatou que foi agredida fisicamente pelo marido, João, 40 anos. O casal está casado há 13 anos e tem um filhos, de 12 . A agressão ocorreu na residência do casal, após uma discussão sobre o comportamento de João.',
            'for_busc_serv' => 1,
            'como_soube' => 'Viu um cartaz em um posto de saúde',
            'inst_encaminha' => 1,
            'nome_instituicao' => 'Secretaria Municipal de Assistência Social',
            'contato_instituicao' => '(65) 3333-3334',
            'prof_resp_encam' => 2,
            'qual_out_form' => 'Não se Aplica',
            'caract_violencia' => [1],
            'tipo_agressor' => 1,
            'relacao_agressor' => $id_objeto,
            'tipo_violencia' => [1,2,3],
            'grau_violencia_fis' => 1,
            'tp_viol_fisica' => [1],
            'necessitou_atendimento' => true,
            'tp_atendimento' => 1,
            'regis_policial' => true,
            'form_medida_prot' => true,
            'acao_rel_med' => 1,
            'tp_viol_sexual' => [1],
            'atend_viol_sex' => false,
            'viol_sex_men_horas' => false,
            'tp_viol_psico' => [1],
            'negligencia' => false,
            'dep_finan' => true,
            'aceita_abrig_temp' => true,
            'concord_encami' => false,
            'motivo_n_con_enc' => 'A vítima não concordou com o encaminhamento para o abrigo temporário, pois não quer se separar dos filhos.',
            'aval_risc_int' => 1,
            'providencia' => 'Foi elaborado um plano de segurança pessoal para Sophia, com medidas como a mudança temporária de residência e o acompanhamento psicológico. Foi solicitado à Polícia Militar a prisão preventiva de João.',
            'org_acionado' => [1,2],
            'elab_psp' => true,
            'data_atendimento' => '2023-08-30',
            'encaminha' => 'Atendimento médico, encaminhamento para abrigo temporário, acompanhamento psicológico, elaboração de plano de segurança pessoal, solicitação de prisão preventiva do agressor',
        ];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$this->atendimento1);

        $response->assertStatus(201)->getContent();

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->delete('/api/relacao_agressor/'.$id_objeto);

        $response
        ->assertStatus(422)
        ->assertJsonValidationErrors(['atendimento']);

    }

}

