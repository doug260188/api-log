<?php

namespace Tests\Feature;

use App\Models\Profile;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class AtendimentoTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp():void 
    {
        parent::setUp();

        $this->cadastro_correto = [
            'mulher' => 1,
            'local_atend' => 1,
            'data_ocorrido' => '2023-08-29',
            'desc_sumaria' => 'Sophia, 35 anos, relatou que foi agredida fisicamente pelo marido, João, 40 anos. O casal está casado há 13 anos e tem um filhos, de 12 . A agressão ocorreu na residência do casal, após uma discussão sobre o comportamento de João.',
            'for_busc_serv' => 1,
            'como_soube' => 'Viu um cartaz em um posto de saúde',
            'inst_encaminha' => 1,
            'nome_instituicao' => 'Secretaria Municipal de Assistência Social',
            'contato_instituicao' => '(65) 3333-3334',
            'prof_resp_encam' => 2,
            'qual_out_form' => 'Não se Aplica',
            'caract_violencia' => [1],
            'tipo_agressor' => 1,
            'relacao_agressor' => 1,
            'tipo_violencia' => [1,2,3],
            'grau_violencia_fis' => 1,
            'tp_viol_fisica' => [1],
            'necessitou_atendimento' => true,
            'tp_atendimento' => 1,
            'regis_policial' => true,
            'form_medida_prot' => true,
            'acao_rel_med' => 1,
            'tp_viol_sexual' => [1],
            'atend_viol_sex' => false,
            'viol_sex_men_horas' => false,
            'tp_viol_psico' => [1],
            'negligencia' => false,
            'dep_finan' => true,
            'aceita_abrig_temp' => true,
            'concord_encami' => false,
            'motivo_n_con_enc' => 'A vítima não concordou com o encaminhamento para o abrigo temporário, pois não quer se separar dos filhos.',
            'aval_risc_int' => 1,
            'providencia' => 'Foi elaborado um plano de segurança pessoal para Sophia, com medidas como a mudança temporária de residência e o acompanhamento psicológico. Foi solicitado à Polícia Militar a prisão preventiva de João.',
            'org_acionado' => [1,2],
            'elab_psp' => true,
            'data_atendimento' => '2023-08-30',
            'encaminha' => 'Atendimento médico, encaminhamento para abrigo temporário, acompanhamento psicológico, elaboração de plano de segurança pessoal, solicitação de prisão preventiva do agressor',
        ];


        $this->cadastro_compara = [
            'mulher' => 1,
            'local_atend' => 1,
            'data_ocorrido' => '2023-08-29',
            'desc_sumaria' => 'Sophia, 35 anos, relatou que foi agredida fisicamente pelo marido, João, 40 anos. O casal está casado há 13 anos e tem um filhos, de 12 . A agressão ocorreu na residência do casal, após uma discussão sobre o comportamento de João.',
            'for_busc_serv' => 1,
            'como_soube' => 'Viu um cartaz em um posto de saúde',
            'inst_encaminha' => 1,
            'nome_instituicao' => 'Secretaria Municipal de Assistência Social',
            'contato_instituicao' => '(65) 3333-3334',
            'prof_resp_encam' => 2,
            'qual_out_form' => 'Não se Aplica',
            'tipo_agressor' => 1,
            'relacao_agressor' => 1,
            'grau_violencia_fis' => 1,
            'necessitou_atendimento' => true,
            'tp_atendimento' => 1,
            'regis_policial' => true,
            'form_medida_prot' => true,
            'acao_rel_med' => 1,
            'atend_viol_sex' => false,
            'viol_sex_men_horas' => false,
            'negligencia' => false,
            'dep_finan' => true,
            'aceita_abrig_temp' => true,
            'concord_encami' => false,
            'motivo_n_con_enc' => 'A vítima não concordou com o encaminhamento para o abrigo temporário, pois não quer se separar dos filhos.',
            'aval_risc_int' => 1,
            'providencia' => 'Foi elaborado um plano de segurança pessoal para Sophia, com medidas como a mudança temporária de residência e o acompanhamento psicológico. Foi solicitado à Polícia Militar a prisão preventiva de João.',
            'elab_psp' => true,
            'data_atendimento' => '2023-08-30',
            'encaminha' => 'Atendimento médico, encaminhamento para abrigo temporário, acompanhamento psicológico, elaboração de plano de segurança pessoal, solicitação de prisão preventiva do agressor',
        ];


        $this->edicao_correto = [
            'local_atend' => 1,
            'data_ocorrido' => '2023-08-30',
            'desc_sumaria' => 'Clarice, 25 anos, relatou que foi vítima de violência sexual por um desconhecido. O fato ocorreu na rua, enquanto ela voltava do trabalho.',
            'for_busc_serv' => 2,
            'inst_encaminha' => 1,
            'nome_instituicao' => 'Secretaria Municipal de Assistência Social',
            'contato_instituicao' => '(65) 3333-3334',
            'prof_resp_encam' => 2,
            'caract_violencia' => [2],
            'tipo_agressor' => 2,
            'tipo_violencia' => [2],
            'tp_viol_fisica' => [],
            'regis_policial' => false,
            'form_medida_prot' => false,
            'tp_viol_sexual' => [1,2],
            'atend_viol_sex' => true,
            'viol_sex_men_horas' => true,
            'tp_viol_psico' => [1,2],
            'negligencia' => true,
            'dep_finan' => false,
            'aceita_abrig_temp' => false,
            'concord_encami' => true,
            'motivo_n_con_enc' => 'A vítima não concordou com o encaminhamento para o abrigo temporário, pois não quer se separar dos filhos.',
            'aval_risc_int' => 2,
            'providencia' => 'Foi realizado o encaminhamento de Clarice para um hospital para receber atendimento médico e psicológico. Foi solicitado à Polícia Civil a investigação do caso.',
            'org_acionado' => [2],
            'elab_psp' => false,
            'data_atendimento' => '2023-08-30',
            'encaminha' => 'Atendimento médico, encaminhamento para hospital, acompanhamento psicológico, solicitação de investigação do caso',
        ];


        $this->edicao_compara = [
            'local_atend' => 1,
            'data_ocorrido' => '2023-08-30',
            'desc_sumaria' => 'Clarice, 25 anos, relatou que foi vítima de violência sexual por um desconhecido. O fato ocorreu na rua, enquanto ela voltava do trabalho.',
            'for_busc_serv' => 2,
            'inst_encaminha' => 1,
            'nome_instituicao' => 'Secretaria Municipal de Assistência Social',
            'contato_instituicao' => '(65) 3333-3334',
            'prof_resp_encam' => 2,
            'tipo_agressor' => 2,
            'regis_policial' => false,
            'form_medida_prot' => false,
            'atend_viol_sex' => true,
            'viol_sex_men_horas' => true,
            'negligencia' => true,
            'dep_finan' => false,
            'aceita_abrig_temp' => false,
            'concord_encami' => true,
            'motivo_n_con_enc' => 'A vítima não concordou com o encaminhamento para o abrigo temporário, pois não quer se separar dos filhos.',
            'aval_risc_int' => 2,
            'providencia' => 'Foi realizado o encaminhamento de Clarice para um hospital para receber atendimento médico e psicológico. Foi solicitado à Polícia Civil a investigação do caso.',
            'elab_psp' => false,
            'data_atendimento' => '2023-08-30',
            'encaminha' => 'Atendimento médico, encaminhamento para hospital, acompanhamento psicológico, solicitação de investigação do caso',
        ];

    }


    public function pre_cadastro() 
    {
        $this->ori_sexual1 = [

            'ativo' => true,
            'orientacao' => 'Hete',
        ];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/ori_sexual',$this->ori_sexual1);

        $response->assertStatus(201)->getContent();

        $this->etnia1 = [

            'ativo' => true,
            'etnia' => 'Branco',
        ];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/etnia',$this->etnia1);

        $response->assertStatus(201)->getContent();

        $this->estado_civil1 = [

            'ativo' => true,
            'estado_civil' => 'Solteiro',
        ];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/estado_civil',$this->estado_civil1);

        $response->assertStatus(201)->getContent();

        $this->escolaridade1 = [

            'ativo' => true,
            'escolaridade' => 'Ensino Fundamental Incomp.',
        ];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/escolaridade',$this->escolaridade1);

        $response->assertStatus(201)->getContent();

        $this->reside_com1 = [

            'ativo' => true,
            'reside_com' => 'Sozinho',
        ];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/reside_com',$this->reside_com1);

        $response->assertStatus(201)->getContent();

        $this->estado1 = [

            'ativo' => true,
            'sigla' => 'MM',
            'nome' => 'Mato Gr.',
        ];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/estado',$this->estado1);

        $response->assertStatus(201)->getContent();

        $this->municipio1 = [

            'ativo' => true,
            'cod_muni_ibge' => '993403',
            'estado' => 1,
            'municipio' => 'Cuiabá',
        ];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/municipio',$this->municipio1);

        $response->assertStatus(201)->getContent();

        $this->servico1 = [

            'ativo' => true,
            'servico' => 'Saúde Pública',
        ];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/servico',$this->servico1);

        $response->assertStatus(201)->getContent();

        $this->sit_moradia1 = [

            'ativo' => true,
            'situacao' => 'Cedido',
        ];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/sit_moradia',$this->sit_moradia1);

        $response->assertStatus(201)->getContent();

        $this->mulher1 = [

            'nome' => 'Sophia Agatha Laís Pereira',
            'data_nascimento' => '1988-02-01',
            'rg' => '19.211.535-2',
            'cpf' => '926.622.331-09',
            'nis' => '37414972104',
            'trabalha' => true,
            'remunerado' => true,
            'ocupacao' => 'Vendedora',
            'escolaridade' => 2,
            'orientacao' => 1,
            'etnia' => 2,
            'estado_civil' => 1,
            'possui_filhos' => true,
            'filhos' => array(["idade"=>12,"fillho_reside_com"=>1,"port_deficiencia"=>false]),
            'dorme_rua' => false,
            'resido_com' => 1,
            'sit_moradia' => 1,
            'cep' => '78043-128',
            'endereco' => 'Rua das Rosas',
            'numero' => '479',
            'complemento' => 'não informado',
            'bairro' => 'Jardim Cuiabá',
            'estado' => 1,
            'municipio' => 1,
            'outro_end_loca' => 'não informado',
            'telefone' => array(["telefone"=>"(65) 3698-5249"],["telefone"=>"(65) 99121-7026"]),
            'nacionalidade_br' => true,
            'estado_nascimento' => 1,
            'municipio_nascimento' => 3,
            'pais_cidade_estrangeiro' => 'Não se Aplica',
            'tempo_reside_mun' => 3.5,
            'muni_anterior' => array(["estado"=>1,"municipio"=>2],["estado"=>4,"municipio"=>3]),
            'port_deficiencia' => false,
            'tipo_deficiencia' => 'Não se Aplica',
            'servico_utilizado' => array(["servico"=>1,"nome"=>"Centro de Saúde Dr Oscarino de Campos Borges"]),
        ];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/mulher',$this->mulher1);

        $response->assertStatus(201)->getContent();

        $this->local_atend1 = [

            'nome_local' => 'Casa de Amparo às Mulheres Vítimas de Violência Doméstica',
            'cep' => '78005-580',
            'endereco' => 'Palácio Alencastro',
            'numero' => '158',
            'complemento' => '7 andar',
            'bairro' => 'Centro',
            'estado' => 1,
            'municipio' => 2,
            'telefone' => '(65) 3555-1224',
        ];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/local_atend',$this->local_atend1);

        $response->assertStatus(201)->getContent();

    }


    /** @test */
    public function listar_get_sem_login()
    {
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->get('/api/atendimento');

        $response
        -> assertStatus(401)
        -> assertJson(['message' => 'Unauthenticated.']);

    }


    /** @test */
    public function listar_get_com_login()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->get('/api/atendimento');

        $response
        -> assertStatus(200);

    }


    /** @test */
    public function salvar_post_sem_login()
    {
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->post('/api/atendimento');

        $response
        -> assertStatus(401)
        -> assertJson(['message' => 'Unauthenticated.']);

    }


    /** @test */
    public function editar_put_sem_login()
    {
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/1',[]);

        $response
        -> assertStatus(401)
        -> assertJson(['message' => 'Unauthenticated.']);

    }


    /** @test */
    public function campos_listar()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$this->cadastro_correto);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->get('/api/atendimento');

        $response
        -> assertStatus(200)
        -> assertJsonStructure(['*' => ['id', 'mulher', 'local_atend', 'data_ocorrido', 'data_atendimento']]);

    }


    /** @test */
    public function salvar_correto()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$this->cadastro_correto);

        $response
        ->assertStatus(201)
        ->assertJsonFragment($this->cadastro_compara);

    }


    /** @test */
    public function salvar_mulher_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',[
                                    'mulher' => '']);

        $response->assertJsonValidationErrors([
                   'mulher' => __('validation.required',['attribute' => 'Mulher'])
        ]);

    }


    /** @test */
    public function salvar_local_atend_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',[
                                    'local_atend' => '']);

        $response->assertJsonValidationErrors([
                   'local_atend' => __('validation.required',['attribute' => 'Local do Atendimento'])
        ]);

    }


    /** @test */
    public function salvar_data_ocorrido_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',[
                                    'data_ocorrido' => '']);

        $response->assertJsonValidationErrors([
                   'data_ocorrido' => __('validation.required',['attribute' => 'Data relatada do ocorrido'])
        ]);

    }


    /** @test */
    public function salvar_desc_sumaria_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',[
                                    'desc_sumaria' => '']);

        $response->assertJsonValidationErrors([
                   'desc_sumaria' => __('validation.required',['attribute' => 'Descrição Sumária'])
        ]);

    }


    /** @test */
    public function salvar_for_busc_serv_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',[
                                    'for_busc_serv' => '']);

        $response->assertJsonValidationErrors([
                   'for_busc_serv' => __('validation.required',['attribute' => 'Forma de Busca do Serviço'])
        ]);

    }


    /** @test */
    public function salvar_caract_violencia_n_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',[
                                    'caract_violencia' => '']);

        $response->assertJsonValidationErrors([
                   'caract_violencia' => __('validation.required',['attribute' => 'Caracterização da Violência'])
        ]);

    }


    /** @test */
    public function salvar_tipo_agressor_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',[
                                    'tipo_agressor' => '']);

        $response->assertJsonValidationErrors([
                   'tipo_agressor' => __('validation.required',['attribute' => 'Tipo do Agressor'])
        ]);

    }


    /** @test */
    public function salvar_tipo_violencia_n_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',[
                                    'tipo_violencia' => '']);

        $response->assertJsonValidationErrors([
                   'tipo_violencia' => __('validation.required',['attribute' => 'Tipo da Violência'])
        ]);

    }


    /** @test */
    public function salvar_aval_risc_int_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',[
                                    'aval_risc_int' => '']);

        $response->assertJsonValidationErrors([
                   'aval_risc_int' => __('validation.required',['attribute' => 'Avaliação de Risco à Integridade Física'])
        ]);

    }


    /** @test */
    public function salvar_providencia_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',[
                                    'providencia' => '']);

        $response->assertJsonValidationErrors([
                   'providencia' => __('validation.required',['attribute' => 'Providências'])
        ]);

    }


    /** @test */
    public function salvar_org_acionado_n_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',[
                                    'org_acionado' => '']);

        $response->assertJsonValidationErrors([
                   'org_acionado' => __('validation.required',['attribute' => 'Órgão a serem Acionados'])
        ]);

    }


    /** @test */
    public function salvar_data_atendimento_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',[
                                    'data_atendimento' => '']);

        $response->assertJsonValidationErrors([
                   'data_atendimento' => __('validation.required',['attribute' => 'Data do Atendimento'])
        ]);

    }


    /** @test */
    public function salvar_encaminha_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',[
                                    'encaminha' => '']);

        $response->assertJsonValidationErrors([
                   'encaminha' => __('validation.required',['attribute' => 'Encaminhamentos'])
        ]);

    }


    /** @test */
    public function salvar_como_soube_obrigatorio_se_for_busc_serv_1()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->postJson('/api/atendimento',[
                'for_busc_serv' => 1,
                'como_soube' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'como_soube' => __('validation.required',['attribute' => 'Como soube do Serviço'])
        ]);

    }


    /** @test */
    public function salvar_inst_encaminha_obrigatorio_se_for_busc_serv_2()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->postJson('/api/atendimento',[
                'for_busc_serv' => 2,
                'inst_encaminha' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'inst_encaminha' => __('validation.required',['attribute' => 'Tipo da Instituição que Encaminhou'])
        ]);

    }


    /** @test */
    public function salvar_nome_instituicao_obrigatorio_se_for_busc_serv_2()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->postJson('/api/atendimento',[
                'for_busc_serv' => 2,
                'nome_instituicao' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'nome_instituicao' => __('validation.required',['attribute' => 'Nome da Instituição'])
        ]);

    }


    /** @test */
    public function salvar_contato_instituicao_obrigatorio_se_for_busc_serv_2()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->postJson('/api/atendimento',[
                'for_busc_serv' => 2,
                'contato_instituicao' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'contato_instituicao' => __('validation.required',['attribute' => 'Contato da Instituição'])
        ]);

    }


    /** @test */
    public function salvar_prof_resp_encam_obrigatorio_se_for_busc_serv_2()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->postJson('/api/atendimento',[
                'for_busc_serv' => 2,
                'prof_resp_encam' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'prof_resp_encam' => __('validation.required',['attribute' => 'Profissional responsável pelo Encaminhamento'])
        ]);

    }


    /** @test */
    public function salvar_qual_out_form_obrigatorio_se_for_busc_serv_3()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->postJson('/api/atendimento',[
                'for_busc_serv' => 3,
                'qual_out_form' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'qual_out_form' => __('validation.required',['attribute' => 'Qual Outra Forma de Busca'])
        ]);

    }


    /** @test */
    public function salvar_relacao_agressor_obrigatorio_se_tipo_agressor_1()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->postJson('/api/atendimento',[
                'tipo_agressor' => 1,
                'relacao_agressor' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'relacao_agressor' => __('validation.required',['attribute' => 'Grau de relação e/ou parentesco com o agressor(a)'])
        ]);

    }


    /** @test */
    public function salvar_grau_violencia_fis_obrigatorio_se_tipo_violencia_1()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->postJson('/api/atendimento',[
                'tipo_violencia' => [1],
                'grau_violencia_fis' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'grau_violencia_fis' => __('validation.required',['attribute' => 'Grau da Violência Física'])
        ]);

    }


    /** @test */
    public function salvar_tp_viol_fisica_obrigatorio_se_tipo_violencia_1()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->postJson('/api/atendimento',[
                'tipo_violencia' => [1],
                'tp_viol_fisica' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'tp_viol_fisica' => __('validation.required',['attribute' => 'Tipo de Violência Física'])
        ]);

    }


    /** @test */
    public function salvar_tp_atendimento_obrigatorio_se_tipo_violencia_1()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->postJson('/api/atendimento',[
                'tipo_violencia' => [1],
                'tp_atendimento' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'tp_atendimento' => __('validation.required',['attribute' => 'Tipo de Atendimento'])
        ]);

    }


    /** @test */
    public function salvar_tp_viol_sexual_obrigatorio_se_tipo_violencia_2()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->postJson('/api/atendimento',[
                'tipo_violencia' => [2],
                'tp_viol_sexual' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'tp_viol_sexual' => __('validation.required',['attribute' => 'Tipo de Violência Sexual'])
        ]);

    }


    /** @test */
    public function salvar_tp_viol_psico_obrigatorio_se_tipo_violencia_3()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->postJson('/api/atendimento',[
                'tipo_violencia' => [3],
                'tp_viol_psico' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'tp_viol_psico' => __('validation.required',['attribute' => 'Tipo de Violência Psicológica'])
        ]);

    }


    /** @test */
    public function salvar_motivo_n_con_enc_obrigatorio_se_concord_encami_false()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->postJson('/api/atendimento',[
                'concord_encami' => false,
                'motivo_n_con_enc' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'motivo_n_con_enc' => __('validation.required_if',['attribute' => 'Motivo de não ter concordado com os encaminhamentos',
                                                                         'other' => 'A vítima concordou com os encaminhamentos',
                                                                         'value' => 'false'
                                                                         ])
        ]);

    }


    /** @test */
    public function salvar_data_ocorrido_data()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'data_ocorrido' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'data_ocorrido' => __('validation.date',['attribute' => 'Data relatada do ocorrido'])
        ]);

    }


    /** @test */
    public function salvar_desc_sumaria_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'desc_sumaria' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'desc_sumaria' => __('validation.string',['attribute' => 'Descrição Sumária'])
        ]);

    }


    /** @test */
    public function salvar_como_soube_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'como_soube' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'como_soube' => __('validation.string',['attribute' => 'Como soube do Serviço'])
        ]);

    }


    /** @test */
    public function salvar_nome_instituicao_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'nome_instituicao' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'nome_instituicao' => __('validation.string',['attribute' => 'Nome da Instituição'])
        ]);

    }


    /** @test */
    public function salvar_contato_instituicao_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'contato_instituicao' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'contato_instituicao' => __('validation.string',['attribute' => 'Contato da Instituição'])
        ]);

    }


    /** @test */
    public function salvar_qual_out_form_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'qual_out_form' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'qual_out_form' => __('validation.string',['attribute' => 'Qual Outra Forma de Busca'])
        ]);

    }


    /** @test */
    public function salvar_caract_violencia_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'caract_violencia' => ['ABCDEF']
                ]);

        $response-> assertJsonValidationErrors([
            'caract_violencia.0' => __('validation.integer',['attribute' => 'Caracterização da Violência'])
        ]);

    }


    /** @test */
    public function salvar_tipo_violencia_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'tipo_violencia' => ['ABCDEF']
                ]);

        $response-> assertJsonValidationErrors([
            'tipo_violencia.0' => __('validation.integer',['attribute' => 'Tipo da Violência'])
        ]);

    }


    /** @test */
    public function salvar_tp_viol_fisica_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'tp_viol_fisica' => ['ABCDEF']
                ]);

        $response-> assertJsonValidationErrors([
            'tp_viol_fisica.0' => __('validation.integer',['attribute' => 'Tipo de Violência Física'])
        ]);

    }


    /** @test */
    public function salvar_tp_viol_sexual_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'tp_viol_sexual' => ['ABCDEF']
                ]);

        $response-> assertJsonValidationErrors([
            'tp_viol_sexual.0' => __('validation.integer',['attribute' => 'Tipo de Violência Sexual'])
        ]);

    }


    /** @test */
    public function salvar_tp_viol_psico_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'tp_viol_psico' => ['ABCDEF']
                ]);

        $response-> assertJsonValidationErrors([
            'tp_viol_psico.0' => __('validation.integer',['attribute' => 'Tipo de Violência Psicológica'])
        ]);

    }


    /** @test */
    public function salvar_motivo_n_con_enc_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'motivo_n_con_enc' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'motivo_n_con_enc' => __('validation.string',['attribute' => 'Motivo de não ter concordado com os encaminhamentos'])
        ]);

    }


    /** @test */
    public function salvar_providencia_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'providencia' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'providencia' => __('validation.string',['attribute' => 'Providências'])
        ]);

    }


    /** @test */
    public function salvar_org_acionado_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'org_acionado' => ['ABCDEF']
                ]);

        $response-> assertJsonValidationErrors([
            'org_acionado.0' => __('validation.integer',['attribute' => 'Órgão a serem Acionados'])
        ]);

    }


    /** @test */
    public function salvar_data_atendimento_data()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'data_atendimento' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'data_atendimento' => __('validation.date',['attribute' => 'Data do Atendimento'])
        ]);

    }


    /** @test */
    public function salvar_encaminha_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'encaminha' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'encaminha' => __('validation.string',['attribute' => 'Encaminhamentos'])
        ]);

    }


    /** @test */
    public function salvar_desc_sumaria_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',[
                'desc_sumaria' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'desc_sumaria' => __('validation.max.string',['attribute' => 'Descrição Sumária', 'max' => '5000'])
        ]);

    }


    /** @test */
    public function salvar_desc_sumaria_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $obj['desc_sumaria'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->cadastro_compara;
        $objcompara['desc_sumaria'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $response
        ->assertJsonMissingValidationErrors('desc_sumaria');

    }


    /** @test */
    public function salvar_como_soube_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',[
                'como_soube' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'como_soube' => __('validation.max.string',['attribute' => 'Como soube do Serviço', 'max' => '500'])
        ]);

    }


    /** @test */
    public function salvar_como_soube_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $obj['como_soube'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->cadastro_compara;
        $objcompara['como_soube'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $response
        ->assertJsonMissingValidationErrors('como_soube');

    }


    /** @test */
    public function salvar_nome_instituicao_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',[
                'nome_instituicao' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'nome_instituicao' => __('validation.max.string',['attribute' => 'Nome da Instituição', 'max' => '500'])
        ]);

    }


    /** @test */
    public function salvar_nome_instituicao_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $obj['nome_instituicao'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->cadastro_compara;
        $objcompara['nome_instituicao'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $response
        ->assertJsonMissingValidationErrors('nome_instituicao');

    }


    /** @test */
    public function salvar_contato_instituicao_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',[
                'contato_instituicao' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'contato_instituicao' => __('validation.max.string',['attribute' => 'Contato da Instituição', 'max' => '500'])
        ]);

    }


    /** @test */
    public function salvar_contato_instituicao_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $obj['contato_instituicao'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->cadastro_compara;
        $objcompara['contato_instituicao'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $response
        ->assertJsonMissingValidationErrors('contato_instituicao');

    }


    /** @test */
    public function salvar_qual_out_form_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',[
                'qual_out_form' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'qual_out_form' => __('validation.max.string',['attribute' => 'Qual Outra Forma de Busca', 'max' => '500'])
        ]);

    }


    /** @test */
    public function salvar_qual_out_form_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $obj['qual_out_form'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->cadastro_compara;
        $objcompara['qual_out_form'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $response
        ->assertJsonMissingValidationErrors('qual_out_form');

    }


    /** @test */
    public function salvar_motivo_n_con_enc_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',[
                'motivo_n_con_enc' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'motivo_n_con_enc' => __('validation.max.string',['attribute' => 'Motivo de não ter concordado com os encaminhamentos', 'max' => '5000'])
        ]);

    }


    /** @test */
    public function salvar_motivo_n_con_enc_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $obj['motivo_n_con_enc'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->cadastro_compara;
        $objcompara['motivo_n_con_enc'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $response
        ->assertJsonMissingValidationErrors('motivo_n_con_enc');

    }


    /** @test */
    public function salvar_providencia_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',[
                'providencia' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'providencia' => __('validation.max.string',['attribute' => 'Providências', 'max' => '5000'])
        ]);

    }


    /** @test */
    public function salvar_providencia_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $obj['providencia'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->cadastro_compara;
        $objcompara['providencia'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $response
        ->assertJsonMissingValidationErrors('providencia');

    }


    /** @test */
    public function salvar_encaminha_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',[
                'encaminha' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'encaminha' => __('validation.max.string',['attribute' => 'Encaminhamentos', 'max' => '5000'])
        ]);

    }


    /** @test */
    public function salvar_encaminha_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $obj['encaminha'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->cadastro_compara;
        $objcompara['encaminha'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $response
        ->assertJsonMissingValidationErrors('encaminha');

    }


    /** @test */
    public function salvar_desc_sumaria_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',[
                'desc_sumaria' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'desc_sumaria' => __('validation.min.string',['attribute' => 'Descrição Sumária', 'min' => '2'])
        ]);

    }


    /** @test */
    public function salvar_desc_sumaria_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $obj['desc_sumaria'] = 'Lo';
        $objcompara = $this->cadastro_compara;
        $objcompara['desc_sumaria'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $response
        ->assertJsonMissingValidationErrors('desc_sumaria');

    }


    /** @test */
    public function salvar_como_soube_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',[
                'como_soube' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'como_soube' => __('validation.min.string',['attribute' => 'Como soube do Serviço', 'min' => '2'])
        ]);

    }


    /** @test */
    public function salvar_como_soube_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $obj['como_soube'] = 'Lo';
        $objcompara = $this->cadastro_compara;
        $objcompara['como_soube'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $response
        ->assertJsonMissingValidationErrors('como_soube');

    }


    /** @test */
    public function salvar_nome_instituicao_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',[
                'nome_instituicao' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'nome_instituicao' => __('validation.min.string',['attribute' => 'Nome da Instituição', 'min' => '2'])
        ]);

    }


    /** @test */
    public function salvar_nome_instituicao_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $obj['nome_instituicao'] = 'Lo';
        $objcompara = $this->cadastro_compara;
        $objcompara['nome_instituicao'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $response
        ->assertJsonMissingValidationErrors('nome_instituicao');

    }


    /** @test */
    public function salvar_contato_instituicao_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',[
                'contato_instituicao' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'contato_instituicao' => __('validation.min.string',['attribute' => 'Contato da Instituição', 'min' => '2'])
        ]);

    }


    /** @test */
    public function salvar_contato_instituicao_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $obj['contato_instituicao'] = 'Lo';
        $objcompara = $this->cadastro_compara;
        $objcompara['contato_instituicao'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $response
        ->assertJsonMissingValidationErrors('contato_instituicao');

    }


    /** @test */
    public function salvar_qual_out_form_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',[
                'qual_out_form' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'qual_out_form' => __('validation.min.string',['attribute' => 'Qual Outra Forma de Busca', 'min' => '2'])
        ]);

    }


    /** @test */
    public function salvar_qual_out_form_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $obj['qual_out_form'] = 'Lo';
        $objcompara = $this->cadastro_compara;
        $objcompara['qual_out_form'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $response
        ->assertJsonMissingValidationErrors('qual_out_form');

    }


    /** @test */
    public function salvar_motivo_n_con_enc_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',[
                'motivo_n_con_enc' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'motivo_n_con_enc' => __('validation.min.string',['attribute' => 'Motivo de não ter concordado com os encaminhamentos', 'min' => '2'])
        ]);

    }


    /** @test */
    public function salvar_motivo_n_con_enc_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $obj['motivo_n_con_enc'] = 'Lo';
        $objcompara = $this->cadastro_compara;
        $objcompara['motivo_n_con_enc'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $response
        ->assertJsonMissingValidationErrors('motivo_n_con_enc');

    }


    /** @test */
    public function salvar_providencia_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',[
                'providencia' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'providencia' => __('validation.min.string',['attribute' => 'Providências', 'min' => '2'])
        ]);

    }


    /** @test */
    public function salvar_providencia_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $obj['providencia'] = 'Lo';
        $objcompara = $this->cadastro_compara;
        $objcompara['providencia'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $response
        ->assertJsonMissingValidationErrors('providencia');

    }


    /** @test */
    public function salvar_encaminha_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',[
                'encaminha' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'encaminha' => __('validation.min.string',['attribute' => 'Encaminhamentos', 'min' => '2'])
        ]);

    }


    /** @test */
    public function salvar_encaminha_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $obj['encaminha'] = 'Lo';
        $objcompara = $this->cadastro_compara;
        $objcompara['encaminha'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $response
        ->assertJsonMissingValidationErrors('encaminha');

    }


    /** @test */
    public function salvar_mulher_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'mulher' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'mulher' => __('validation.exists',['attribute' => 'Mulher'])
        ]);

    }


    /** @test */
    public function salvar_local_atend_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'local_atend' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'local_atend' => __('validation.exists',['attribute' => 'Local do Atendimento'])
        ]);

    }


    /** @test */
    public function salvar_for_busc_serv_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'for_busc_serv' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'for_busc_serv' => __('validation.exists',['attribute' => 'Forma de Busca do Serviço'])
        ]);

    }


    /** @test */
    public function salvar_inst_encaminha_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'inst_encaminha' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'inst_encaminha' => __('validation.exists',['attribute' => 'Tipo da Instituição que Encaminhou'])
        ]);

    }


    /** @test */
    public function salvar_prof_resp_encam_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'prof_resp_encam' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'prof_resp_encam' => __('validation.exists',['attribute' => 'Profissional responsável pelo Encaminhamento'])
        ]);

    }


    /** @test */
    public function salvar_caract_violencia_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'caract_violencia' => [9999]
        ]);

        $response-> assertJsonValidationErrors([
            'caract_violencia.0' => __('validation.exists',['attribute' => 'Caracterização da Violência'])
        ]);

    }


    /** @test */
    public function salvar_tipo_agressor_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'tipo_agressor' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'tipo_agressor' => __('validation.exists',['attribute' => 'Tipo do Agressor'])
        ]);

    }


    /** @test */
    public function salvar_relacao_agressor_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'relacao_agressor' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'relacao_agressor' => __('validation.exists',['attribute' => 'Grau de relação e/ou parentesco com o agressor(a)'])
        ]);

    }


    /** @test */
    public function salvar_tipo_violencia_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'tipo_violencia' => [9999]
        ]);

        $response-> assertJsonValidationErrors([
            'tipo_violencia.0' => __('validation.exists',['attribute' => 'Tipo da Violência'])
        ]);

    }


    /** @test */
    public function salvar_grau_violencia_fis_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'grau_violencia_fis' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'grau_violencia_fis' => __('validation.exists',['attribute' => 'Grau da Violência Física'])
        ]);

    }


    /** @test */
    public function salvar_tp_viol_fisica_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'tp_viol_fisica' => [9999]
        ]);

        $response-> assertJsonValidationErrors([
            'tp_viol_fisica.0' => __('validation.exists',['attribute' => 'Tipo de Violência Física'])
        ]);

    }


    /** @test */
    public function salvar_tp_atendimento_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'tp_atendimento' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'tp_atendimento' => __('validation.exists',['attribute' => 'Tipo de Atendimento'])
        ]);

    }


    /** @test */
    public function salvar_acao_rel_med_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'acao_rel_med' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'acao_rel_med' => __('validation.exists',['attribute' => 'Ação Relacionada a Medida Protetiva'])
        ]);

    }


    /** @test */
    public function salvar_tp_viol_sexual_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'tp_viol_sexual' => [9999]
        ]);

        $response-> assertJsonValidationErrors([
            'tp_viol_sexual.0' => __('validation.exists',['attribute' => 'Tipo de Violência Sexual'])
        ]);

    }


    /** @test */
    public function salvar_tp_viol_psico_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'tp_viol_psico' => [9999]
        ]);

        $response-> assertJsonValidationErrors([
            'tp_viol_psico.0' => __('validation.exists',['attribute' => 'Tipo de Violência Psicológica'])
        ]);

    }


    /** @test */
    public function salvar_aval_risc_int_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'aval_risc_int' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'aval_risc_int' => __('validation.exists',['attribute' => 'Avaliação de Risco à Integridade Física'])
        ]);

    }


    /** @test */
    public function salvar_org_acionado_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->postJson('/api/atendimento',[
                'org_acionado' => [9999]
        ]);

        $response-> assertJsonValidationErrors([
            'org_acionado.0' => __('validation.exists',['attribute' => 'Órgão a serem Acionados'])
        ]);

    }


    /** @test */
    public function editar_correto()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];


        $obj = $this->edicao_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,$obj);

        $response
        ->assertStatus(200)
        ->assertJsonFragment($this->edicao_compara);

    }
    /** @test */
    public function editar_local_atend_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                                    'local_atend' => '']);

        $response->assertJsonValidationErrors([
                   'local_atend' => __('validation.required',['attribute' => 'Local do Atendimento'])
        ]);

    }


    /** @test */
    public function editar_data_ocorrido_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                                    'data_ocorrido' => '']);

        $response->assertJsonValidationErrors([
                   'data_ocorrido' => __('validation.required',['attribute' => 'Data relatada do ocorrido'])
        ]);

    }


    /** @test */
    public function editar_desc_sumaria_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                                    'desc_sumaria' => '']);

        $response->assertJsonValidationErrors([
                   'desc_sumaria' => __('validation.required',['attribute' => 'Descrição Sumária'])
        ]);

    }


    /** @test */
    public function editar_for_busc_serv_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                                    'for_busc_serv' => '']);

        $response->assertJsonValidationErrors([
                   'for_busc_serv' => __('validation.required',['attribute' => 'Forma de Busca do Serviço'])
        ]);

    }


    /** @test */
    public function editar_caract_violencia_n_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                                    'caract_violencia' => '']);

        $response->assertJsonValidationErrors([
                   'caract_violencia' => __('validation.required',['attribute' => 'Caracterização da Violência'])
        ]);

    }


    /** @test */
    public function editar_tipo_agressor_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                                    'tipo_agressor' => '']);

        $response->assertJsonValidationErrors([
                   'tipo_agressor' => __('validation.required',['attribute' => 'Tipo do Agressor'])
        ]);

    }


    /** @test */
    public function editar_tipo_violencia_n_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                                    'tipo_violencia' => '']);

        $response->assertJsonValidationErrors([
                   'tipo_violencia' => __('validation.required',['attribute' => 'Tipo da Violência'])
        ]);

    }


    /** @test */
    public function editar_aval_risc_int_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                                    'aval_risc_int' => '']);

        $response->assertJsonValidationErrors([
                   'aval_risc_int' => __('validation.required',['attribute' => 'Avaliação de Risco à Integridade Física'])
        ]);

    }


    /** @test */
    public function editar_providencia_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                                    'providencia' => '']);

        $response->assertJsonValidationErrors([
                   'providencia' => __('validation.required',['attribute' => 'Providências'])
        ]);

    }


    /** @test */
    public function editar_org_acionado_n_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                                    'org_acionado' => '']);

        $response->assertJsonValidationErrors([
                   'org_acionado' => __('validation.required',['attribute' => 'Órgão a serem Acionados'])
        ]);

    }


    /** @test */
    public function editar_data_atendimento_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                                    'data_atendimento' => '']);

        $response->assertJsonValidationErrors([
                   'data_atendimento' => __('validation.required',['attribute' => 'Data do Atendimento'])
        ]);

    }


    /** @test */
    public function editar_encaminha_obrigatorio()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                                    'encaminha' => '']);

        $response->assertJsonValidationErrors([
                   'encaminha' => __('validation.required',['attribute' => 'Encaminhamentos'])
        ]);

    }


    /** @test */
    public function editar_como_soube_obrigatorio_se_for_busc_serv_1()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'for_busc_serv' => 1,
                'como_soube' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'como_soube' => __('validation.required',['attribute' => 'Como soube do Serviço'])
        ]);

    }


    /** @test */
    public function editar_inst_encaminha_obrigatorio_se_for_busc_serv_2()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'for_busc_serv' => 2,
                'inst_encaminha' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'inst_encaminha' => __('validation.required',['attribute' => 'Tipo da Instituição que Encaminhou'])
        ]);

    }


    /** @test */
    public function editar_nome_instituicao_obrigatorio_se_for_busc_serv_2()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'for_busc_serv' => 2,
                'nome_instituicao' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'nome_instituicao' => __('validation.required',['attribute' => 'Nome da Instituição'])
        ]);

    }


    /** @test */
    public function editar_contato_instituicao_obrigatorio_se_for_busc_serv_2()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'for_busc_serv' => 2,
                'contato_instituicao' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'contato_instituicao' => __('validation.required',['attribute' => 'Contato da Instituição'])
        ]);

    }


    /** @test */
    public function editar_prof_resp_encam_obrigatorio_se_for_busc_serv_2()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'for_busc_serv' => 2,
                'prof_resp_encam' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'prof_resp_encam' => __('validation.required',['attribute' => 'Profissional responsável pelo Encaminhamento'])
        ]);

    }


    /** @test */
    public function editar_qual_out_form_obrigatorio_se_for_busc_serv_3()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'for_busc_serv' => 3,
                'qual_out_form' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'qual_out_form' => __('validation.required',['attribute' => 'Qual Outra Forma de Busca'])
        ]);

    }


    /** @test */
    public function editar_relacao_agressor_obrigatorio_se_tipo_agressor_1()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'tipo_agressor' => 1,
                'relacao_agressor' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'relacao_agressor' => __('validation.required',['attribute' => 'Grau de relação e/ou parentesco com o agressor(a)'])
        ]);

    }


    /** @test */
    public function editar_grau_violencia_fis_obrigatorio_se_tipo_violencia_1()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'tipo_violencia' => [1],
                'grau_violencia_fis' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'grau_violencia_fis' => __('validation.required',['attribute' => 'Grau da Violência Física'])
        ]);

    }


    /** @test */
    public function editar_tp_viol_fisica_obrigatorio_se_tipo_violencia_1()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'tipo_violencia' => [1],
                'tp_viol_fisica' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'tp_viol_fisica' => __('validation.required',['attribute' => 'Tipo de Violência Física'])
        ]);

    }


    /** @test */
    public function editar_tp_atendimento_obrigatorio_se_tipo_violencia_1()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'tipo_violencia' => [1],
                'tp_atendimento' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'tp_atendimento' => __('validation.required',['attribute' => 'Tipo de Atendimento'])
        ]);

    }


    /** @test */
    public function editar_tp_viol_sexual_obrigatorio_se_tipo_violencia_2()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'tipo_violencia' => [2],
                'tp_viol_sexual' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'tp_viol_sexual' => __('validation.required',['attribute' => 'Tipo de Violência Sexual'])
        ]);

    }


    /** @test */
    public function editar_tp_viol_psico_obrigatorio_se_tipo_violencia_3()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'tipo_violencia' => [3],
                'tp_viol_psico' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'tp_viol_psico' => __('validation.required',['attribute' => 'Tipo de Violência Psicológica'])
        ]);

    }


    /** @test */
    public function editar_motivo_n_con_enc_obrigatorio_se_concord_encami_false()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'concord_encami' => false,
                'motivo_n_con_enc' => ''
            ]);

        $response-> assertJsonValidationErrors([
            'motivo_n_con_enc' => __('validation.required_if',['attribute' => 'Motivo de não ter concordado com os encaminhamentos',
                                                                         'other' => 'A vítima concordou com os encaminhamentos',
                                                                         'value' => 'false'
                                                                         ])
        ]);

    }


    /** @test */
    public function editar_data_ocorrido_data()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/atendimento/'.$id_objeto,[
                'data_ocorrido' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'data_ocorrido' => __('validation.date',['attribute' => 'Data relatada do ocorrido'])
        ]);

    }


    /** @test */
    public function editar_desc_sumaria_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/atendimento/'.$id_objeto,[
                'desc_sumaria' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'desc_sumaria' => __('validation.string',['attribute' => 'Descrição Sumária'])
        ]);

    }


    /** @test */
    public function editar_como_soube_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/atendimento/'.$id_objeto,[
                'como_soube' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'como_soube' => __('validation.string',['attribute' => 'Como soube do Serviço'])
        ]);

    }


    /** @test */
    public function editar_nome_instituicao_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/atendimento/'.$id_objeto,[
                'nome_instituicao' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'nome_instituicao' => __('validation.string',['attribute' => 'Nome da Instituição'])
        ]);

    }


    /** @test */
    public function editar_contato_instituicao_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/atendimento/'.$id_objeto,[
                'contato_instituicao' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'contato_instituicao' => __('validation.string',['attribute' => 'Contato da Instituição'])
        ]);

    }


    /** @test */
    public function editar_qual_out_form_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/atendimento/'.$id_objeto,[
                'qual_out_form' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'qual_out_form' => __('validation.string',['attribute' => 'Qual Outra Forma de Busca'])
        ]);

    }


    /** @test */
    public function editar_caract_violencia_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/atendimento/'.$id_objeto,[
                'caract_violencia' => ['ABCDEF']
                ]);

        $response-> assertJsonValidationErrors([
            'caract_violencia.0' => __('validation.integer',['attribute' => 'Caracterização da Violência'])
        ]);

    }


    /** @test */
    public function editar_tipo_violencia_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/atendimento/'.$id_objeto,[
                'tipo_violencia' => ['ABCDEF']
                ]);

        $response-> assertJsonValidationErrors([
            'tipo_violencia.0' => __('validation.integer',['attribute' => 'Tipo da Violência'])
        ]);

    }


    /** @test */
    public function editar_tp_viol_fisica_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/atendimento/'.$id_objeto,[
                'tp_viol_fisica' => ['ABCDEF']
                ]);

        $response-> assertJsonValidationErrors([
            'tp_viol_fisica.0' => __('validation.integer',['attribute' => 'Tipo de Violência Física'])
        ]);

    }


    /** @test */
    public function editar_tp_viol_sexual_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/atendimento/'.$id_objeto,[
                'tp_viol_sexual' => ['ABCDEF']
                ]);

        $response-> assertJsonValidationErrors([
            'tp_viol_sexual.0' => __('validation.integer',['attribute' => 'Tipo de Violência Sexual'])
        ]);

    }


    /** @test */
    public function editar_tp_viol_psico_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/atendimento/'.$id_objeto,[
                'tp_viol_psico' => ['ABCDEF']
                ]);

        $response-> assertJsonValidationErrors([
            'tp_viol_psico.0' => __('validation.integer',['attribute' => 'Tipo de Violência Psicológica'])
        ]);

    }


    /** @test */
    public function editar_motivo_n_con_enc_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/atendimento/'.$id_objeto,[
                'motivo_n_con_enc' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'motivo_n_con_enc' => __('validation.string',['attribute' => 'Motivo de não ter concordado com os encaminhamentos'])
        ]);

    }


    /** @test */
    public function editar_providencia_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/atendimento/'.$id_objeto,[
                'providencia' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'providencia' => __('validation.string',['attribute' => 'Providências'])
        ]);

    }


    /** @test */
    public function editar_org_acionado_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/atendimento/'.$id_objeto,[
                'org_acionado' => ['ABCDEF']
                ]);

        $response-> assertJsonValidationErrors([
            'org_acionado.0' => __('validation.integer',['attribute' => 'Órgão a serem Acionados'])
        ]);

    }


    /** @test */
    public function editar_data_atendimento_data()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/atendimento/'.$id_objeto,[
                'data_atendimento' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'data_atendimento' => __('validation.date',['attribute' => 'Data do Atendimento'])
        ]);

    }


    /** @test */
    public function editar_encaminha_string()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/atendimento/'.$id_objeto,[
                'encaminha' => 999
                ]);

        $response-> assertJsonValidationErrors([
            'encaminha' => __('validation.string',['attribute' => 'Encaminhamentos'])
        ]);

    }


    /** @test */
    public function editar_desc_sumaria_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/atendimento/'.$id_objeto,[
                'desc_sumaria' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'desc_sumaria' => __('validation.max.string',['attribute' => 'Descrição Sumária', 'max' => '5000'])
        ]);

    }


    /** @test */
    public function editar_desc_sumaria_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['desc_sumaria'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->edicao_compara;
        $objcompara['desc_sumaria'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('desc_sumaria');

    }


    /** @test */
    public function editar_como_soube_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/atendimento/'.$id_objeto,[
                'como_soube' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'como_soube' => __('validation.max.string',['attribute' => 'Como soube do Serviço', 'max' => '500'])
        ]);

    }


    /** @test */
    public function editar_como_soube_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['como_soube'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->edicao_compara;
        $objcompara['como_soube'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('como_soube');

    }


    /** @test */
    public function editar_nome_instituicao_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/atendimento/'.$id_objeto,[
                'nome_instituicao' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'nome_instituicao' => __('validation.max.string',['attribute' => 'Nome da Instituição', 'max' => '500'])
        ]);

    }


    /** @test */
    public function editar_nome_instituicao_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['nome_instituicao'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->edicao_compara;
        $objcompara['nome_instituicao'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('nome_instituicao');

    }


    /** @test */
    public function editar_contato_instituicao_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/atendimento/'.$id_objeto,[
                'contato_instituicao' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'contato_instituicao' => __('validation.max.string',['attribute' => 'Contato da Instituição', 'max' => '500'])
        ]);

    }


    /** @test */
    public function editar_contato_instituicao_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['contato_instituicao'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->edicao_compara;
        $objcompara['contato_instituicao'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('contato_instituicao');

    }


    /** @test */
    public function editar_qual_out_form_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/atendimento/'.$id_objeto,[
                'qual_out_form' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'qual_out_form' => __('validation.max.string',['attribute' => 'Qual Outra Forma de Busca', 'max' => '500'])
        ]);

    }


    /** @test */
    public function editar_qual_out_form_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['qual_out_form'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->edicao_compara;
        $objcompara['qual_out_form'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('qual_out_form');

    }


    /** @test */
    public function editar_motivo_n_con_enc_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/atendimento/'.$id_objeto,[
                'motivo_n_con_enc' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'motivo_n_con_enc' => __('validation.max.string',['attribute' => 'Motivo de não ter concordado com os encaminhamentos', 'max' => '5000'])
        ]);

    }


    /** @test */
    public function editar_motivo_n_con_enc_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['motivo_n_con_enc'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->edicao_compara;
        $objcompara['motivo_n_con_enc'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('motivo_n_con_enc');

    }


    /** @test */
    public function editar_providencia_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/atendimento/'.$id_objeto,[
                'providencia' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'providencia' => __('validation.max.string',['attribute' => 'Providências', 'max' => '5000'])
        ]);

    }


    /** @test */
    public function editar_providencia_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['providencia'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->edicao_compara;
        $objcompara['providencia'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('providencia');

    }


    /** @test */
    public function editar_encaminha_maior_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_maior ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_maior = $txt_Lorem_ipsum_maior . 'Lorem';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders([
            'Accept' => 'application/json',
            ])->putJson('/api/atendimento/'.$id_objeto,[
                'encaminha' => $txt_Lorem_ipsum_maior
        ]);

        $response-> assertJsonValidationErrors([
            'encaminha' => __('validation.max.string',['attribute' => 'Encaminhamentos', 'max' => '5000'])
        ]);

    }


    /** @test */
    public function editar_encaminha_igual_max_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $txt_Lorem_ipsum_max ='Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';
        $txt_Lorem_ipsum_max = $txt_Lorem_ipsum_max . 'Lorem_ipsum_dolor_sit_amet_consectetuer_adipiscing_elit_Aenean_commodo_ligula_eget_dolor_Aenean_mass';

        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['encaminha'] = $txt_Lorem_ipsum_max;
        $objcompara = $this->edicao_compara;
        $objcompara['encaminha'] = $txt_Lorem_ipsum_max;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('encaminha');

    }


    /** @test */
    public function editar_desc_sumaria_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'desc_sumaria' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'desc_sumaria' => __('validation.min.string',['attribute' => 'Descrição Sumária', 'min' => '2'])
        ]);

    }


    /** @test */
    public function editar_desc_sumaria_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['desc_sumaria'] = 'Lo';
        $objcompara = $this->edicao_compara;
        $objcompara['desc_sumaria'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('desc_sumaria');

    }

    /** @test */
    public function editar_como_soube_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'como_soube' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'como_soube' => __('validation.min.string',['attribute' => 'Como soube do Serviço', 'min' => '2'])
        ]);

    }


    /** @test */
    public function editar_como_soube_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['como_soube'] = 'Lo';
        $objcompara = $this->edicao_compara;
        $objcompara['como_soube'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('como_soube');

    }

    /** @test */
    public function editar_nome_instituicao_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'nome_instituicao' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'nome_instituicao' => __('validation.min.string',['attribute' => 'Nome da Instituição', 'min' => '2'])
        ]);

    }


    /** @test */
    public function editar_nome_instituicao_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['nome_instituicao'] = 'Lo';
        $objcompara = $this->edicao_compara;
        $objcompara['nome_instituicao'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('nome_instituicao');

    }

    /** @test */
    public function editar_contato_instituicao_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'contato_instituicao' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'contato_instituicao' => __('validation.min.string',['attribute' => 'Contato da Instituição', 'min' => '2'])
        ]);

    }


    /** @test */
    public function editar_contato_instituicao_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['contato_instituicao'] = 'Lo';
        $objcompara = $this->edicao_compara;
        $objcompara['contato_instituicao'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('contato_instituicao');

    }

    /** @test */
    public function editar_qual_out_form_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'qual_out_form' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'qual_out_form' => __('validation.min.string',['attribute' => 'Qual Outra Forma de Busca', 'min' => '2'])
        ]);

    }


    /** @test */
    public function editar_qual_out_form_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['qual_out_form'] = 'Lo';
        $objcompara = $this->edicao_compara;
        $objcompara['qual_out_form'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('qual_out_form');

    }

    /** @test */
    public function editar_motivo_n_con_enc_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'motivo_n_con_enc' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'motivo_n_con_enc' => __('validation.min.string',['attribute' => 'Motivo de não ter concordado com os encaminhamentos', 'min' => '2'])
        ]);

    }


    /** @test */
    public function editar_motivo_n_con_enc_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['motivo_n_con_enc'] = 'Lo';
        $objcompara = $this->edicao_compara;
        $objcompara['motivo_n_con_enc'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('motivo_n_con_enc');

    }

    /** @test */
    public function editar_providencia_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'providencia' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'providencia' => __('validation.min.string',['attribute' => 'Providências', 'min' => '2'])
        ]);

    }


    /** @test */
    public function editar_providencia_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['providencia'] = 'Lo';
        $objcompara = $this->edicao_compara;
        $objcompara['providencia'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('providencia');

    }

    /** @test */
    public function editar_encaminha_menor_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'encaminha' => 'L'
        ]);

        $response-> assertJsonValidationErrors([
            'encaminha' => __('validation.min.string',['attribute' => 'Encaminhamentos', 'min' => '2'])
        ]);

    }


    /** @test */
    public function editar_encaminha_igual_min_permitido()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = $this->edicao_correto;
        $obj2['encaminha'] = 'Lo';
        $objcompara = $this->edicao_compara;
        $objcompara['encaminha'] = 'Lo';
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto, $obj2);

        $response
        ->assertJsonMissingValidationErrors('encaminha');

    }

    /** @test */
    public function editar_local_atend_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'local_atend' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'local_atend' => __('validation.exists',['attribute' => 'Local do Atendimento'])
        ]);

    }


    /** @test */
    public function editar_for_busc_serv_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'for_busc_serv' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'for_busc_serv' => __('validation.exists',['attribute' => 'Forma de Busca do Serviço'])
        ]);

    }


    /** @test */
    public function editar_inst_encaminha_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'inst_encaminha' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'inst_encaminha' => __('validation.exists',['attribute' => 'Tipo da Instituição que Encaminhou'])
        ]);

    }


    /** @test */
    public function editar_prof_resp_encam_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'prof_resp_encam' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'prof_resp_encam' => __('validation.exists',['attribute' => 'Profissional responsável pelo Encaminhamento'])
        ]);

    }


    /** @test */
    public function editar_caract_violencia_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'caract_violencia' => [9999]
        ]);

        $response-> assertJsonValidationErrors([
            'caract_violencia.0' => __('validation.exists',['attribute' => 'Caracterização da Violência'])
        ]);

    }


    /** @test */
    public function editar_tipo_agressor_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'tipo_agressor' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'tipo_agressor' => __('validation.exists',['attribute' => 'Tipo do Agressor'])
        ]);

    }


    /** @test */
    public function editar_relacao_agressor_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'relacao_agressor' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'relacao_agressor' => __('validation.exists',['attribute' => 'Grau de relação e/ou parentesco com o agressor(a)'])
        ]);

    }


    /** @test */
    public function editar_tipo_violencia_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'tipo_violencia' => [9999]
        ]);

        $response-> assertJsonValidationErrors([
            'tipo_violencia.0' => __('validation.exists',['attribute' => 'Tipo da Violência'])
        ]);

    }


    /** @test */
    public function editar_grau_violencia_fis_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'grau_violencia_fis' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'grau_violencia_fis' => __('validation.exists',['attribute' => 'Grau da Violência Física'])
        ]);

    }


    /** @test */
    public function editar_tp_viol_fisica_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'tp_viol_fisica' => [9999]
        ]);

        $response-> assertJsonValidationErrors([
            'tp_viol_fisica.0' => __('validation.exists',['attribute' => 'Tipo de Violência Física'])
        ]);

    }


    /** @test */
    public function editar_tp_atendimento_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'tp_atendimento' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'tp_atendimento' => __('validation.exists',['attribute' => 'Tipo de Atendimento'])
        ]);

    }


    /** @test */
    public function editar_acao_rel_med_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'acao_rel_med' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'acao_rel_med' => __('validation.exists',['attribute' => 'Ação Relacionada a Medida Protetiva'])
        ]);

    }


    /** @test */
    public function editar_tp_viol_sexual_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'tp_viol_sexual' => [9999]
        ]);

        $response-> assertJsonValidationErrors([
            'tp_viol_sexual.0' => __('validation.exists',['attribute' => 'Tipo de Violência Sexual'])
        ]);

    }


    /** @test */
    public function editar_tp_viol_psico_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'tp_viol_psico' => [9999]
        ]);

        $response-> assertJsonValidationErrors([
            'tp_viol_psico.0' => __('validation.exists',['attribute' => 'Tipo de Violência Psicológica'])
        ]);

    }


    /** @test */
    public function editar_aval_risc_int_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'aval_risc_int' => 9999
        ]);

        $response-> assertJsonValidationErrors([
            'aval_risc_int' => __('validation.exists',['attribute' => 'Avaliação de Risco à Integridade Física'])
        ]);

    }


    /** @test */
    public function editar_org_acionado_exist()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->putJson('/api/atendimento/'.$id_objeto,[
                'org_acionado' => [9999]
        ]);

        $response-> assertJsonValidationErrors([
            'org_acionado.0' => __('validation.exists',['attribute' => 'Órgão a serem Acionados'])
        ]);

    }


    /** @test */
    public function buscar_registro_especifico()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $response = $this->withHeaders(['Accept' => 'application/json',])
                        ->get('/api/atendimento/'.$id_objeto);

        $response
        ->assertStatus(200)
        ->assertJson($this->cadastro_compara);

    }


    /** @test */
    public function buscar_varios_registros()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();

        $obj2 = array_merge($this->cadastro_correto, $this->edicao_correto);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj2);

        $resposta = $response->assertStatus(201)->getContent();


        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->get('/api/atendimento/');

        $response
        ->assertStatus(200)
        ->assertJsonCount(2);

    }


    /** @test */
    public function deletar_um_registro()
    {
        $user = User::factory()->createOne();
        Sanctum::actingAs($user, ['*']);

        $id_item = Profile::where('nome','=','Admin')->firstOrFail()->id;
        $user->profile()->sync($id_item);

        $this->pre_cadastro();
        $obj = $this->cadastro_correto;
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj);

        $resposta = $response->assertStatus(201)->getContent();
        $id_objeto = json_decode($resposta,true)['id'];

        $obj2 = array_merge($this->cadastro_correto, $this->edicao_correto);
        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->postJson('/api/atendimento',$obj2);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->delete('/api/atendimento/'.$id_objeto);

        $response = $this->withHeaders(['Accept' => 'application/json',])
                         ->get('/api/atendimento/');

        $response
        ->assertStatus(200)
        ->assertJsonMissingExact($obj);

    }

}

